import { useMemo, useState } from 'react';
import type { AnalysisResult } from '../types/market.ts';

interface CandlestickChartProps {
  analysis: AnalysisResult;
  visibleCount?: number;
}

export function CandlestickChart({ analysis, visibleCount = 55 }: CandlestickChartProps) {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const viewData = useMemo(() => {
    const total = analysis.candles.length;
    const start = Math.max(0, total - visibleCount);
    const candles = analysis.candles.slice(start);
    const emaFast = analysis.series.emaFast.slice(start);
    const emaSlow = analysis.series.emaSlow.slice(start);
    const rsi = analysis.series.rsi.slice(start);
    const macdLine = analysis.series.macdLine.slice(start);
    const macdSignal = analysis.series.macdSignal.slice(start);
    const macdHist = analysis.series.macdHistogram.slice(start);

    return {
      candles,
      emaFast,
      emaSlow,
      rsi,
      macdLine,
      macdSignal,
      macdHist,
    };
  }, [analysis, visibleCount]);

  if (viewData.candles.length === 0) {
    return null;
  }

  const width = 760;
  const priceHeight = 250;
  const rsiHeight = 76;
  const macdHeight = 76;
  const padLeft = 10;
  const padRight = 64;
  const padTop = 14;
  const padBottom = 14;

  const plotWidth = width - padLeft - padRight;
  const n = viewData.candles.length;
  const stepX = plotWidth / n;
  const candleWidth = Math.max(3, Math.min(10, stepX * 0.62));

  // Price bounds
  let minPrice = Infinity;
  let maxPrice = -Infinity;
  for (let i = 0; i < n; i++) {
    const c = viewData.candles[i];
    if (c.low < minPrice) minPrice = c.low;
    if (c.high > maxPrice) maxPrice = c.high;
    const ef = viewData.emaFast[i];
    const es = viewData.emaSlow[i];
    if (ef !== null) {
      minPrice = Math.min(minPrice, ef);
      maxPrice = Math.max(maxPrice, ef);
    }
    if (es !== null) {
      minPrice = Math.min(minPrice, es);
      maxPrice = Math.max(maxPrice, es);
    }
  }
  const priceSpan = Math.max(maxPrice - minPrice, 1e-8);
  const pricePad = priceSpan * 0.08;
  const yMin = minPrice - pricePad;
  const yMax = maxPrice + pricePad;

  const mapPriceY = (val: number) => {
    const ratio = (val - yMin) / (yMax - yMin);
    return padTop + (priceHeight - padTop - padBottom) * (1 - ratio);
  };

  // MACD bounds
  let maxMacdAbs = 1e-8;
  for (let i = 0; i < n; i++) {
    const m = viewData.macdLine[i];
    const s = viewData.macdSignal[i];
    const h = viewData.macdHist[i];
    if (m !== null) maxMacdAbs = Math.max(maxMacdAbs, Math.abs(m));
    if (s !== null) maxMacdAbs = Math.max(maxMacdAbs, Math.abs(s));
    if (h !== null) maxMacdAbs = Math.max(maxMacdAbs, Math.abs(h));
  }
  const mapMacdY = (val: number) => {
    const mid = macdHeight / 2;
    const scale = (macdHeight / 2 - 8) / maxMacdAbs;
    return mid - val * scale;
  };

  const mapRsiY = (val: number) => {
    const clamped = Math.max(0, Math.min(100, val));
    return 8 + (rsiHeight - 16) * (1 - clamped / 100);
  };

  const buildPolyline = (arr: (number | null)[], mapY: (v: number) => number) => {
    const pts: string[] = [];
    for (let i = 0; i < arr.length; i++) {
      const val = arr[i];
      if (val === null) continue;
      const x = padLeft + i * stepX + stepX / 2;
      const y = mapY(val);
      pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
    }
    return pts.join(' ');
  };

  const emaFastPoints = buildPolyline(viewData.emaFast, mapPriceY);
  const emaSlowPoints = buildPolyline(viewData.emaSlow, mapPriceY);
  const rsiPoints = buildPolyline(viewData.rsi, mapRsiY);
  const macdLinePoints = buildPolyline(viewData.macdLine, mapMacdY);
  const macdSignalPoints = buildPolyline(viewData.macdSignal, mapMacdY);

  const activeIdx = hoveredIdx !== null && hoveredIdx < n ? hoveredIdx : n - 1;
  const activeCandle = viewData.candles[activeIdx];
  const activeEmaF = viewData.emaFast[activeIdx];
  const activeEmaS = viewData.emaSlow[activeIdx];
  const activeRsi = viewData.rsi[activeIdx];
  const activeHist = viewData.macdHist[activeIdx];

  const decimals = analysis.pair.decimals;
  const priceLevels = [yMax, (yMax + yMin) / 2, yMin];

  const handlePointer = (clientX: number, rect: DOMRect) => {
    const relX = ((clientX - rect.left) / rect.width) * width;
    const idx = Math.floor((relX - padLeft) / stepX);
    if (idx >= 0 && idx < n) {
      setHoveredIdx(idx);
    }
  };

  return (
    <div className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-3 sm:p-4">
      {/* Live / Hovered OHLC Telemetry Strip */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5 text-xs">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 font-mono tabular-nums text-slate-300">
          <span className="text-slate-400">
            {new Date(activeCandle.time).toLocaleTimeString('pt-PT', {
              hour: '2-digit',
              minute: '2-digit',
              hour12: false,
            })}
          </span>
          <span>O {activeCandle.open.toFixed(decimals)}</span>
          <span>H {activeCandle.high.toFixed(decimals)}</span>
          <span>L {activeCandle.low.toFixed(decimals)}</span>
          <span
            className={
              activeCandle.close >= activeCandle.open ? 'text-emerald-400' : 'text-red-400'
            }
          >
            C {activeCandle.close.toFixed(decimals)}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] tabular-nums">
          <span className="text-sky-400">
            EMA9 {activeEmaF !== null ? activeEmaF.toFixed(decimals) : '—'}
          </span>
          <span className="text-amber-400">
            EMA21 {activeEmaS !== null ? activeEmaS.toFixed(decimals) : '—'}
          </span>
          <span className="text-slate-300">
            RSI {activeRsi !== null ? activeRsi.toFixed(1) : '—'}
          </span>
        </div>
      </div>

      {/* Main Price & EMAs SVG */}
      <div
        className="relative w-full select-none touch-pan-y"
        onMouseLeave={() => setHoveredIdx(null)}
        onMouseMove={(e) => handlePointer(e.clientX, e.currentTarget.getBoundingClientRect())}
        onTouchStart={(e) => {
          if (e.touches[0]) {
            handlePointer(e.touches[0].clientX, e.currentTarget.getBoundingClientRect());
          }
        }}
        onTouchMove={(e) => {
          if (e.touches[0]) {
            handlePointer(e.touches[0].clientX, e.currentTarget.getBoundingClientRect());
          }
        }}
      >
        <svg
          viewBox={`0 0 ${width} ${priceHeight}`}
          className="h-auto w-full overflow-visible"
          role="img"
          aria-label={`Gráfico de velas para ${analysis.pair.symbol}`}
        >
          {/* Horizontal grid lines */}
          {priceLevels.map((lvl, idx) => {
            const y = mapPriceY(lvl);
            return (
              <g key={idx}>
                <line
                  x1={padLeft}
                  y1={y}
                  x2={width - padRight}
                  y2={y}
                  stroke="#1E293B"
                  strokeDasharray="3 4"
                  strokeWidth="1"
                />
                <text
                  x={width - padRight + 6}
                  y={y + 4}
                  fill="#64748B"
                  fontSize="10"
                  fontFamily="JetBrains Mono, monospace"
                >
                  {lvl.toFixed(decimals)}
                </text>
              </g>
            );
          })}

          {/* Active crosshair vertical line */}
          <line
            x1={padLeft + activeIdx * stepX + stepX / 2}
            y1={padTop}
            x2={padLeft + activeIdx * stepX + stepX / 2}
            y2={priceHeight - padBottom}
            stroke="#334155"
            strokeWidth="1"
            strokeDasharray="2 2"
          />

          {/* Candlesticks */}
          {viewData.candles.map((c, i) => {
            const xCenter = padLeft + i * stepX + stepX / 2;
            const isUp = c.close >= c.open;
            const color = isUp ? '#22C55E' : '#EF4444';
            const yHigh = mapPriceY(c.high);
            const yLow = mapPriceY(c.low);
            const yOpen = mapPriceY(c.open);
            const yClose = mapPriceY(c.close);
            const bodyTop = Math.min(yOpen, yClose);
            const bodyHeight = Math.max(1.5, Math.abs(yOpen - yClose));

            return (
              <g key={c.time}>
                <line
                  x1={xCenter}
                  y1={yHigh}
                  x2={xCenter}
                  y2={yLow}
                  stroke={color}
                  strokeWidth="1.25"
                />
                <rect
                  x={xCenter - candleWidth / 2}
                  y={bodyTop}
                  width={candleWidth}
                  height={bodyHeight}
                  fill={color}
                  rx="0.75"
                />
              </g>
            );
          })}

          {/* EMA 21 & EMA 9 */}
          {emaSlowPoints && (
            <polyline
              fill="none"
              stroke="#F59E0B"
              strokeWidth="1.75"
              points={emaSlowPoints}
            />
          )}
          {emaFastPoints && (
            <polyline
              fill="none"
              stroke="#38BDF8"
              strokeWidth="1.75"
              points={emaFastPoints}
            />
          )}

          {/* Current Price Line */}
          {analysis.currentPrice !== null && (
            <g>
              <line
                x1={padLeft}
                y1={mapPriceY(analysis.currentPrice)}
                x2={width - padRight}
                y2={mapPriceY(analysis.currentPrice)}
                stroke="#3B82F6"
                strokeWidth="1"
                strokeOpacity="0.65"
              />
              <rect
                x={width - padRight + 2}
                y={mapPriceY(analysis.currentPrice) - 9}
                width={padRight - 4}
                height={18}
                rx="3"
                fill="#1D4ED8"
              />
              <text
                x={width - padRight + 6}
                y={mapPriceY(analysis.currentPrice) + 4}
                fill="#FFFFFF"
                fontSize="10"
                fontWeight="600"
                fontFamily="JetBrains Mono, monospace"
              >
                {analysis.currentPrice.toFixed(decimals)}
              </text>
            </g>
          )}
        </svg>
      </div>

      {/* RSI (14) Sub-Panel */}
      <div className="mt-2 border-t border-slate-800/80 pt-2">
        <div className="mb-1 flex items-center justify-between text-[11px] text-slate-400">
          <span>RSI ({analysis.latestIndicators.rsi !== null ? analysis.latestIndicators.rsi.toFixed(1) : '—'})</span>
          <span className="font-mono">70 / 30</span>
        </div>
        <svg viewBox={`0 0 ${width} ${rsiHeight}`} className="h-auto w-full">
          <line
            x1={padLeft}
            y1={mapRsiY(70)}
            x2={width - padRight}
            y2={mapRsiY(70)}
            stroke="#EF4444"
            strokeOpacity="0.35"
            strokeDasharray="3 3"
          />
          <line
            x1={padLeft}
            y1={mapRsiY(50)}
            x2={width - padRight}
            y2={mapRsiY(50)}
            stroke="#334155"
            strokeDasharray="2 3"
          />
          <line
            x1={padLeft}
            y1={mapRsiY(30)}
            x2={width - padRight}
            y2={mapRsiY(30)}
            stroke="#22C55E"
            strokeOpacity="0.35"
            strokeDasharray="3 3"
          />
          {rsiPoints && (
            <polyline
              fill="none"
              stroke="#60A5FA"
              strokeWidth="1.6"
              points={rsiPoints}
            />
          )}
          <text x={width - padRight + 6} y={mapRsiY(70) + 3} fill="#94A3B8" fontSize="9" fontFamily="JetBrains Mono, monospace">
            70
          </text>
          <text x={width - padRight + 6} y={mapRsiY(30) + 3} fill="#94A3B8" fontSize="9" fontFamily="JetBrains Mono, monospace">
            30
          </text>
        </svg>
      </div>

      {/* MACD (12, 26, 9) Sub-Panel */}
      <div className="mt-2 border-t border-slate-800/80 pt-2">
        <div className="mb-1 flex items-center justify-between text-[11px] text-slate-400">
          <span>MACD (12, 26, 9)</span>
          <span className="font-mono tabular-nums">
            Hist {activeHist !== null ? activeHist.toFixed(decimals + 1) : '—'}
          </span>
        </div>
        <svg viewBox={`0 0 ${width} ${macdHeight}`} className="h-auto w-full">
          <line
            x1={padLeft}
            y1={macdHeight / 2}
            x2={width - padRight}
            y2={macdHeight / 2}
            stroke="#1E293B"
            strokeWidth="1"
          />
          {viewData.macdHist.map((h, i) => {
            if (h === null) return null;
            const xCenter = padLeft + i * stepX + stepX / 2;
            const yZero = macdHeight / 2;
            const yVal = mapMacdY(h);
            const barTop = Math.min(yZero, yVal);
            const barHeight = Math.max(1, Math.abs(yVal - yZero));
            return (
              <rect
                key={i}
                x={xCenter - candleWidth / 2}
                y={barTop}
                width={candleWidth}
                height={barHeight}
                fill={h >= 0 ? '#22C55E' : '#EF4444'}
                fillOpacity="0.55"
              />
            );
          })}
          {macdLinePoints && (
            <polyline fill="none" stroke="#38BDF8" strokeWidth="1.4" points={macdLinePoints} />
          )}
          {macdSignalPoints && (
            <polyline fill="none" stroke="#F59E0B" strokeWidth="1.4" points={macdSignalPoints} />
          )}
        </svg>
      </div>
    </div>
  );
}
