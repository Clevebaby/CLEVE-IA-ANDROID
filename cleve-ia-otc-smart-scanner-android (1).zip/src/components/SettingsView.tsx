import {
  Archive,
  CheckCircle2,
  Eye,
  EyeOff,
  FolderCode,
  RotateCcw,
  Send,
  ShieldCheck,
  Smartphone,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import type { AppSettings } from '../types/market.ts';
import { apiUrl, getApiBaseUrl, setApiBaseUrl } from '../utils/api.ts';
import { DEFAULT_INDICATOR_CONFIG } from '../utils/indicators.ts';

interface ExportManifest {
  projectName: string;
  capacitorAppId: string;
  hasAndroidProject: boolean;
  totalFiles: number;
  totalBytes: number;
}

interface SettingsViewProps {
  settings: AppSettings;
  onSaveSettings: (updated: AppSettings) => Promise<void>;
}

export function SettingsView({ settings, onSaveSettings }: SettingsViewProps) {
  const [draft, setDraft] = useState<AppSettings>(settings);
  const [showToken, setShowToken] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );
  const [testingTelegram, setTestingTelegram] = useState(false);
  const [telegramResult, setTelegramResult] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [testingBridge, setTestingBridge] = useState(false);
  const [bridgeResult, setBridgeResult] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [apiBaseDraft, setApiBaseDraft] = useState<string>(() => getApiBaseUrl());
  const [manifest, setManifest] = useState<ExportManifest | null>(null);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);

  useEffect(() => {
    setDraft(settings);
  }, [settings]);

  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        const resp = await fetch(apiUrl('/api/export/manifest'));
        if (!resp.ok) return;
        const data = (await resp.json()) as ExportManifest;
        if (active) setManifest(data);
      } catch {
        // Ignore silent manifest fetch error
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaveMsg(null);
    try {
      setApiBaseUrl(apiBaseDraft);
      await onSaveSettings(draft);
      setSaveMsg({ type: 'success', text: 'Configurações guardadas com sucesso.' });
    } catch (err) {
      setSaveMsg({
        type: 'error',
        text: err instanceof Error ? err.message : 'Erro ao guardar configurações.',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDownloadProjectZip = async () => {
    setDownloadingZip(true);
    setExportError(null);
    try {
      const resp = await fetch(apiUrl('/api/export/project-zip'));
      if (!resp.ok) {
        throw new Error('Não foi possível gerar o pacote ZIP do projeto.');
      }
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'cleve-ia-otc-smart-scanner-android.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      setExportError(
        err instanceof Error ? err.message : 'Erro ao descarregar ZIP do projeto.'
      );
    } finally {
      setDownloadingZip(false);
    }
  };

  const handleTestTelegram = async () => {
    setTestingTelegram(true);
    setTelegramResult(null);
    try {
      const resp = await fetch(apiUrl('/api/telegram/test'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          botToken: draft.telegramBotToken,
          chatId: draft.telegramChatId,
        }),
      });
      const data = (await resp.json()) as { ok?: boolean; error?: string };
      if (!resp.ok || !data.ok) {
        setTelegramResult({
          type: 'error',
          text: data.error || 'Falha ao enviar mensagem de teste no Telegram.',
        });
      } else {
        setTelegramResult({
          type: 'success',
          text: 'Mensagem de teste enviada! Verifique o seu chat do Telegram.',
        });
      }
    } catch {
      setTelegramResult({
        type: 'error',
        text: 'Erro de rede ao contactar o servidor.',
      });
    } finally {
      setTestingTelegram(false);
    }
  };

  const handleTestBridge = async () => {
    setTestingBridge(true);
    setBridgeResult(null);
    try {
      const resp = await fetch(apiUrl('/api/market/test-bridge'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          otcBridgeUrl: draft.otcBridgeUrl,
          otcBridgeApiKey: draft.otcBridgeApiKey,
          pairSymbol: 'EUR/USD OTC',
          timeframe: '1m',
        }),
      });
      const data = (await resp.json()) as {
        ok?: boolean;
        candleCount?: number;
        error?: string;
      };
      if (!resp.ok || !data.ok) {
        setBridgeResult({
          type: 'error',
          text: data.error || 'Não foi possível validar a Bridge OTC.',
        });
      } else {
        setBridgeResult({
          type: 'success',
          text: `Ligação válida! ${data.candleCount} velas OHLC verificadas.`,
        });
      }
    } catch {
      setBridgeResult({
        type: 'error',
        text: 'Erro ao testar a Bridge OTC.',
      });
    } finally {
      setTestingBridge(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-5">
      <div className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4 sm:p-5">
        <h1 className="font-display text-xl font-bold text-white">
          Configurações do Sistema
        </h1>
        <p className="mt-0.5 text-xs text-slate-400">
          Gerencie o modo de operação, ligação OTC verificável, integração com Telegram e parâmetros dos indicadores.
        </p>
      </div>

      {/* Mode & Safety Lock */}
      <section className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4 sm:p-5">
        <h2 className="font-display text-base font-bold text-white">
          Modo de Operação e Segurança
        </h2>

        <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => setDraft({ ...draft, mode: 'DEMO' })}
            className={`min-h-[56px] rounded-xl border p-3.5 text-left transition-colors ${
              draft.mode === 'DEMO'
                ? 'border-blue-500 bg-[#0E1D3B] text-white'
                : 'border-slate-800 bg-[#060A14] text-slate-300 hover:border-slate-700'
            }`}
          >
            <span className="block text-sm font-bold">Modo DEMO (Recomendado)</span>
            <span className="mt-0.5 block text-xs text-slate-400">
              Registo e validação manual em ambiente de testes sem risco financeiro.
            </span>
          </button>

          <button
            type="button"
            onClick={() => setDraft({ ...draft, mode: 'REAL_ANALYTICS' })}
            className={`min-h-[56px] rounded-xl border p-3.5 text-left transition-colors ${
              draft.mode === 'REAL_ANALYTICS'
                ? 'border-emerald-500/60 bg-emerald-950/30 text-white'
                : 'border-slate-800 bg-[#060A14] text-slate-300 hover:border-slate-700'
            }`}
          >
            <span className="block text-sm font-bold">Modo Análise Real</span>
            <span className="mt-0.5 block text-xs text-slate-400">
              Apenas sinalização informativa. Continua sem execução automática.
            </span>
          </button>
        </div>

        <div className="mt-3 flex items-center gap-2.5 rounded-lg border border-slate-800 bg-[#060A14] px-3.5 py-2.5 text-xs text-slate-300">
          <ShieldCheck className="h-4 w-4 text-blue-400 shrink-0" />
          <span>
            <strong>Execução automática desativada:</strong> este sistema nunca abre nem fecha operações na Pocket Option.
          </span>
        </div>
      </section>

      {/* Telegram Integration */}
      <section className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4 sm:p-5">
        <h2 className="font-display text-base font-bold text-white">
          Integração Telegram
        </h2>
        <p className="mt-0.5 text-xs text-slate-400">
          Receba sinais de UP/DOWN, força, confiança estimada e hora de entrada diretamente no seu bot Telegram.
        </p>

        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="tg-token"
              className="mb-1.5 block text-xs font-medium text-slate-300"
            >
              Bot Token (@BotFather)
            </label>
            <div className="relative flex items-center">
              <input
                id="tg-token"
                type={showToken ? 'text' : 'password'}
                value={draft.telegramBotToken}
                onChange={(e) =>
                  setDraft({ ...draft, telegramBotToken: e.target.value })
                }
                placeholder="123456789:ABCdefGHIjklMNO..."
                className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] pl-3 pr-11 font-mono text-xs text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowToken(!showToken)}
                aria-label={showToken ? 'Ocultar token' : 'Mostrar token'}
                className="absolute right-1 flex min-h-[40px] min-w-[40px] items-center justify-center text-slate-400 hover:text-white"
              >
                {showToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div>
            <label
              htmlFor="tg-chat-id"
              className="mb-1.5 block text-xs font-medium text-slate-300"
            >
              Chat ID (Utilizador ou Grupo/Canal)
            </label>
            <input
              id="tg-chat-id"
              type="text"
              value={draft.telegramChatId}
              onChange={(e) =>
                setDraft({ ...draft, telegramChatId: e.target.value })
              }
              placeholder="Ex: 987654321 ou -1001234567890"
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div className="space-y-2">
            <label className="flex min-h-[44px] cursor-pointer items-center gap-2.5 text-xs text-slate-200">
              <input
                type="checkbox"
                checked={draft.telegramAutoAlert}
                onChange={(e) =>
                  setDraft({ ...draft, telegramAutoAlert: e.target.checked })
                }
                className="h-4 w-4 rounded border-slate-600 bg-[#050811] text-blue-600 focus:ring-blue-500"
              />
              <span>
                Enviar alerta automático ao detetar sinal OHLC com confiança &ge;{' '}
                {draft.indicatorConfig.minConfidence}%
              </span>
            </label>

            <label className="flex min-h-[44px] cursor-pointer items-center gap-2.5 text-xs text-slate-200">
              <input
                type="checkbox"
                checked={draft.telegramAutoSendCaptures}
                onChange={(e) =>
                  setDraft({ ...draft, telegramAutoSendCaptures: e.target.checked })
                }
                className="h-4 w-4 rounded border-slate-600 bg-[#050811] text-blue-600 focus:ring-blue-500"
              />
              <span>
                Enviar automaticamente resultado das análises de capturas de ecrã (par, período, direção, justificativa e confiança estimada)
              </span>
            </label>
          </div>

          <button
            type="button"
            onClick={handleTestTelegram}
            disabled={testingTelegram || !draft.telegramBotToken || !draft.telegramChatId}
            className="flex min-h-[44px] shrink-0 items-center justify-center gap-2 rounded-lg border border-blue-500/40 bg-[#0E1D3B] px-4 py-2 text-xs font-semibold text-blue-200 hover:bg-[#152A52] disabled:cursor-not-allowed disabled:opacity-45"
          >
            <Send className="h-3.5 w-3.5" />
            <span>{testingTelegram ? 'A testar...' : 'Testar Ligação Telegram'}</span>
          </button>
        </div>

        {telegramResult && (
          <div
            className={`mt-3 rounded-lg border px-3 py-2 text-xs ${
              telegramResult.type === 'success'
                ? 'border-emerald-500/40 bg-emerald-950/35 text-emerald-200'
                : 'border-red-500/40 bg-red-950/35 text-red-200'
            }`}
          >
            {telegramResult.text}
          </div>
        )}
      </section>

      {/* Verifiable OTC Bridge Source */}
      <section className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4 sm:p-5">
        <h2 className="font-display text-base font-bold text-white">
          Fonte de Dados OTC Compatível (Bridge / API REST)
        </h2>
        <p className="mt-0.5 text-xs text-slate-400">
          Opcional: se possuir um servidor/bridge pessoal com acesso às velas OHLC da Pocket Option OTC, introduza o endpoint JSON abaixo. O sistema consulta <code>?pair=...&amp;timeframe=...</code>.
        </p>

        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="otc-bridge-url"
              className="mb-1.5 block text-xs font-medium text-slate-300"
            >
              URL do Endpoint OTC
            </label>
            <input
              id="otc-bridge-url"
              type="url"
              value={draft.otcBridgeUrl}
              onChange={(e) => setDraft({ ...draft, otcBridgeUrl: e.target.value })}
              placeholder="https://sua-bridge-otc.exemplo/candles"
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="otc-bridge-key"
              className="mb-1.5 block text-xs font-medium text-slate-300"
            >
              Chave Bearer (Opcional)
            </label>
            <input
              id="otc-bridge-key"
              type="password"
              value={draft.otcBridgeApiKey}
              onChange={(e) =>
                setDraft({ ...draft, otcBridgeApiKey: e.target.value })
              }
              placeholder="Token de autenticação da bridge"
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-3 flex justify-end">
          <button
            type="button"
            onClick={handleTestBridge}
            disabled={testingBridge || !draft.otcBridgeUrl.trim()}
            className="min-h-[44px] rounded-lg border border-slate-700 bg-[#0D1526] px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-45"
          >
            {testingBridge ? 'A verificar...' : 'Testar Bridge OTC'}
          </button>
        </div>

        {bridgeResult && (
          <div
            className={`mt-3 rounded-lg border px-3 py-2 text-xs ${
              bridgeResult.type === 'success'
                ? 'border-emerald-500/40 bg-emerald-950/35 text-emerald-200'
                : 'border-red-500/40 bg-red-950/35 text-red-200'
            }`}
          >
            {bridgeResult.text}
          </div>
        )}
      </section>

      {/* Indicator Parameters */}
      <section className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-display text-base font-bold text-white">
              Parâmetros dos Indicadores Técnicos
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Ajuste os períodos de RSI, EMA 9/21, MACD e o limiar mínimo de confiança estimada.
            </p>
          </div>
          <button
            type="button"
            onClick={() =>
              setDraft({ ...draft, indicatorConfig: { ...DEFAULT_INDICATOR_CONFIG } })
            }
            className="flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-300 hover:bg-slate-800"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Restaurar Padrões</span>
          </button>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div>
            <label className="mb-1 block text-[11px] text-slate-400">RSI Período</label>
            <input
              type="number"
              min={5}
              max={30}
              value={draft.indicatorConfig.rsiPeriod}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  indicatorConfig: {
                    ...draft.indicatorConfig,
                    rsiPeriod: Number(e.target.value) || 14,
                  },
                })
              }
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white"
            />
          </div>
          <div>
            <label className="mb-1 block text-[11px] text-slate-400">RSI Sobrecompra</label>
            <input
              type="number"
              min={55}
              max={90}
              value={draft.indicatorConfig.rsiOverbought}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  indicatorConfig: {
                    ...draft.indicatorConfig,
                    rsiOverbought: Number(e.target.value) || 70,
                  },
                })
              }
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white"
            />
          </div>
          <div>
            <label className="mb-1 block text-[11px] text-slate-400">RSI Sobrevenda</label>
            <input
              type="number"
              min={10}
              max={45}
              value={draft.indicatorConfig.rsiOversold}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  indicatorConfig: {
                    ...draft.indicatorConfig,
                    rsiOversold: Number(e.target.value) || 30,
                  },
                })
              }
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white"
            />
          </div>
          <div>
            <label className="mb-1 block text-[11px] text-slate-400">Confiança Mín. (%)</label>
            <input
              type="number"
              min={52}
              max={90}
              value={draft.indicatorConfig.minConfidence}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  indicatorConfig: {
                    ...draft.indicatorConfig,
                    minConfidence: Number(e.target.value) || 62,
                  },
                })
              }
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white"
            />
          </div>

          <div>
            <label className="mb-1 block text-[11px] text-slate-400">EMA Rápida</label>
            <input
              type="number"
              min={3}
              max={20}
              value={draft.indicatorConfig.emaFast}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  indicatorConfig: {
                    ...draft.indicatorConfig,
                    emaFast: Number(e.target.value) || 9,
                  },
                })
              }
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white"
            />
          </div>
          <div>
            <label className="mb-1 block text-[11px] text-slate-400">EMA Lenta</label>
            <input
              type="number"
              min={10}
              max={50}
              value={draft.indicatorConfig.emaSlow}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  indicatorConfig: {
                    ...draft.indicatorConfig,
                    emaSlow: Number(e.target.value) || 21,
                  },
                })
              }
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white"
            />
          </div>
          <div>
            <label className="mb-1 block text-[11px] text-slate-400">MACD Rápido / Lento</label>
            <div className="flex gap-1.5">
              <input
                type="number"
                min={5}
                max={20}
                value={draft.indicatorConfig.macdFast}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    indicatorConfig: {
                      ...draft.indicatorConfig,
                      macdFast: Number(e.target.value) || 12,
                    },
                  })
                }
                className="w-1/2 min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-2 font-mono text-xs text-white"
              />
              <input
                type="number"
                min={15}
                max={40}
                value={draft.indicatorConfig.macdSlow}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    indicatorConfig: {
                      ...draft.indicatorConfig,
                      macdSlow: Number(e.target.value) || 26,
                    },
                  })
                }
                className="w-1/2 min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-2 font-mono text-xs text-white"
              />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-[11px] text-slate-400">MACD Sinal</label>
            <input
              type="number"
              min={3}
              max={15}
              value={draft.indicatorConfig.macdSignal}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  indicatorConfig: {
                    ...draft.indicatorConfig,
                    macdSignal: Number(e.target.value) || 9,
                  },
                })
              }
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white"
            />
          </div>
        </div>
      </section>

      {/* Android APK (Capacitor) & ZIP Project Export */}
      <section className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4 sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Smartphone className="h-4 w-4 text-blue-400" />
              <h2 className="font-display text-base font-bold text-white">
                Exportar Projeto (.ZIP) e APK Android (Capacitor)
              </h2>
            </div>
            <p className="mt-0.5 text-xs text-slate-400">
              Descarregue o código-fonte completo organizado para telemóvel ou PC (HTML, CSS, React, TypeScript, Express e projeto nativo Capacitor Android) pronto para gerar o APK.
            </p>
          </div>

          <button
            type="button"
            onClick={handleDownloadProjectZip}
            disabled={downloadingZip}
            className="flex min-h-[44px] shrink-0 items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-emerald-500 disabled:opacity-50"
          >
            <Archive className="h-4 w-4" />
            <span>
              {downloadingZip ? 'A empacotar ZIP...' : 'Descarregar Projeto (.ZIP)'}
            </span>
          </button>
        </div>

        {manifest && (
          <div className="mt-3 grid grid-cols-1 gap-2 rounded-lg border border-slate-800 bg-[#050811] p-3 text-xs sm:grid-cols-3">
            <div>
              <span className="block text-[10px] text-slate-400">Pacote Capacitor</span>
              <span className="font-mono font-semibold text-white">
                {manifest.capacitorAppId}
              </span>
            </div>
            <div>
              <span className="block text-[10px] text-slate-400">Projeto Android Nativo</span>
              <span
                className={`font-semibold ${
                  manifest.hasAndroidProject ? 'text-emerald-400' : 'text-amber-300'
                }`}
              >
                {manifest.hasAndroidProject
                  ? 'Pronto (pasta android/ incluída)'
                  : 'Requer npx cap add android'}
              </span>
            </div>
            <div>
              <span className="block text-[10px] text-slate-400">Ficheiros no ZIP</span>
              <span className="font-mono text-slate-200">
                {manifest.totalFiles} ficheiros ·{' '}
                {(manifest.totalBytes / 1024).toFixed(0)} KB
              </span>
            </div>
          </div>
        )}

        <div className="mt-4">
          <label
            htmlFor="apk-backend-url"
            className="mb-1.5 block text-xs font-medium text-slate-300"
          >
            URL do Servidor Backend (Opcional — para uso dentro do APK Android)
          </label>
          <input
            id="apk-backend-url"
            type="url"
            value={apiBaseDraft}
            onChange={(e) => setApiBaseDraft(e.target.value)}
            placeholder="Deixe vazio na Web · Ex. no APK: https://seu-servidor.exemplo"
            className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 font-mono text-xs text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none"
          />
          <p className="mt-1 text-[11px] text-slate-400">
            No APK instalado no telemóvel, este endereço liga a interface Capacitor ao servidor Express (<code>server.ts</code>) onde a <code>GEMINI_API_KEY</code> e o Telegram operam com segurança.
          </p>
        </div>

        <div className="mt-3 rounded-lg border border-slate-800 bg-[#050811] p-3">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
            <FolderCode className="h-3.5 w-3.5 text-blue-400" />
            <span>Comandos reais para gerar o APK (ver BUILD_ANDROID_APK.md no ZIP)</span>
          </div>
          <pre className="mt-2 overflow-x-auto font-mono text-[11px] leading-relaxed text-slate-300">
{`npm install
npm run build
npx cap sync android
cd android && ./gradlew assembleDebug`}
          </pre>
        </div>

        {exportError && (
          <div className="mt-3 rounded-lg border border-red-500/40 bg-red-950/35 px-3 py-2 text-xs text-red-200">
            {exportError}
          </div>
        )}
      </section>

      {saveMsg && (
        <div
          className={`flex items-center gap-2 rounded-xl border px-4 py-3 text-xs ${
            saveMsg.type === 'success'
              ? 'border-emerald-500/40 bg-emerald-950/35 text-emerald-200'
              : 'border-red-500/40 bg-red-950/35 text-red-200'
          }`}
        >
          <CheckCircle2 className="h-4 w-4 shrink-0" />
          <span>{saveMsg.text}</span>
        </div>
      )}

      <div className="flex justify-end">
        <button
          type="submit"
          disabled={saving}
          className="min-h-[48px] w-full rounded-xl bg-blue-600 px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-500 disabled:opacity-50 sm:w-auto"
        >
          {saving ? 'A guardar...' : 'Guardar Configurações'}
        </button>
      </div>
    </form>
  );
}
