import { AlertTriangle, ArrowRight, Camera, FileSpreadsheet, Settings2 } from 'lucide-react';
import type { PairDefinition, Timeframe } from '../types/market.ts';

interface DataUnavailablePanelProps {
  pair: PairDefinition;
  timeframe: Timeframe;
  message: string;
  onOpenImport: () => void;
  onOpenImageAnalyzer: () => void;
  onOpenSettings: () => void;
}

export function DataUnavailablePanel({
  pair,
  timeframe,
  message,
  onOpenImport,
  onOpenImageAnalyzer,
  onOpenSettings,
}: DataUnavailablePanelProps) {
  return (
    <section
      aria-label="Análise OTC não disponível"
      className="rounded-xl border border-slate-800 bg-[#090F1D] p-5 sm:p-7"
    >
      <div className="flex items-start gap-3.5">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-amber-500/30 bg-amber-950/30 text-amber-300">
          <AlertTriangle className="h-5 w-5" />
        </div>
        <div>
          <h2 className="font-display text-lg font-bold text-white">
            Análise OTC não disponível para {pair.symbol} ({timeframe.toUpperCase()})
          </h2>
          <p className="mt-1.5 text-sm leading-relaxed text-slate-300">
            {message}
          </p>
          <p className="mt-2 text-xs leading-relaxed text-slate-400">
            Para garantir integridade total, esta aplicação analisa exclusivamente dados OTC compatíveis e verificáveis do par selecionado ou capturas de ecrã reais do gráfico OTC da Pocket Option.
          </p>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <button
          type="button"
          onClick={onOpenImageAnalyzer}
          className="flex min-h-[48px] items-center justify-between gap-2 rounded-xl border border-blue-500/50 bg-blue-600/20 px-4 py-3 text-left text-xs font-semibold text-white transition-colors hover:bg-blue-600/30"
        >
          <span className="flex items-center gap-2">
            <Camera className="h-4 w-4 text-blue-300 shrink-0" />
            <span>Analisar Captura do Gráfico</span>
          </span>
          <ArrowRight className="h-4 w-4 text-blue-300 shrink-0" />
        </button>

        <button
          type="button"
          onClick={onOpenImport}
          className="flex min-h-[48px] items-center justify-between gap-2 rounded-xl border border-blue-500/35 bg-[#0E1B34] px-4 py-3 text-left text-xs font-semibold text-white transition-colors hover:bg-[#142547]"
        >
          <span className="flex items-center gap-2">
            <FileSpreadsheet className="h-4 w-4 text-blue-400 shrink-0" />
            <span>Importar Velas OTC (CSV)</span>
          </span>
          <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          className="flex min-h-[48px] items-center justify-between gap-2 rounded-xl border border-slate-700 bg-[#0D1322] px-4 py-3 text-left text-xs font-semibold text-slate-100 transition-colors hover:bg-slate-800/80"
        >
          <span className="flex items-center gap-2">
            <Settings2 className="h-4 w-4 text-slate-300 shrink-0" />
            <span>Configurar Bridge OTC</span>
          </span>
          <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
        </button>
      </div>
    </section>
  );
}
