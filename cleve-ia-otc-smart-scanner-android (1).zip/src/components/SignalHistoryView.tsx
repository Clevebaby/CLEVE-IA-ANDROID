import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  Camera,
  Download,
  Minus,
  Send,
  Trash2,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { MARKET_PAIRS } from '../data/pairs.ts';
import type {
  CaptureComparisonSummary,
  ChartImageAnalysisResult,
  SignalDirection,
  SignalOutcome,
  SignalRecord,
  Timeframe,
} from '../types/market.ts';
import { apiUrl } from '../utils/api.ts';
import {
  formatBreakoutLabel,
  formatProximityLabel,
  formatTrendEvolutionLabel,
  formatTrendLabel,
} from '../utils/captureFormatting.ts';
import {
  formatDateTimePT,
  formatTimeHHMMSS,
  strengthToLabel,
} from '../utils/indicators.ts';

interface SignalHistoryViewProps {
  signals: SignalRecord[];
  initialPairId: string;
  initialTimeframe: Timeframe;
  telegramConfigured: boolean;
  onUpdateOutcome: (id: string, outcome: SignalOutcome) => Promise<void>;
  onSendTelegram: (signal: SignalRecord) => Promise<void>;
  onClearHistory: () => Promise<void>;
  onGoToAnalyze: () => void;
}

export function SignalHistoryView({
  signals,
  initialPairId,
  initialTimeframe,
  telegramConfigured,
  onUpdateOutcome,
  onSendTelegram,
  onClearHistory,
  onGoToAnalyze,
}: SignalHistoryViewProps) {
  const [subTab, setSubTab] = useState<'signals' | 'captures'>('signals');
  const [dirFilter, setDirFilter] = useState<'ALL' | SignalDirection>('ALL');
  const [tfFilter, setTfFilter] = useState<'ALL' | '1m' | '5m'>('ALL');
  const [confirmClear, setConfirmClear] = useState(false);
  const [sendingId, setSendingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(
    null
  );

  // Capture history state — strictly isolated by selected OTC pair + timeframe
  const [capturePairId, setCapturePairId] = useState<string>(initialPairId);
  const [captureTimeframe, setCaptureTimeframe] = useState<Timeframe>(initialTimeframe);
  const [captures, setCaptures] = useState<ChartImageAnalysisResult[]>([]);
  const [comparison, setComparison] = useState<CaptureComparisonSummary | null>(null);
  const [loadingCaptures, setLoadingCaptures] = useState(false);
  const [confirmClearCaptures, setConfirmClearCaptures] = useState(false);
  const [sendingCaptureId, setSendingCaptureId] = useState<string | null>(null);

  const loadCaptures = useCallback(async () => {
    setLoadingCaptures(true);
    try {
      const resp = await fetch(
        apiUrl(
          `/api/market/capture-history?pairId=${encodeURIComponent(
            capturePairId
          )}&timeframe=${captureTimeframe}`
        )
      );
      if (!resp.ok) throw new Error('Erro ao carregar histórico de capturas.');
      const data = (await resp.json()) as {
        captures: ChartImageAnalysisResult[];
        comparison: CaptureComparisonSummary;
      };
      setCaptures(data.captures);
      setComparison(data.comparison);
    } catch {
      setCaptures([]);
      setComparison(null);
    } finally {
      setLoadingCaptures(false);
    }
  }, [capturePairId, captureTimeframe]);

  useEffect(() => {
    if (subTab === 'captures') {
      void loadCaptures();
    }
  }, [subTab, loadCaptures]);

  const filtered = useMemo(() => {
    return signals.filter((s) => {
      if (dirFilter !== 'ALL' && s.direction !== dirFilter) return false;
      if (tfFilter !== 'ALL' && s.timeframe !== tfFilter) return false;
      return true;
    });
  }, [signals, dirFilter, tfFilter]);

  const stats = useMemo(() => {
    const directionalSignals = signals.filter(
      (s) => s.direction === 'UP' || s.direction === 'DOWN'
    );
    const total = signals.length;
    const wins = directionalSignals.filter((s) => s.outcome === 'WIN').length;
    const losses = directionalSignals.filter((s) => s.outcome === 'LOSS').length;
    const resolved = wins + losses;
    const rate = resolved > 0 ? Math.round((wins / resolved) * 100) : null;
    return { total, signalCount: directionalSignals.length, wins, losses, rate };
  }, [signals]);

  const handleExportCsv = () => {
    const header = [
      'Data',
      'Par',
      'Timeframe',
      'Direcao',
      'Forca',
      'Confianca_%',
      'Cotacao',
      'Entrada_Estimada',
      'Modo',
      'Resultado_Manual',
      'Fonte',
    ].join(',');

    const rows = filtered.map((s) =>
      [
        new Date(s.createdAtMs).toISOString(),
        `"${s.pairSymbol}"`,
        s.timeframe.toUpperCase(),
        s.direction,
        strengthToLabel(s.strength),
        s.confidence,
        s.priceAtSignal,
        formatTimeHHMMSS(s.entryTimeMs),
        s.mode,
        s.direction === 'NEUTRO' ? 'ANALISE_NEUTRA' : s.outcome,
        `"${s.sourceProvider}"`,
      ].join(',')
    );

    const blob = new Blob([[header, ...rows].join('\n')], {
      type: 'text/csv;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pocket-ai-pro-otc-historico.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleSend = async (sig: SignalRecord) => {
    setSendingId(sig.id);
    setFeedback(null);
    try {
      await onSendTelegram(sig);
      setFeedback({
        type: 'success',
        message: `Sinal válido ${sig.pairSymbol} enviado para o Telegram.`,
      });
    } catch (err) {
      setFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Erro ao enviar para o Telegram.',
      });
    } finally {
      setSendingId(null);
    }
  };

  const handleSendCaptureTelegram = async (cap: ChartImageAnalysisResult) => {
    setSendingCaptureId(cap.id);
    setFeedback(null);
    try {
      const resp = await fetch(apiUrl('/api/telegram/send-image-analysis'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ analysis: cap }),
      });
      const data = (await resp.json()) as { ok?: boolean; error?: string };
      if (!resp.ok || !data.ok) {
        throw new Error(data.error || 'Erro ao enviar captura para o Telegram.');
      }
      setFeedback({
        type: 'success',
        message: `Análise da captura ${cap.pairSymbol} (${cap.timeframe.toUpperCase()}) enviada para o Telegram.`,
      });
    } catch (err) {
      setFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Erro ao enviar para o Telegram.',
      });
    } finally {
      setSendingCaptureId(null);
    }
  };

  const handleClearPairCaptures = async () => {
    const resp = await fetch(
      apiUrl(
        `/api/market/capture-history?pairId=${encodeURIComponent(
          capturePairId
        )}&timeframe=${captureTimeframe}`
      ),
      { method: 'DELETE' }
    );
    if (resp.ok) {
      setConfirmClearCaptures(false);
      await loadCaptures();
    }
  };

  const evolutionMeta = comparison
    ? formatTrendEvolutionLabel(comparison.trendEvolution)
    : null;

  return (
    <div className="space-y-4">
      {/* Header & Section Switcher */}
      <div className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-display text-xl font-bold text-white">
              Histórico de Análises e Capturas
            </h1>
            <p className="mt-0.5 text-xs text-slate-400">
              Registo persistente das análises OHLC e comparação isolada de capturas por par e período.
            </p>
          </div>

          <div
            role="tablist"
            aria-label="Tipo de histórico"
            className="flex items-center rounded-lg border border-slate-800 bg-[#050811] p-1"
          >
            <button
              type="button"
              role="tab"
              aria-selected={subTab === 'signals'}
              onClick={() => {
                setSubTab('signals');
                setFeedback(null);
              }}
              className={`min-h-[40px] flex-1 rounded-md px-3.5 text-xs font-semibold whitespace-nowrap transition-colors sm:flex-initial ${
                subTab === 'signals'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Sinais OHLC ({signals.length})
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={subTab === 'captures'}
              onClick={() => {
                setSubTab('captures');
                setFeedback(null);
              }}
              className={`min-h-[40px] flex-1 rounded-md px-3.5 text-xs font-semibold whitespace-nowrap transition-colors sm:flex-initial ${
                subTab === 'captures'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Histórico de Capturas
            </button>
          </div>
        </div>
      </div>

      {feedback && (
        <div
          className={`rounded-lg border px-3 py-2 text-xs ${
            feedback.type === 'success'
              ? 'border-emerald-500/40 bg-emerald-950/35 text-emerald-200'
              : 'border-red-500/40 bg-red-950/35 text-red-200'
          }`}
        >
          {feedback.message}
        </div>
      )}

      {subTab === 'signals' ? (
        <>
          {/* Signals Actions Bar */}
          {signals.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center rounded-lg border border-slate-800 bg-[#090F1D] p-1">
                  {(['ALL', 'UP', 'DOWN', 'NEUTRO'] as const).map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDirFilter(d)}
                      className={`min-h-[36px] rounded-md px-3 text-xs font-semibold transition-colors ${
                        dirFilter === d
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {d === 'ALL' ? 'Todos' : d}
                    </button>
                  ))}
                </div>

                <div className="flex items-center rounded-lg border border-slate-800 bg-[#090F1D] p-1">
                  {(['ALL', '1m', '5m'] as const).map((tf) => (
                    <button
                      key={tf}
                      type="button"
                      onClick={() => setTfFilter(tf)}
                      className={`min-h-[36px] rounded-md px-3 text-xs font-semibold transition-colors ${
                        tfFilter === tf
                          ? 'bg-[#162747] text-blue-200'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {tf === 'ALL' ? '1M & 5M' : tf.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleExportCsv}
                  className="flex min-h-[44px] items-center gap-1.5 rounded-lg border border-slate-700 bg-[#0D1526] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800"
                >
                  <Download className="h-4 w-4" />
                  <span>Exportar CSV</span>
                </button>

                {!confirmClear ? (
                  <button
                    type="button"
                    onClick={() => setConfirmClear(true)}
                    className="flex min-h-[44px] items-center gap-1.5 rounded-lg border border-red-500/35 bg-red-950/25 px-3.5 py-2 text-xs font-semibold text-red-300 hover:bg-red-950/45"
                  >
                    <Trash2 className="h-4 w-4" />
                    <span>Limpar</span>
                  </button>
                ) : (
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={async () => {
                        await onClearHistory();
                        setConfirmClear(false);
                      }}
                      className="min-h-[44px] rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white hover:bg-red-500"
                    >
                      Confirmar limpeza
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClear(false)}
                      className="min-h-[44px] rounded-lg border border-slate-700 px-3 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800"
                    >
                      Cancelar
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Summary Metrics */}
          {signals.length > 0 && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl border border-slate-800/80 bg-[#090F1D] p-3.5">
                <span className="text-xs text-slate-400">Análises Guardadas</span>
                <p className="mt-1 font-mono text-xl font-bold tabular-nums text-white">
                  {stats.total}
                </p>
              </div>
              <div className="rounded-xl border border-slate-800/80 bg-[#090F1D] p-3.5">
                <span className="text-xs text-slate-400">WIN (Manual)</span>
                <p className="mt-1 font-mono text-xl font-bold tabular-nums text-emerald-400">
                  {stats.wins}
                </p>
              </div>
              <div className="rounded-xl border border-slate-800/80 bg-[#090F1D] p-3.5">
                <span className="text-xs text-slate-400">LOSS (Manual)</span>
                <p className="mt-1 font-mono text-xl font-bold tabular-nums text-red-400">
                  {stats.losses}
                </p>
              </div>
              <div className="rounded-xl border border-slate-800/80 bg-[#090F1D] p-3.5">
                <span className="text-xs text-slate-400">Taxa Observada</span>
                <p className="mt-1 font-mono text-xl font-bold tabular-nums text-blue-300">
                  {stats.rate !== null ? `${stats.rate}%` : '—'}
                </p>
              </div>
            </div>
          )}

          {/* Empty State or List */}
          {signals.length === 0 ? (
            <div className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-8 text-center">
              <h2 className="font-display text-base font-bold text-white">
                Nenhuma análise OTC registada no histórico
              </h2>
              <p className="mx-auto mt-1.5 max-w-md text-xs leading-relaxed text-slate-400">
                Selecione um par OTC na aba Analisar com uma fonte compatível ou velas OTC importadas para gerar e guardar automaticamente o histórico das análises e sinais.
              </p>
              <button
                type="button"
                onClick={onGoToAnalyze}
                className="mt-4 min-h-[44px] rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white hover:bg-blue-500"
              >
                Ir para Análise OTC
              </button>
            </div>
          ) : filtered.length === 0 ? (
            <div className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-6 text-center text-xs text-slate-400">
              Nenhum registo corresponde aos filtros selecionados.
            </div>
          ) : (
            <div className="space-y-2.5">
              {filtered.map((sig) => {
                const isUp = sig.direction === 'UP';
                const isDown = sig.direction === 'DOWN';
                const isValidSignal = isUp || isDown;

                return (
                  <article
                    key={sig.id}
                    className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4"
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`inline-flex items-center gap-1 font-mono text-sm font-bold ${
                              isUp
                                ? 'text-emerald-400'
                                : isDown
                                  ? 'text-red-400'
                                  : 'text-slate-400'
                            }`}
                          >
                            {isUp ? (
                              <ArrowUpRight className="h-4 w-4" />
                            ) : isDown ? (
                              <ArrowDownRight className="h-4 w-4" />
                            ) : (
                              <Minus className="h-4 w-4" />
                            )}
                            {sig.direction}
                          </span>
                          <span className="font-display text-sm font-bold text-white">
                            {sig.pairSymbol}
                          </span>
                          <span className="font-mono text-xs text-slate-400">
                            {sig.timeframe.toUpperCase()} · {formatTimeHHMMSS(sig.entryTimeMs)}
                          </span>
                        </div>

                        <p className="mt-1 text-xs text-slate-400">
                          Força:{' '}
                          <span className="text-slate-200">
                            {strengthToLabel(sig.strength)}
                          </span>
                          {' · '}
                          Confiança est.:{' '}
                          <span className="font-mono text-slate-200">{sig.confidence}%</span>
                          {' · '}
                          Modo:{' '}
                          <span className="text-slate-200">
                            {sig.mode === 'DEMO' ? 'DEMO' : 'Real'}
                          </span>
                          {' · '}
                          {sig.sourceProvider}
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {isValidSignal ? (
                          <>
                            <div className="flex items-center rounded-lg border border-slate-800 bg-[#050811] p-0.5">
                              {(['PENDENTE', 'WIN', 'LOSS', 'EMPATE'] as SignalOutcome[]).map(
                                (out) => {
                                  const active = sig.outcome === out;
                                  let activeStyle = 'bg-slate-700 text-white';
                                  if (out === 'WIN' && active)
                                    activeStyle = 'bg-emerald-600 text-white';
                                  if (out === 'LOSS' && active)
                                    activeStyle = 'bg-red-600 text-white';
                                  if (out === 'EMPATE' && active)
                                    activeStyle = 'bg-blue-600 text-white';
                                  return (
                                    <button
                                      key={out}
                                      type="button"
                                      onClick={() => onUpdateOutcome(sig.id, out)}
                                      className={`min-h-[36px] rounded-md px-2.5 text-[11px] font-semibold transition-colors ${
                                        active
                                          ? activeStyle
                                          : 'text-slate-400 hover:text-slate-200'
                                      }`}
                                    >
                                      {out}
                                    </button>
                                  );
                                }
                              )}
                            </div>

                            <button
                              type="button"
                              onClick={() => handleSend(sig)}
                              disabled={!telegramConfigured || sendingId === sig.id}
                              title={
                                telegramConfigured
                                  ? 'Enviar este sinal válido para o Telegram'
                                  : 'Configure o Telegram nas Configurações'
                              }
                              className="flex min-h-[38px] items-center gap-1.5 rounded-lg border border-blue-500/35 bg-[#0F1E3A] px-3 text-xs font-semibold text-blue-200 hover:bg-[#172B52] disabled:cursor-not-allowed disabled:opacity-45"
                            >
                              <Send className="h-3.5 w-3.5" />
                              <span>{sig.telegramSent ? 'Reenviar' : 'Telegram'}</span>
                            </button>
                          </>
                        ) : (
                          <span className="text-xs text-slate-400">
                            Análise sem confluência direcional
                          </span>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </>
      ) : (
        /* Isolated Per-Pair & Per-Timeframe Capture History Comparison */
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4">
            <p className="text-xs font-semibold text-slate-300">
              Selecionar par OTC e período exclusivos para comparação (nunca mistura pares ou períodos diferentes)
            </p>

            <div className="mt-2.5 grid grid-cols-2 gap-2 sm:flex sm:flex-wrap">
              {MARKET_PAIRS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setCapturePairId(p.id);
                    setConfirmClearCaptures(false);
                  }}
                  className={`min-h-[42px] rounded-lg border px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                    capturePairId === p.id
                      ? 'border-blue-500 bg-blue-600 text-white'
                      : 'border-slate-800 bg-[#050811] text-slate-300 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  {p.symbol}
                </button>
              ))}
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/80 pt-3">
              <div className="flex items-center rounded-lg border border-slate-800 bg-[#050811] p-1">
                {(['1m', '5m'] as Timeframe[]).map((tf) => (
                  <button
                    key={tf}
                    type="button"
                    onClick={() => {
                      setCaptureTimeframe(tf);
                      setConfirmClearCaptures(false);
                    }}
                    className={`min-h-[36px] rounded-md px-3.5 text-xs font-bold transition-colors ${
                      captureTimeframe === tf
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {tf === '1m' ? '1 Minuto' : '5 Minutos'}
                  </button>
                ))}
              </div>

              {captures.length > 0 && (
                <div>
                  {!confirmClearCaptures ? (
                    <button
                      type="button"
                      onClick={() => setConfirmClearCaptures(true)}
                      className="flex min-h-[40px] items-center gap-1.5 rounded-lg border border-red-500/35 bg-red-950/25 px-3 py-1.5 text-xs font-semibold text-red-300 hover:bg-red-950/45"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>Limpar capturas deste par</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={handleClearPairCaptures}
                        className="min-h-[40px] rounded-lg bg-red-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-red-500"
                      >
                        Confirmar
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmClearCaptures(false)}
                        className="min-h-[40px] rounded-lg border border-slate-700 px-3 py-1.5 text-xs text-slate-300"
                      >
                        Cancelar
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Trend Strengthening / Weakening Comparison Panel */}
          {comparison && (
            <div className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="text-[11px] text-slate-400">
                    Evolução da Tendência · {comparison.pairSymbol} ({comparison.timeframe.toUpperCase()})
                  </span>
                  <h2 className={`font-display text-base font-bold ${evolutionMeta?.toneClass}`}>
                    {evolutionMeta?.label}
                  </h2>
                </div>
                <span className="font-mono text-xs text-slate-400">
                  {comparison.totalCaptures}{' '}
                  {comparison.totalCaptures === 1 ? 'captura fiável' : 'capturas fiáveis'}
                </span>
              </div>
              <p className="mt-1.5 text-xs leading-relaxed text-slate-300">
                {comparison.summary}
              </p>
            </div>
          )}

          {loadingCaptures ? (
            <div className="h-40 rounded-xl border border-slate-800/80 bg-[#090F1D] animate-pulse" />
          ) : captures.length === 0 ? (
            <div className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-8 text-center">
              <Camera className="mx-auto h-7 w-7 text-slate-500" />
              <h3 className="mt-2 font-display text-sm font-bold text-white">
                Sem capturas guardadas para este par e período
              </h3>
              <p className="mx-auto mt-1 max-w-md text-xs text-slate-400">
                Na aba Analisar, toque em Analisar Imagem para carregar capturas de ecrã da Pocket Option OTC e acompanhar a evolução da tendência aqui.
              </p>
              <button
                type="button"
                onClick={onGoToAnalyze}
                className="mt-4 min-h-[44px] rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white hover:bg-blue-500"
              >
                Analisar Captura Agora
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {captures.map((cap, idx) => (
                <article
                  key={cap.id}
                  className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4"
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div className="space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-400">
                          #{idx + 1}
                        </span>
                        <span
                          className={`inline-flex items-center gap-1 font-mono text-sm font-bold ${
                            cap.direction === 'UP'
                              ? 'text-emerald-400'
                              : cap.direction === 'DOWN'
                                ? 'text-red-400'
                                : 'text-slate-300'
                          }`}
                        >
                          {cap.direction === 'UP' ? (
                            <ArrowUpRight className="h-4 w-4" />
                          ) : cap.direction === 'DOWN' ? (
                            <ArrowDownRight className="h-4 w-4" />
                          ) : (
                            <Minus className="h-4 w-4" />
                          )}
                          {cap.direction === 'NEUTRO'
                            ? 'NEUTRO — AGUARDAR'
                            : cap.direction}
                        </span>
                        <span className="font-display text-sm font-bold text-white">
                          {cap.pairSymbol}
                        </span>
                        <span className="font-mono text-xs text-slate-400">
                          {cap.timeframe.toUpperCase()} · {formatDateTimePT(cap.analyzedAtMs)}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-300">
                        <span className="inline-flex items-center gap-1">
                          {cap.trend === 'ALTA' && (
                            <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
                          )}
                          {cap.trend === 'BAIXA' && (
                            <TrendingDown className="h-3.5 w-3.5 text-red-400" />
                          )}
                          {cap.trend === 'LATERAL' && (
                            <Activity className="h-3.5 w-3.5 text-sky-400" />
                          )}
                          Tendência: <strong>{formatTrendLabel(cap.trend)}</strong>
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>
                          Confiança est.: <strong className="font-mono">{cap.confidence}%</strong>
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono">
                          {cap.greenCandlesCount}V / {cap.redCandlesCount}R
                        </span>
                      </div>

                      <p className="text-xs text-slate-300">{cap.lastCandlesSequence}</p>
                      <p className="text-[11px] text-slate-400">
                        {formatProximityLabel(cap.supportResistance.priceProximity)} ·{' '}
                        {formatBreakoutLabel(cap.supportResistance.breakoutStatus)}
                      </p>
                      <p className="text-xs leading-relaxed text-slate-400">{cap.rationale}</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleSendCaptureTelegram(cap)}
                      disabled={!telegramConfigured || sendingCaptureId === cap.id}
                      title={
                        telegramConfigured
                          ? 'Enviar análise desta captura para o Telegram'
                          : 'Configure Bot Token e Chat ID nas Configurações'
                      }
                      className="flex min-h-[42px] shrink-0 items-center justify-center gap-1.5 rounded-lg border border-blue-500/35 bg-[#0F1E3A] px-3.5 text-xs font-semibold text-blue-200 hover:bg-[#172B52] disabled:cursor-not-allowed disabled:opacity-45"
                    >
                      <Send className="h-3.5 w-3.5" />
                      <span>
                        {sendingCaptureId === cap.id ? 'A enviar...' : 'Enviar Telegram'}
                      </span>
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
