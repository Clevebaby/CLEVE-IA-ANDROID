import { ArrowDownRight, ArrowUpRight, Minus, RefreshCw } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { MARKET_PAIRS } from '../data/pairs.ts';
import type { ScannerOpportunity, Timeframe } from '../types/market.ts';
import { apiUrl } from '../utils/api.ts';
import { strengthToLabel } from '../utils/indicators.ts';

interface OpportunitiesScannerProps {
  timeframe: Timeframe;
  onChangeTimeframe: (tf: Timeframe) => void;
  onInspectPair: (pairId: string) => void;
}

export function OpportunitiesScanner({
  timeframe,
  onChangeTimeframe,
  onInspectPair,
}: OpportunitiesScannerProps) {
  const [selectedPairIds, setSelectedPairIds] = useState<string[]>(() =>
    MARKET_PAIRS.map((p) => p.id)
  );
  const [opportunities, setOpportunities] = useState<ScannerOpportunity[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const togglePairSelection = (pairId: string) => {
    setSelectedPairIds((prev) => {
      if (prev.includes(pairId)) {
        return prev.length > 1 ? prev.filter((id) => id !== pairId) : prev;
      }
      return [...prev, pairId];
    });
  };

  const loadScanner = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const resp = await fetch(
        apiUrl(
          `/api/market/scanner?timeframe=${timeframe}&pairIds=${encodeURIComponent(
            selectedPairIds.join(',')
          )}`
        )
      );
      if (!resp.ok) throw new Error('Falha ao consultar pares OTC.');
      const data = (await resp.json()) as { opportunities: ScannerOpportunity[] };
      setOpportunities(data.opportunities);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao atualizar oportunidades OTC.');
    } finally {
      setLoading(false);
    }
  }, [timeframe, selectedPairIds]);

  useEffect(() => {
    loadScanner();
  }, [loadScanner]);

  const sorted = [...opportunities].sort((a, b) => {
    if (a.available !== b.available) return a.available ? -1 : 1;
    if (a.isStale !== b.isStale) return a.isStale ? 1 : -1;
    return b.confidence - a.confidence;
  });

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4 space-y-3.5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-display text-xl font-bold text-white">
              Oportunidades OTC
            </h1>
            <p className="mt-0.5 text-xs text-slate-400">
              Escolha manualmente os pares OTC que deseja verificar com RSI, MACD, EMA 9/21 e padrões de velas.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center rounded-lg border border-slate-800 bg-[#050811] p-1">
              {(['1m', '5m'] as Timeframe[]).map((tf) => (
                <button
                  key={tf}
                  type="button"
                  onClick={() => onChangeTimeframe(tf)}
                  className={`min-h-[36px] rounded-md px-3 text-xs font-semibold transition-colors ${
                    timeframe === tf
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tf.toUpperCase()}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={loadScanner}
              disabled={loading}
              className="flex min-h-[44px] items-center gap-1.5 rounded-lg border border-slate-700 bg-[#0D1526] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800 disabled:opacity-50"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Atualizar</span>
            </button>
          </div>
        </div>

        {/* Manual Multi-Pair OTC Filter */}
        <div className="flex flex-wrap items-center gap-2 border-t border-slate-800/80 pt-3">
          {MARKET_PAIRS.map((pair) => {
            const active = selectedPairIds.includes(pair.id);
            return (
              <button
                key={pair.id}
                type="button"
                onClick={() => togglePairSelection(pair.id)}
                className={`min-h-[38px] rounded-lg border px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                  active
                    ? 'border-blue-500/60 bg-[#0E1E3C] text-blue-100'
                    : 'border-slate-800 bg-[#050811] text-slate-400 hover:text-slate-200'
                }`}
              >
                {pair.symbol}
              </button>
            );
          })}
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-red-500/40 bg-red-950/30 p-4 text-xs text-red-200">
          {error}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: selectedPairIds.length }).map((_, idx) => (
            <div
              key={idx}
              className="h-36 rounded-xl border border-slate-800/80 bg-[#090F1D] p-4 animate-pulse"
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
          {sorted.map((item) => {
            const isUp = item.available && !item.isStale && item.direction === 'UP';
            const isDown = item.available && !item.isStale && item.direction === 'DOWN';

            return (
              <button
                key={item.pair.id}
                type="button"
                onClick={() => onInspectPair(item.pair.id)}
                className="flex flex-col justify-between rounded-xl border border-slate-800/90 bg-[#090F1D] p-4 text-left transition-colors hover:border-blue-500/50 hover:bg-[#0D1629]"
              >
                <div className="flex w-full items-start justify-between gap-2">
                  <div>
                    <h2 className="font-display text-base font-bold text-white">
                      {item.pair.displayName}
                    </h2>
                    <p className="mt-0.5 text-[11px] text-slate-400">
                      {item.sourceProvider}
                    </p>
                  </div>

                  {!item.available ? (
                    <span className="text-xs font-medium text-amber-300 whitespace-nowrap">
                      OTC indisponível
                    </span>
                  ) : item.isStale ? (
                    <span className="text-xs font-medium text-slate-400 whitespace-nowrap">
                      Sem atualização
                    </span>
                  ) : isUp ? (
                    <span className="inline-flex items-center gap-1 font-mono text-xs font-bold text-emerald-400 whitespace-nowrap">
                      <ArrowUpRight className="h-4 w-4" />
                      UP {item.confidence}%
                    </span>
                  ) : isDown ? (
                    <span className="inline-flex items-center gap-1 font-mono text-xs font-bold text-red-400 whitespace-nowrap">
                      <ArrowDownRight className="h-4 w-4" />
                      DOWN {item.confidence}%
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 font-mono text-xs font-medium text-slate-400 whitespace-nowrap">
                      <Minus className="h-3.5 w-3.5" />
                      NEUTRO
                    </span>
                  )}
                </div>

                {item.available && item.currentPrice !== null ? (
                  <div className="mt-4 flex w-full items-end justify-between border-t border-slate-800/80 pt-3 font-mono text-xs tabular-nums">
                    <div>
                      <span className="block text-[10px] text-slate-400">Cotação OTC</span>
                      <span className="font-semibold text-white">
                        {item.currentPrice.toFixed(item.pair.decimals)}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[10px] text-slate-400">RSI</span>
                      <span className="text-slate-200">
                        {item.rsi !== null ? item.rsi.toFixed(1) : '—'}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="block text-[10px] text-slate-400">Força</span>
                      <span className="text-slate-200">
                        {strengthToLabel(item.strength)}
                      </span>
                    </div>
                  </div>
                ) : (
                  <p className="mt-4 border-t border-slate-800/80 pt-3 text-[11px] text-slate-400">
                    Análise OTC não disponível. Toque para importar velas OTC ou configurar fonte compatível.
                  </p>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
