import {
  ArrowDownRight,
  ArrowUpRight,
  BookmarkPlus,
  Clock,
  Minus,
  Send,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import type { AnalysisResult, TradingMode } from '../types/market.ts';
import {
  formatDateTimePT,
  formatTimeHHMMSS,
  strengthToLabel,
} from '../utils/indicators.ts';

interface SignalCardProps {
  analysis: AnalysisResult;
  mode: TradingMode;
  minConfidence: number;
  telegramConfigured: boolean;
  onSaveToHistory: () => Promise<void>;
  onSendTelegram: () => Promise<void>;
  savingHistory: boolean;
  sendingTelegram: boolean;
  actionFeedback: { type: 'success' | 'error'; message: string } | null;
}

export function SignalCard({
  analysis,
  mode,
  minConfidence,
  telegramConfigured,
  onSaveToHistory,
  onSendTelegram,
  savingHistory,
  sendingTelegram,
  actionFeedback,
}: SignalCardProps) {
  const [countdownSec, setCountdownSec] = useState<number>(
    analysis.entryEstimate?.secondsUntilEntry ?? 0
  );

  useEffect(() => {
    const intervalMs = analysis.timeframe === '1m' ? 60_000 : 300_000;
    const update = () => {
      if (!analysis.entryEstimate) {
        setCountdownSec(0);
        return;
      }
      if (
        analysis.entryEstimate.timingStatus === 'DADOS_HISTORICOS' ||
        analysis.source.isStale
      ) {
        setCountdownSec(0);
        return;
      }
      const now = Date.now();
      const nextBoundary = Math.ceil(now / intervalMs) * intervalMs;
      setCountdownSec(Math.max(0, Math.ceil((nextBoundary - now) / 1000)));
    };
    update();
    const timer = window.setInterval(update, 1000);
    return () => window.clearInterval(timer);
  }, [analysis.entryEstimate, analysis.timeframe, analysis.source.isStale]);

  const isUp = analysis.direction === 'UP';
  const isDown = analysis.direction === 'DOWN';

  const verdictColorClass = isUp
    ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300'
    : isDown
      ? 'border-red-500/40 bg-red-950/30 text-red-300'
      : 'border-slate-700/80 bg-[#0D1526] text-slate-200';

  const canAct =
    (isUp || isDown) && !analysis.source.isStale && analysis.source.available;
  const meetsTelegramThreshold = canAct && analysis.confidence >= minConfidence;
  const lastUpdateMs = analysis.source.importedAtMs ?? analysis.source.fetchedAtMs;

  return (
    <section
      aria-label="Resultado da análise técnica"
      className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-4 sm:p-5"
    >
      {/* Primary Signal Verdict */}
      <div className={`rounded-xl border p-4 ${verdictColorClass}`}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-medium text-slate-300">
              Sinal Analítico · {analysis.pair.symbol} · {analysis.timeframe.toUpperCase()}
            </p>
            <div className="mt-1.5 flex items-center gap-2.5">
              {isUp ? (
                <ArrowUpRight className="h-7 w-7 text-emerald-400 shrink-0" />
              ) : isDown ? (
                <ArrowDownRight className="h-7 w-7 text-red-400 shrink-0" />
              ) : (
                <Minus className="h-6 w-6 text-slate-400 shrink-0" />
              )}
              <h2 className="font-display text-2xl font-extrabold tracking-tight text-white">
                {isUp
                  ? 'UP · COMPRA'
                  : isDown
                    ? 'DOWN · VENDA'
                    : 'NEUTRO · AGUARDAR'}
              </h2>
            </div>
          </div>

          <div className="text-right font-mono tabular-nums">
            <span className="block text-[11px] text-slate-400">Confiança est.</span>
            <span className="text-2xl font-bold text-white">{analysis.confidence}%</span>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-300">
          <span>
            Força:{' '}
            <strong className="font-semibold text-white">
              {strengthToLabel(analysis.strength)}
            </strong>
          </span>
          <span aria-hidden="true">·</span>
          <span>
            Modo:{' '}
            <strong className="font-semibold text-white">
              {mode === 'DEMO' ? 'DEMO' : 'Análise Real'}
            </strong>
          </span>
          <span aria-hidden="true">·</span>
          <span>Sem execução automática</span>
        </div>
      </div>

      {/* Estimated Entry Timing */}
      {analysis.entryEstimate && (
        <div className="mt-4 rounded-xl border border-blue-900/50 bg-[#0C172B] p-3.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-300">
              <Clock className="h-4 w-4 shrink-0" />
              <span>Melhor Momento Estimado para Entrada</span>
            </div>
            {countdownSec > 0 && (
              <span className="font-mono text-xs font-semibold tabular-nums text-blue-200">
                Faltam {countdownSec}s
              </span>
            )}
          </div>

          <div className="mt-2 flex items-baseline justify-between gap-3">
            <p className="text-sm font-semibold text-white">
              {analysis.entryEstimate.label}
            </p>
            <span className="font-mono text-sm font-bold tabular-nums text-blue-300">
              {formatTimeHHMMSS(analysis.entryEstimate.nextEntryTimeMs)}
            </span>
          </div>
          <p className="mt-1 text-xs leading-relaxed text-slate-300">
            {analysis.entryEstimate.detail}
          </p>
        </div>
      )}

      {/* Rationale */}
      <p className="mt-3.5 text-xs leading-relaxed text-slate-300">
        {analysis.rationale}
      </p>

      {/* Technical Indicators Breakdown */}
      <div className="mt-4 divide-y divide-slate-800/80 border-t border-slate-800/80">
        {analysis.factors.map((factor) => {
          const biasColor =
            factor.bias === 'UP'
              ? 'text-emerald-400'
              : factor.bias === 'DOWN'
                ? 'text-red-400'
                : 'text-slate-400';
          return (
            <div key={factor.id} className="py-2.5">
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="font-medium text-slate-200">{factor.label}</span>
                <div className="flex items-center gap-2 font-mono tabular-nums">
                  <span className="text-slate-300">{factor.valueText}</span>
                  <span className={`font-semibold ${biasColor}`}>
                    {factor.bias === 'UP'
                      ? '▲ UP'
                      : factor.bias === 'DOWN'
                        ? '▼ DOWN'
                        : '• NEUTRO'}
                  </span>
                </div>
              </div>
              <p className="mt-0.5 text-[11px] text-slate-400">{factor.summary}</p>
            </div>
          );
        })}
      </div>

      <div className="mt-3 rounded-lg border border-slate-800/80 bg-[#060A14] px-3 py-2 text-[11px] text-slate-300 space-y-1">
        <div className="flex items-center justify-between gap-2">
          <span className="text-slate-400">Última atualização dos dados:</span>
          <span className="font-mono tabular-nums text-slate-200">
            {formatDateTimePT(lastUpdateMs)}
          </span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <span className="text-slate-400">Condições para alerta Telegram:</span>
          <span
            className={`font-semibold ${
              meetsTelegramThreshold ? 'text-emerald-400' : 'text-slate-400'
            }`}
          >
            {meetsTelegramThreshold
              ? `Suficientes (≥ ${minConfidence}%)`
              : `Insuficientes (mín. ${minConfidence}%)`}
          </span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
        <button
          type="button"
          onClick={onSaveToHistory}
          disabled={!canAct || savingHistory}
          className="flex min-h-[44px] items-center justify-center gap-2 rounded-lg border border-blue-500/40 bg-[#10203F] px-4 py-2 text-xs font-semibold text-blue-100 transition-colors hover:bg-[#162C56] disabled:cursor-not-allowed disabled:opacity-45"
        >
          <BookmarkPlus className="h-4 w-4" />
          <span>{savingHistory ? 'A guardar...' : 'Registar no Histórico'}</span>
        </button>

        <button
          type="button"
          onClick={onSendTelegram}
          disabled={!canAct || !telegramConfigured || sendingTelegram}
          title={
            !telegramConfigured
              ? 'Configure o Bot Token e Chat ID do Telegram nas Configurações'
              : 'Enviar alerta formatado para o Telegram'
          }
          className="flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-45"
        >
          <Send className="h-4 w-4" />
          <span>{sendingTelegram ? 'A enviar...' : 'Enviar para Telegram'}</span>
        </button>
      </div>

      {!telegramConfigured && (
        <p className="mt-2 text-[11px] text-slate-400">
          Integração Telegram disponível em Configurações (Bot Token + Chat ID).
        </p>
      )}

      {actionFeedback && (
        <div
          className={`mt-3 rounded-lg border px-3 py-2 text-xs ${
            actionFeedback.type === 'success'
              ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-200'
              : 'border-red-500/40 bg-red-950/40 text-red-200'
          }`}
        >
          {actionFeedback.message}
        </div>
      )}

      <p className="mt-4 border-t border-slate-800/80 pt-3 text-[11px] leading-relaxed text-slate-400">
        Aviso de risco: Estimativa técnica baseada exclusivamente em indicadores históricos e atuais. Não garante lucros nem taxa de acerto. O sistema não executa ordens automaticamente.
      </p>
    </section>
  );
}
