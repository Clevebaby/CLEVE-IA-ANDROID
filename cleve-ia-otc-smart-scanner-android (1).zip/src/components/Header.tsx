import type { TradingMode } from '../types/market.ts';

export type AppTab = 'analyze' | 'scanner' | 'history' | 'settings';

interface HeaderProps {
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  mode: TradingMode;
  onToggleMode: () => void;
}

const NAV_ITEMS: Array<{ id: AppTab; label: string }> = [
  { id: 'analyze', label: 'Analisar' },
  { id: 'scanner', label: 'Oportunidades' },
  { id: 'history', label: 'Histórico' },
  { id: 'settings', label: 'Configurações' },
];

export function Header({ activeTab, onSelectTab, mode, onToggleMode }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-[#05070B]/95 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 sm:h-16 sm:gap-8 sm:px-6">
        <button
          type="button"
          onClick={() => onSelectTab('analyze')}
          className="font-display text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 sm:text-lg"
        >
          POCKET AI PRO OTC
        </button>

        <nav
          aria-label="Navegação principal"
          className="hidden items-center gap-6 md:flex"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`relative py-2 text-sm font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  isActive
                    ? 'text-white'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {item.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-[1px] h-0.5 bg-blue-500"
                  />
                )}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onToggleMode}
            title="Alternar entre Modo DEMO e Modo Análise Real (sem execução automática)"
            className={`min-h-[40px] rounded-lg border px-3.5 py-2 text-xs font-semibold tracking-wide whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
              mode === 'DEMO'
                ? 'border-blue-500/40 bg-[#0D182E] text-blue-300 hover:bg-[#132342]'
                : 'border-emerald-500/40 bg-emerald-950/50 text-emerald-300 hover:bg-emerald-950/80'
            }`}
          >
            {mode === 'DEMO' ? 'Modo DEMO' : 'Análise Real'}
          </button>
        </div>
      </div>
    </header>
  );
}
