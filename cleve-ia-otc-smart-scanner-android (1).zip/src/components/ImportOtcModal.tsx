import { AlertCircle, CheckCircle2, Download, Upload, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { PairDefinition, Timeframe } from '../types/market.ts';
import { apiUrl } from '../utils/api.ts';
import { formatDateTimePT } from '../utils/indicators.ts';
import { validateAndParseOtcInput } from '../utils/otcParser.ts';

interface ImportOtcModalProps {
  isOpen: boolean;
  onClose: () => void;
  pair: PairDefinition;
  timeframe: Timeframe;
  onImported: () => void;
}

export function ImportOtcModal({
  isOpen,
  onClose,
  pair,
  timeframe,
  onImported,
}: ImportOtcModalProps) {
  const [rawData, setRawData] = useState('');
  const [label, setLabel] = useState(`Pocket Option ${pair.symbol}`);
  const [confirmedOtcSource, setConfirmedOtcSource] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const previewValidation = useMemo(() => {
    if (!rawData.trim()) return null;
    return validateAndParseOtcInput(rawData, pair.symbol);
  }, [rawData, pair.symbol]);

  if (!isOpen) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    setRawData(text);
    setLabel(file.name.replace(/\.(csv|json|txt)$/i, ''));
    setError(null);
  };

  const handleDownloadHeaderTemplate = () => {
    const header = 'data,hora,abertura,maxima,minima,fecho\n';
    const blob = new Blob([header], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `modelo-velas-otc-${pair.id.toLowerCase()}-${timeframe}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmedOtcSource) {
      setError('Confirme que os dados pertencem exclusivamente a cotações OTC reais.');
      return;
    }
    if (!previewValidation || !previewValidation.valid) {
      setError(
        previewValidation?.errors.join(' ') ||
          'Valide os dados CSV antes de iniciar a análise.'
      );
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const resp = await fetch(apiUrl('/api/market/import-otc'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pairId: pair.id,
          timeframe,
          rawData,
          label,
        }),
      });
      const data = (await resp.json()) as { ok?: boolean; error?: string };
      if (!resp.ok || !data.ok) {
        setError(data.error || 'Não foi possível validar as velas OTC.');
        return;
      }
      onImported();
      onClose();
    } catch {
      setError('Erro de comunicação ao importar velas.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/75 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="import-otc-title"
    >
      <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-t-2xl border border-slate-800 bg-[#0A1120] p-5 shadow-2xl sm:rounded-2xl sm:p-6">
        <div className="mb-4 flex items-center justify-between gap-4">
          <div>
            <h2 id="import-otc-title" className="font-display text-lg font-bold text-white">
              Importar Velas OTC Reais
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Par exclusivo: <strong className="text-slate-200">{pair.symbol}</strong> · Período:{' '}
              <strong className="text-slate-200">
                {timeframe === '1m' ? '1 Minuto' : '5 Minutos'}
              </strong>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela"
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-300">
              Identificação da exportação OTC
            </label>
            <input
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              className="w-full min-h-[44px] rounded-lg border border-slate-700 bg-[#050811] px-3 py-2 text-sm text-white focus:border-blue-500 focus:outline-none"
              placeholder={`Pocket Option ${pair.symbol}`}
            />
          </div>

          <div>
            <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-medium text-slate-300">
                Ficheiro CSV (data, hora, abertura, máxima, mínima, fecho)
              </label>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleDownloadHeaderTemplate}
                  className="inline-flex items-center gap-1 text-xs font-medium text-slate-300 hover:text-white"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Modelo CSV</span>
                </button>
                <label className="inline-flex cursor-pointer items-center gap-1.5 text-xs font-semibold text-blue-400 hover:text-blue-300">
                  <Upload className="h-3.5 w-3.5" />
                  <span>Carregar CSV</span>
                  <input
                    type="file"
                    accept=".csv,.json,.txt"
                    onChange={handleFileUpload}
                    className="sr-only"
                  />
                </label>
              </div>
            </div>
            <textarea
              rows={6}
              value={rawData}
              onChange={(e) => {
                setRawData(e.target.value);
                setError(null);
              }}
              placeholder={`data,hora,abertura,maxima,minima,fecho\n2026-11-17,13:00:00,1.08420,1.08455,1.08410,1.08448\n2026-11-17,13:01:00,1.08448,1.08470,1.08435,1.08462`}
              className="w-full rounded-lg border border-slate-700 bg-[#050811] p-3 font-mono text-xs text-slate-200 placeholder:text-slate-600 focus:border-blue-500 focus:outline-none"
            />
            <p className="mt-1.5 text-[11px] leading-relaxed text-slate-400">
              Suporta separador vírgula (<code>,</code>) ou ponto-e-vírgula (<code>;</code>), datas <code>YYYY-MM-DD</code> ou <code>DD/MM/YYYY</code>, e colunas em português (<code>data, hora, abertura, maxima, minima, fecho</code>) ou inglês. Mínimo de 30 velas válidas.
            </p>
          </div>

          {/* Live Validation Preview */}
          {previewValidation && (
            <div
              className={`rounded-xl border p-3.5 text-xs ${
                previewValidation.valid
                  ? 'border-emerald-500/40 bg-emerald-950/25 text-emerald-200'
                  : 'border-amber-500/40 bg-amber-950/25 text-amber-200'
              }`}
            >
              <div className="flex items-start gap-2">
                {previewValidation.valid ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <p className="font-semibold">
                    {previewValidation.valid
                      ? `Validação concluída: ${previewValidation.validCount} velas OTC válidas prontas para análise.`
                      : 'Dados incompletos ou inválidos para análise técnica.'}
                  </p>
                  <p className="font-mono text-[11px] opacity-90">
                    Linhas lidas: {previewValidation.totalRows} · Válidas:{' '}
                    {previewValidation.validCount} · Rejeitadas:{' '}
                    {previewValidation.rejectedCount}
                  </p>
                  {previewValidation.firstCandleTimeMs &&
                    previewValidation.lastCandleTimeMs && (
                      <p className="font-mono text-[11px] opacity-90">
                        Intervalo: {formatDateTimePT(previewValidation.firstCandleTimeMs)} até{' '}
                        {formatDateTimePT(previewValidation.lastCandleTimeMs)}
                      </p>
                    )}
                  {previewValidation.errors.length > 0 && (
                    <ul className="mt-1 list-disc pl-4 text-[11px] text-red-200">
                      {previewValidation.errors.map((errMsg, idx) => (
                        <li key={idx}>{errMsg}</li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>
          )}

          <label className="flex min-h-[44px] cursor-pointer items-start gap-2.5 rounded-lg border border-slate-800 bg-[#050811] p-3 text-xs text-slate-300">
            <input
              type="checkbox"
              checked={confirmedOtcSource}
              onChange={(e) => setConfirmedOtcSource(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-slate-600 bg-[#050811] text-blue-600 focus:ring-blue-500"
            />
            <span>
              Confirmo que estas velas pertencem exclusivamente a cotações OTC reais de{' '}
              <strong>{pair.symbol}</strong> e não são dados de Forex tradicional.
            </span>
          </label>

          {error && (
            <div className="rounded-lg border border-red-500/40 bg-red-950/40 px-3 py-2.5 text-xs text-red-200">
              {error}
            </div>
          )}

          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] rounded-lg border border-slate-700 px-4 py-2 text-sm font-medium text-slate-300 hover:bg-slate-800"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={
                submitting ||
                !previewValidation?.valid ||
                !confirmedOtcSource
              }
              className="min-h-[44px] rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {submitting ? 'A validar...' : 'Validar e Analisar OTC'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
