import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  BookmarkPlus,
  Camera,
  CheckCircle2,
  History,
  ImagePlus,
  Layers,
  Minus,
  Send,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import type {
  CaptureComparisonSummary,
  ChartImageAnalysisResult,
  PairDefinition,
  Timeframe,
  TradingMode,
} from '../types/market.ts';
import { apiUrl } from '../utils/api.ts';
import {
  formatBreakoutLabel,
  formatProximityLabel,
  formatTrendEvolutionLabel,
  formatTrendLabel,
} from '../utils/captureFormatting.ts';
import { formatDateTimePT, strengthToLabel } from '../utils/indicators.ts';

interface ChartImageAnalyzerModalProps {
  isOpen: boolean;
  onClose: () => void;
  pair: PairDefinition;
  timeframe: Timeframe;
  mode: TradingMode;
  telegramConfigured: boolean;
  telegramAutoSendCaptures: boolean;
  onToggleAutoSendCaptures: (enabled: boolean) => Promise<void>;
  onSaveToHistory: (result: ChartImageAnalysisResult) => Promise<void>;
}

async function prepareImagePayload(
  file: File
): Promise<{
  base64: string;
  mimeType: 'image/png' | 'image/jpeg' | 'image/webp';
  previewUrl: string;
}> {
  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('Não foi possível ler a imagem.'));
      el.src = objectUrl;
    });

    const maxWidth = 1600;
    let targetW = img.naturalWidth;
    let targetH = img.naturalHeight;
    if (targetW > maxWidth) {
      targetH = Math.round((targetH * maxWidth) / targetW);
      targetW = maxWidth;
    }

    const canvas = document.createElement('canvas');
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Falha ao processar imagem no navegador.');
    }
    ctx.drawImage(img, 0, 0, targetW, targetH);

    const mimeType: 'image/png' | 'image/jpeg' | 'image/webp' =
      file.type === 'image/png' && file.size < 2_500_000 ? 'image/png' : 'image/jpeg';
    const dataUrl = canvas.toDataURL(mimeType, 0.9);
    const base64 = dataUrl.split(',')[1] || '';

    return {
      base64,
      mimeType,
      previewUrl: dataUrl,
    };
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

export function ChartImageAnalyzerModal({
  isOpen,
  onClose,
  pair,
  timeframe,
  mode,
  telegramConfigured,
  telegramAutoSendCaptures,
  onToggleAutoSendCaptures,
  onSaveToHistory,
}: ChartImageAnalyzerModalProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<'image/png' | 'image/jpeg' | 'image/webp'>('image/jpeg');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<ChartImageAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savingHistory, setSavingHistory] = useState(false);
  const [sendingTelegram, setSendingTelegram] = useState(false);
  const [togglingAutoSend, setTogglingAutoSend] = useState(false);
  const [captureHistory, setCaptureHistory] = useState<ChartImageAnalysisResult[]>([]);
  const [comparison, setComparison] = useState<CaptureComparisonSummary | null>(null);
  const [actionFeedback, setActionFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  const fetchCaptureHistory = useCallback(async () => {
    try {
      const resp = await fetch(
        apiUrl(
          `/api/market/capture-history?pairId=${encodeURIComponent(
            pair.id
          )}&timeframe=${timeframe}`
        )
      );
      if (!resp.ok) return;
      const data = (await resp.json()) as {
        captures: ChartImageAnalysisResult[];
        comparison: CaptureComparisonSummary;
      };
      setCaptureHistory(data.captures);
      setComparison(data.comparison);
    } catch {
      // Ignore silent history fetch failures
    }
  }, [pair.id, timeframe]);

  useEffect(() => {
    if (!isOpen) return;
    setResult(null);
    setError(null);
    setActionFeedback(null);
    void fetchCaptureHistory();
  }, [isOpen, pair.id, timeframe, fetchCaptureHistory]);

  const loadImageFile = async (file: File) => {
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
      setError('Formato não suportado. Carregue uma imagem PNG, JPEG ou WEBP.');
      return;
    }
    setError(null);
    setResult(null);
    setActionFeedback(null);
    try {
      const prepared = await prepareImagePayload(file);
      setPreviewUrl(prepared.previewUrl);
      setImageBase64(prepared.base64);
      setMimeType(prepared.mimeType);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao processar imagem.');
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (const item of items) {
        if (item.type.startsWith('image/')) {
          const file = item.getAsFile();
          if (file) {
            void loadImageFile(file);
            break;
          }
        }
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAnalyze = async () => {
    if (!imageBase64) return;
    setAnalyzing(true);
    setError(null);
    setActionFeedback(null);
    try {
      const resp = await fetch(apiUrl('/api/market/analyze-image'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pairId: pair.id,
          timeframe,
          imageBase64,
          mimeType,
        }),
      });
      const data = (await resp.json()) as ChartImageAnalysisResult & { error?: string };
      if (!resp.ok) {
        throw new Error(data.error || 'Falha ao analisar captura de ecrã.');
      }
      setResult(data);
      if (data.reliable) {
        await fetchCaptureHistory();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao analisar captura.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSave = async () => {
    if (!result || !result.reliable) return;
    setSavingHistory(true);
    setActionFeedback(null);
    try {
      await onSaveToHistory(result);
      setActionFeedback({
        type: 'success',
        message: 'Leitura visual registada também no histórico geral de sinais.',
      });
    } catch (err) {
      setActionFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Erro ao guardar no histórico.',
      });
    } finally {
      setSavingHistory(false);
    }
  };

  const handleSendTelegram = async () => {
    if (!result || !result.reliable) return;
    setSendingTelegram(true);
    setActionFeedback(null);
    try {
      const resp = await fetch(apiUrl('/api/telegram/send-image-analysis'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ analysis: result }),
      });
      const data = (await resp.json()) as { ok?: boolean; error?: string };
      if (!resp.ok || !data.ok) {
        throw new Error(data.error || 'Erro ao enviar análise para o Telegram.');
      }
      setActionFeedback({
        type: 'success',
        message: 'Resultado da captura enviado para o Telegram.',
      });
    } catch (err) {
      setActionFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Erro ao enviar para o Telegram.',
      });
    } finally {
      setSendingTelegram(false);
    }
  };

  const handleToggleAutoSend = async (next: boolean) => {
    setTogglingAutoSend(true);
    try {
      await onToggleAutoSendCaptures(next);
    } finally {
      setTogglingAutoSend(false);
    }
  };

  const renderIndicatorRow = (
    name: string,
    reading: ChartImageAnalysisResult['indicators']['rsi']
  ) => {
    const biasColor =
      reading.bias === 'UP'
        ? 'text-emerald-400'
        : reading.bias === 'DOWN'
          ? 'text-red-400'
          : reading.bias === 'NEUTRO'
            ? 'text-slate-300'
            : 'text-slate-500';
    return (
      <div className="py-2">
        <div className="flex items-center justify-between gap-2 text-xs">
          <span className="font-medium text-slate-200">{name}</span>
          <span className={`font-mono font-semibold ${biasColor}`}>
            {!reading.visible
              ? 'Não visível / dados insuficientes'
              : reading.bias === 'UP'
                ? '▲ UP'
                : reading.bias === 'DOWN'
                  ? '▼ DOWN'
                  : '• NEUTRO'}
          </span>
        </div>
        <p className="mt-0.5 text-[11px] text-slate-400">{reading.summary}</p>
      </div>
    );
  };

  const evolutionMeta = comparison
    ? formatTrendEvolutionLabel(comparison.trendEvolution)
    : null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="chart-image-modal-title"
    >
      <div className="max-h-[94vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl border border-slate-800 bg-[#0A1120] p-4 shadow-2xl sm:rounded-2xl sm:p-6">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 id="chart-image-modal-title" className="font-display text-lg font-bold text-white">
              Análise Visual de Captura OTC
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              {pair.symbol} · {timeframe === '1m' ? '1 Minuto' : '5 Minutos'} · Modo{' '}
              {mode === 'DEMO' ? 'DEMO' : 'Análise Real'} · Execução automática desativada
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela"
            className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Quick Auto-Send Telegram Option */}
          <div className="flex flex-col gap-2 rounded-xl border border-slate-800 bg-[#050811] px-3.5 py-2.5 sm:flex-row sm:items-center sm:justify-between">
            <label className="flex min-h-[40px] cursor-pointer items-center gap-2.5 text-xs text-slate-200">
              <input
                type="checkbox"
                checked={telegramAutoSendCaptures}
                disabled={togglingAutoSend}
                onChange={(e) => void handleToggleAutoSend(e.target.checked)}
                className="h-4 w-4 rounded border-slate-600 bg-[#0A1120] text-blue-600 focus:ring-blue-500"
              />
              <span>Enviar resultado automaticamente para o Telegram</span>
            </label>
            <span className="text-[11px] text-slate-400">
              {telegramConfigured
                ? telegramAutoSendCaptures
                  ? 'Envio automático ativo'
                  : 'Envio manual'
                : 'Configure Bot Token e Chat ID nas Configurações'}
            </span>
          </div>

          {/* Upload Zone */}
          <label className="flex min-h-[112px] cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-slate-700 bg-[#050811] p-4 text-center transition-colors hover:border-blue-500/60 hover:bg-[#081022]">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#0D1A33] text-blue-400">
              <Camera className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-white">
                Carregar captura do gráfico Pocket Option ({pair.symbol})
              </p>
              <p className="mt-0.5 text-[11px] text-slate-400">
                Toque para escolher PNG/JPEG/WEBP da galeria ou cole com Ctrl+V
              </p>
            </div>
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) void loadImageFile(file);
              }}
              className="sr-only"
            />
          </label>

          {previewUrl && (
            <div className="space-y-3">
              <div className="overflow-hidden rounded-xl border border-slate-800 bg-[#050811]">
                <img
                  src={previewUrl}
                  alt="Pré-visualização da captura do gráfico OTC"
                  referrerPolicy="no-referrer"
                  className="max-h-60 w-full object-contain"
                />
              </div>

              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <label className="inline-flex min-h-[44px] cursor-pointer items-center justify-center gap-1.5 rounded-lg border border-slate-700 px-3.5 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800">
                  <ImagePlus className="h-4 w-4" />
                  <span>Trocar captura</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) void loadImageFile(file);
                    }}
                    className="sr-only"
                  />
                </label>

                <button
                  type="button"
                  onClick={handleAnalyze}
                  disabled={analyzing}
                  className="min-h-[44px] rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white hover:bg-blue-500 disabled:opacity-50"
                >
                  {analyzing ? 'A analisar velas e zonas...' : 'Analisar Captura'}
                </button>
              </div>
            </div>
          )}

          {error && (
            <div className="rounded-xl border border-red-500/40 bg-red-950/35 px-4 py-3 text-xs text-red-200">
              {error}
            </div>
          )}

          {/* Unreliable Image Feedback */}
          {result && !result.reliable && (
            <div className="rounded-xl border border-amber-500/45 bg-amber-950/30 p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
                <div>
                  <h3 className="font-display text-sm font-bold text-amber-200">
                    Captura insuficiente para análise fiável — envie outra imagem
                  </h3>
                  <p className="mt-1 text-xs leading-relaxed text-amber-100/90">
                    {result.unreliableReason ||
                      'Não foi possível identificar velas suficientes com nitidez para emitir um parecer técnico rigoroso.'}
                  </p>
                  <p className="mt-2 text-[11px] text-slate-400">
                    Tire outra captura de ecrã nítida do gráfico OTC da Pocket Option, mostrando as últimas velas à direita sem recortes nem sobreposições.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Reliable Result Display */}
          {result && result.reliable && (
            <div className="space-y-4 rounded-xl border border-slate-800 bg-[#070C18] p-4">
              {/* Verdict Header */}
              <div
                className={`rounded-xl border p-4 ${
                  result.direction === 'UP'
                    ? 'border-emerald-500/40 bg-emerald-950/30'
                    : result.direction === 'DOWN'
                      ? 'border-red-500/40 bg-red-950/30'
                      : 'border-slate-700 bg-[#0D1526]'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs text-slate-300">
                      Pocket Option OTC · {result.detectedPairText || result.pairSymbol} ·{' '}
                      {result.timeframe.toUpperCase()}
                    </p>
                    <div className="mt-1 flex items-center gap-2">
                      {result.direction === 'UP' ? (
                        <ArrowUpRight className="h-6 w-6 text-emerald-400" />
                      ) : result.direction === 'DOWN' ? (
                        <ArrowDownRight className="h-6 w-6 text-red-400" />
                      ) : (
                        <Minus className="h-6 w-6 text-slate-400" />
                      )}
                      <h3 className="font-display text-xl font-extrabold text-white">
                        {result.direction === 'UP'
                          ? 'UP · COMPRA'
                          : result.direction === 'DOWN'
                            ? 'DOWN · VENDA'
                            : 'NEUTRO — AGUARDAR'}
                      </h3>
                    </div>
                  </div>
                  <div className="text-right font-mono tabular-nums">
                    <span className="block text-[11px] text-slate-400">Confiança est.</span>
                    <span className="text-xl font-bold text-white">{result.confidence}%</span>
                  </div>
                </div>

                <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-300">
                  <span>
                    Força: <strong className="text-white">{strengthToLabel(result.strength)}</strong>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    Critérios alinhados:{' '}
                    <strong className="font-mono text-white">
                      {result.evidenceSummary.criteriaAligned}
                    </strong>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    Preço:{' '}
                    <strong className="font-mono text-white">
                      {result.visiblePriceText || 'Não legível (não inventado)'}
                    </strong>
                  </span>
                </div>

                <p className="mt-2 text-[11px] text-slate-400">
                  A confiança estimada reflete apenas a confluência visual observada — não representa probabilidade real de vitória nem garantia de lucro.
                </p>
              </div>

              {/* Auto-sent Telegram Notification */}
              {result.telegramAutoSent === true && (
                <div className="flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-950/35 px-3 py-2 text-xs text-emerald-200">
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                  <span>Resultado enviado automaticamente para o Telegram.</span>
                </div>
              )}
              {result.telegramAutoSent === false && result.telegramAutoError && (
                <div className="rounded-lg border border-red-500/40 bg-red-950/35 px-3 py-2 text-xs text-red-200">
                  Falha no envio automático para o Telegram: {result.telegramAutoError}
                </div>
              )}

              {/* Candle Analysis & Trend */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-lg border border-slate-800 bg-[#050811] p-3">
                  <span className="text-[11px] font-medium text-slate-400">
                    Análise de Velas e Últimas Velas
                  </span>
                  <div className="mt-1.5 flex items-center gap-4 font-mono text-sm font-bold tabular-nums">
                    <span className="text-emerald-400">
                      {result.greenCandlesCount} Verdes
                    </span>
                    <span className="text-red-400">
                      {result.redCandlesCount} Vermelhas
                    </span>
                  </div>
                  <p className="mt-1.5 text-xs font-medium text-slate-200">
                    {result.lastCandlesSequence}
                  </p>
                  <p className="mt-1 text-[11px] text-slate-400">
                    {result.recentCandlesSummary}
                  </p>
                </div>

                <div className="rounded-lg border border-slate-800 bg-[#050811] p-3">
                  <span className="text-[11px] font-medium text-slate-400">
                    Tendência Identificada
                  </span>
                  <div className="mt-1.5 flex items-center gap-1.5 text-sm font-bold text-white">
                    {result.trend === 'ALTA' && (
                      <TrendingUp className="h-4 w-4 text-emerald-400" />
                    )}
                    {result.trend === 'BAIXA' && (
                      <TrendingDown className="h-4 w-4 text-red-400" />
                    )}
                    {result.trend === 'LATERAL' && (
                      <Activity className="h-4 w-4 text-sky-400" />
                    )}
                    <span>{formatTrendLabel(result.trend)}</span>
                  </div>
                  <p className="mt-1.5 text-[11px] leading-relaxed text-slate-400">
                    {result.trendSummary}
                  </p>
                </div>
              </div>

              {/* Candle Type Breakdown (Force / Rejection / Doji / Reversal) */}
              <div className="rounded-lg border border-slate-800 bg-[#050811] p-3">
                <span className="text-[11px] font-medium text-slate-400">
                  Características das Velas Recentes
                </span>
                <div className="mt-2 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
                  <div>
                    <span className="block text-[10px] text-slate-500">Velas de força</span>
                    <span
                      className={`font-semibold ${
                        result.candleTypes.forceCandles ? 'text-emerald-300' : 'text-slate-400'
                      }`}
                    >
                      {result.candleTypes.forceCandles ? 'Identificadas' : 'Não evidentes'}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-500">Rejeição (pavios)</span>
                    <span
                      className={`font-semibold ${
                        result.candleTypes.rejectionCandles ? 'text-sky-300' : 'text-slate-400'
                      }`}
                    >
                      {result.candleTypes.rejectionCandles ? 'Identificada' : 'Não evidente'}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-500">Doji / Indecisão</span>
                    <span
                      className={`font-semibold ${
                        result.candleTypes.dojiDetected ? 'text-amber-300' : 'text-slate-400'
                      }`}
                    >
                      {result.candleTypes.dojiDetected ? 'Detetado' : 'Ausente'}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-500">Possível reversão</span>
                    <span
                      className={`font-semibold ${
                        result.candleTypes.reversalSignal ? 'text-amber-300' : 'text-slate-400'
                      }`}
                    >
                      {result.candleTypes.reversalSignal ? 'Sinal presente' : 'Sem sinal claro'}
                    </span>
                  </div>
                </div>
                <p className="mt-2 text-[11px] leading-relaxed text-slate-300">
                  {result.candleTypes.details}
                </p>
              </div>

              {/* Support & Resistance Zones */}
              <div className="rounded-lg border border-slate-800 bg-[#050811] p-3">
                <div className="flex items-center gap-1.5">
                  <Layers className="h-3.5 w-3.5 text-blue-400" />
                  <span className="text-[11px] font-medium text-slate-400">
                    Suportes, Resistências e Rompimentos
                  </span>
                </div>

                <div className="mt-2 grid grid-cols-1 gap-2 text-xs sm:grid-cols-2">
                  <div>
                    <span className="block text-[10px] text-slate-500">Posição do preço</span>
                    <span className="font-semibold text-white">
                      {formatProximityLabel(result.supportResistance.priceProximity)}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-500">Estado de rompimento</span>
                    <span className="font-semibold text-sky-300">
                      {formatBreakoutLabel(result.supportResistance.breakoutStatus)}
                    </span>
                  </div>
                </div>

                {(result.supportResistance.supportZones.length > 0 ||
                  result.supportResistance.resistanceZones.length > 0) && (
                  <div className="mt-2.5 grid grid-cols-1 gap-2 border-t border-slate-800/80 pt-2.5 text-[11px] sm:grid-cols-2">
                    <div>
                      <span className="font-semibold text-emerald-400">Zonas de Suporte</span>
                      {result.supportResistance.supportZones.length === 0 ? (
                        <p className="mt-0.5 text-slate-500">Nenhuma zona visível destacada.</p>
                      ) : (
                        <ul className="mt-1 space-y-1 text-slate-300">
                          {result.supportResistance.supportZones.map((z, idx) => (
                            <li key={idx}>
                              {z.label} ·{' '}
                              <span className="font-mono text-slate-400">
                                {z.visiblePrice || 'Nível visual (preço não legível)'}
                              </span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                    <div>
                      <span className="font-semibold text-red-400">Zonas de Resistência</span>
                      {result.supportResistance.resistanceZones.length === 0 ? (
                        <p className="mt-0.5 text-slate-500">Nenhuma zona visível destacada.</p>
                      ) : (
                        <ul className="mt-1 space-y-1 text-slate-300">
                          {result.supportResistance.resistanceZones.map((z, idx) => (
                            <li key={idx}>
                              {z.label} ·{' '}
                              <span className="font-mono text-slate-400">
                                {z.visiblePrice || 'Nível visual (preço não legível)'}
                              </span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                )}

                <p className="mt-2 text-[11px] leading-relaxed text-slate-300">
                  {result.supportResistance.summary}
                </p>
              </div>

              {/* Candlestick Patterns */}
              <div className="rounded-lg border border-slate-800 bg-[#050811] p-3">
                <span className="text-[11px] font-medium text-slate-400">
                  Padrões de Velas Observados
                </span>
                {result.patterns.length === 0 ? (
                  <p className="mt-1 text-xs text-slate-300">
                    Sem padrão clássico de reversão ou continuação claramente definido.
                  </p>
                ) : (
                  <ul className="mt-1.5 space-y-1.5">
                    {result.patterns.map((p, idx) => (
                      <li key={idx} className="text-xs">
                        <span
                          className={`font-semibold ${
                            p.bias === 'BULLISH'
                              ? 'text-emerald-400'
                              : p.bias === 'BEARISH'
                                ? 'text-red-400'
                                : 'text-slate-200'
                          }`}
                        >
                          {p.name}:
                        </span>{' '}
                        <span className="text-slate-300">{p.description}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Indicators (Strictly when visible in screenshot) */}
              <div className="divide-y divide-slate-800 rounded-lg border border-slate-800 bg-[#050811] px-3 py-1">
                {renderIndicatorRow('RSI', result.indicators.rsi)}
                {renderIndicatorRow('EMA', result.indicators.ema)}
                {renderIndicatorRow('MACD', result.indicators.macd)}
              </div>

              {/* Rigorous Evidence & Rationale */}
              <div className="rounded-lg border border-slate-800 bg-[#050811] p-3">
                <span className="text-[11px] font-medium text-slate-400">
                  Justificativa e Rigor da Análise
                </span>
                <p className="mt-1 text-xs leading-relaxed text-slate-200">{result.rationale}</p>
                <p className="mt-1.5 text-[11px] text-slate-400">
                  {result.evidenceSummary.notes}
                </p>
              </div>

              <p className="font-mono text-[11px] text-slate-400">
                Análise efetuada em: {formatDateTimePT(result.analyzedAtMs)}
              </p>

              {/* Actions */}
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={handleSave}
                  disabled={savingHistory}
                  className="flex min-h-[44px] items-center justify-center gap-2 rounded-lg border border-blue-500/40 bg-[#10203F] px-4 py-2 text-xs font-semibold text-blue-100 hover:bg-[#162C56] disabled:opacity-50"
                >
                  <BookmarkPlus className="h-4 w-4" />
                  <span>{savingHistory ? 'A guardar...' : 'Registar nos Sinais'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSendTelegram}
                  disabled={!telegramConfigured || sendingTelegram}
                  title={
                    !telegramConfigured
                      ? 'Configure Bot Token e Chat ID nas Configurações'
                      : 'Enviar resultado desta captura para o Telegram'
                  }
                  className="flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-45"
                >
                  <Send className="h-4 w-4" />
                  <span>{sendingTelegram ? 'A enviar...' : 'Enviar para Telegram'}</span>
                </button>
              </div>

              {actionFeedback && (
                <div
                  className={`rounded-lg border px-3 py-2 text-xs ${
                    actionFeedback.type === 'success'
                      ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-200'
                      : 'border-red-500/40 bg-red-950/40 text-red-200'
                  }`}
                >
                  {actionFeedback.message}
                </div>
              )}
            </div>
          )}

          {/* Isolated Per-Pair & Per-Timeframe Capture History Comparison */}
          {comparison && (
            <div className="rounded-xl border border-slate-800 bg-[#050811] p-3.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <History className="h-4 w-4 text-blue-400" />
                  <h3 className="text-xs font-bold text-white">
                    Comparação de Capturas · {pair.symbol} ({timeframe.toUpperCase()})
                  </h3>
                </div>
                {evolutionMeta && (
                  <span className={`text-xs font-bold ${evolutionMeta.toneClass}`}>
                    {evolutionMeta.label}
                  </span>
                )}
              </div>
              <p className="mt-1.5 text-[11px] leading-relaxed text-slate-300">
                {comparison.summary}
              </p>

              {captureHistory.length > 0 && (
                <div className="mt-2.5 divide-y divide-slate-800/80 border-t border-slate-800/80 pt-2">
                  {captureHistory.slice(0, 4).map((cap, idx) => (
                    <div
                      key={cap.id}
                      className="flex items-center justify-between gap-2 py-1.5 text-[11px]"
                    >
                      <span className="font-mono text-slate-400">
                        #{idx + 1} · {formatDateTimePT(cap.analyzedAtMs)}
                      </span>
                      <span className="text-slate-300">
                        {formatTrendLabel(cap.trend)} ·{' '}
                        <strong
                          className={
                            cap.direction === 'UP'
                              ? 'text-emerald-400'
                              : cap.direction === 'DOWN'
                                ? 'text-red-400'
                                : 'text-slate-300'
                          }
                        >
                          {cap.direction === 'NEUTRO' ? 'NEUTRO — AGUARDAR' : cap.direction}
                        </strong>{' '}
                        <span className="font-mono text-slate-400">({cap.confidence}%)</span>
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="flex items-start gap-2 border-t border-slate-800 pt-2.5 text-[11px] text-slate-400">
            <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-blue-400" />
            <span>
              Exclusivo Pocket Option OTC · Modo {mode === 'DEMO' ? 'DEMO' : 'Análise Real'} · Execução automática desativada · Sem promessa de lucros ou taxas de acerto.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
