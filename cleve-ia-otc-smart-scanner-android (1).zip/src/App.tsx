import { Camera, FileSpreadsheet, RefreshCw, Trash2 } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { CandlestickChart } from './components/CandlestickChart.tsx';
import { ChartImageAnalyzerModal } from './components/ChartImageAnalyzerModal.tsx';
import { DataUnavailablePanel } from './components/DataUnavailablePanel.tsx';
import { Header, type AppTab } from './components/Header.tsx';
import { ImportOtcModal } from './components/ImportOtcModal.tsx';
import { MobileBottomNav } from './components/MobileBottomNav.tsx';
import { OpportunitiesScanner } from './components/OpportunitiesScanner.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { SignalCard } from './components/SignalCard.tsx';
import { SignalHistoryView } from './components/SignalHistoryView.tsx';
import { MARKET_PAIRS, getPairById } from './data/pairs.ts';
import type {
  AnalysisResult,
  AppSettings,
  ChartImageAnalysisResult,
  SignalOutcome,
  SignalRecord,
  Timeframe,
} from './types/market.ts';
import { apiUrl } from './utils/api.ts';
import { DEFAULT_INDICATOR_CONFIG, formatDateTimePT } from './utils/indicators.ts';

const DEFAULT_SETTINGS: AppSettings = {
  mode: 'DEMO',
  otcBridgeUrl: '',
  otcBridgeApiKey: '',
  telegramBotToken: '',
  telegramChatId: '',
  telegramAutoAlert: false,
  telegramAutoSendCaptures: false,
  indicatorConfig: DEFAULT_INDICATOR_CONFIG,
};

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>('analyze');
  const [selectedPairId, setSelectedPairId] = useState<string>('EURUSD_OTC');
  const [timeframe, setTimeframe] = useState<Timeframe>('1m');
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [signals, setSignals] = useState<SignalRecord[]>([]);
  const [loadingAnalysis, setLoadingAnalysis] = useState<boolean>(true);
  const [importOpen, setImportOpen] = useState<boolean>(false);
  const [imageModalOpen, setImageModalOpen] = useState<boolean>(false);
  const [savingHistory, setSavingHistory] = useState<boolean>(false);
  const [sendingTelegram, setSendingTelegram] = useState<boolean>(false);
  const [actionFeedback, setActionFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  const lastAutoSentKeyRef = useRef<string>('');
  const lastRecordedAnalysisKeyRef = useRef<string>('');

  const selectedPair = getPairById(selectedPairId);

  const fetchSettingsAndHistory = useCallback(async () => {
    try {
      const [settingsRes, signalsRes] = await Promise.all([
        fetch(apiUrl('/api/settings')),
        fetch(apiUrl('/api/signals')),
      ]);
      if (settingsRes.ok) {
        const sData = (await settingsRes.json()) as AppSettings;
        setSettings(sData);
      }
      if (signalsRes.ok) {
        const sigData = (await signalsRes.json()) as { signals: SignalRecord[] };
        setSignals(sigData.signals);
      }
    } catch {
      // Keep defaults on initial load failure
    }
  }, []);

  const fetchAnalysis = useCallback(async () => {
    setLoadingAnalysis(true);
    setActionFeedback(null);
    try {
      const resp = await fetch(
        apiUrl(
          `/api/market/analyze?pairId=${encodeURIComponent(
            selectedPairId
          )}&timeframe=${timeframe}`
        )
      );
      if (!resp.ok) throw new Error('Erro ao obter análise OTC.');
      const data = (await resp.json()) as AnalysisResult;
      setAnalysis(data);
    } catch {
      setAnalysis(null);
    } finally {
      setLoadingAnalysis(false);
    }
  }, [selectedPairId, timeframe]);

  useEffect(() => {
    fetchSettingsAndHistory();
  }, [fetchSettingsAndHistory]);

  useEffect(() => {
    fetchAnalysis();
  }, [fetchAnalysis]);

  // Periodic refresh every 20s while on Analyze tab for exclusively the selected OTC pair
  useEffect(() => {
    if (activeTab !== 'analyze') return;
    const timer = window.setInterval(() => {
      fetchAnalysis();
    }, 20_000);
    return () => window.clearInterval(timer);
  }, [activeTab, fetchAnalysis]);

  const buildAnalysisRecordPayload = useCallback(
    (res: AnalysisResult): Omit<SignalRecord, 'id' | 'createdAtMs'> | null => {
      if (
        !res.source.available ||
        !res.source.isPocketOtc ||
        res.source.isStale ||
        res.currentPrice === null ||
        !res.entryEstimate
      ) {
        return null;
      }

      return {
        pairId: res.pair.id,
        pairSymbol: res.pair.symbol,
        timeframe: res.timeframe,
        direction: res.direction,
        strength: res.strength,
        confidence: res.confidence,
        priceAtSignal: res.currentPrice,
        entryTimeMs: res.entryEstimate.nextEntryTimeMs,
        expirationMinutes: res.entryEstimate.expirationMinutes,
        candleTimeMs: res.source.lastCandleTimeMs ?? undefined,
        mode: settings.mode,
        sourceProvider: res.source.providerName,
        isPocketOtc: true,
        indicatorsSnapshot: {
          rsi: res.latestIndicators.rsi,
          macdHistogram: res.latestIndicators.macdHistogram,
          emaFast: res.latestIndicators.emaFast,
          emaSlow: res.latestIndicators.emaSlow,
          pattern: res.patterns[0]?.name || 'N/A',
        },
        telegramSent: false,
        outcome: 'PENDENTE',
      };
    },
    [settings.mode]
  );

  // Automatically record every valid OTC analysis into history (deduplicated per candle)
  // and optionally send valid UP/DOWN signals to Telegram when enabled
  useEffect(() => {
    if (!analysis) return;
    const payload = buildAnalysisRecordPayload(analysis);
    if (!payload) return;

    const dedupKey = `${payload.pairId}:${payload.timeframe}:${payload.candleTimeMs ?? 'na'}:${payload.direction}`;
    if (lastRecordedAnalysisKeyRef.current === dedupKey) return;
    lastRecordedAnalysisKeyRef.current = dedupKey;

    void (async () => {
      try {
        const saveRes = await fetch(apiUrl('/api/signals'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...payload, dedupeByCandle: true }),
        });
        if (!saveRes.ok) return;
        const { signal, deduplicated } = (await saveRes.json()) as {
          signal: SignalRecord;
          deduplicated?: boolean;
        };

        if (!deduplicated) {
          setSignals((prev) => [signal, ...prev]);
        }

        const isValidDirectionalSignal =
          (signal.direction === 'UP' || signal.direction === 'DOWN') &&
          signal.confidence >= settings.indicatorConfig.minConfidence;

        if (
          settings.telegramAutoAlert &&
          settings.telegramBotToken.trim() &&
          settings.telegramChatId.trim() &&
          isValidDirectionalSignal &&
          lastAutoSentKeyRef.current !== dedupKey
        ) {
          lastAutoSentKeyRef.current = dedupKey;
          const tgRes = await fetch(apiUrl('/api/telegram/send-signal'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ signalId: signal.id, signal }),
          });
          if (tgRes.ok) {
            setSignals((prev) =>
              prev.map((s) => (s.id === signal.id ? { ...s, telegramSent: true } : s))
            );
          }
        }
      } catch {
        // Silent background save; manual save/send remain available
      }
    })();
  }, [analysis, settings, buildAnalysisRecordPayload]);

  const handleToggleMode = async () => {
    const nextMode = settings.mode === 'DEMO' ? 'REAL_ANALYTICS' : 'DEMO';
    const updated = { ...settings, mode: nextMode } as AppSettings;
    setSettings(updated);
    await fetch(apiUrl('/api/settings'), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    });
  };

  const handleSaveSettings = async (updated: AppSettings) => {
    const resp = await fetch(apiUrl('/api/settings'), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    });
    if (!resp.ok) throw new Error('Falha ao guardar configurações.');
    const saved = (await resp.json()) as AppSettings;
    setSettings(saved);
    fetchAnalysis();
  };

  const handleToggleAutoSendCaptures = async (enabled: boolean) => {
    const updated: AppSettings = { ...settings, telegramAutoSendCaptures: enabled };
    setSettings(updated);
    try {
      const resp = await fetch(apiUrl('/api/settings'), {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
      if (resp.ok) {
        const saved = (await resp.json()) as AppSettings;
        setSettings(saved);
      }
    } catch {
      // Revert if network fails
      setSettings(settings);
    }
  };

  const handleSaveCurrentSignal = async () => {
    if (!analysis) return;
    const payload = buildAnalysisRecordPayload(analysis);
    if (!payload || (payload.direction !== 'UP' && payload.direction !== 'DOWN')) return;
    setSavingHistory(true);
    setActionFeedback(null);
    try {
      const resp = await fetch(apiUrl('/api/signals'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!resp.ok) throw new Error('Erro ao guardar sinal no histórico.');
      const data = (await resp.json()) as { signal: SignalRecord };
      setSignals((prev) => [data.signal, ...prev]);
      setActionFeedback({
        type: 'success',
        message: 'Sinal OTC registado no histórico com sucesso.',
      });
    } catch (err) {
      setActionFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Erro ao guardar sinal.',
      });
    } finally {
      setSavingHistory(false);
    }
  };

  const handleSendCurrentTelegram = async () => {
    if (!analysis) return;
    const payload = buildAnalysisRecordPayload(analysis);
    if (!payload || (payload.direction !== 'UP' && payload.direction !== 'DOWN')) return;
    setSendingTelegram(true);
    setActionFeedback(null);
    try {
      const tempSignal: SignalRecord = {
        ...payload,
        id: `preview_${Date.now()}`,
        createdAtMs: Date.now(),
      };
      const resp = await fetch(apiUrl('/api/telegram/send-signal'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ signal: tempSignal }),
      });
      const data = (await resp.json()) as { ok?: boolean; error?: string };
      if (!resp.ok || !data.ok) {
        throw new Error(data.error || 'Falha ao enviar mensagem no Telegram.');
      }
      setActionFeedback({
        type: 'success',
        message: 'Sinal válido enviado para o Telegram com sucesso.',
      });
    } catch (err) {
      setActionFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Erro ao enviar para o Telegram.',
      });
    } finally {
      setSendingTelegram(false);
    }
  };

  const handleUpdateOutcome = async (id: string, outcome: SignalOutcome) => {
    const resp = await fetch(apiUrl(`/api/signals/${encodeURIComponent(id)}`), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ outcome }),
    });
    if (resp.ok) {
      const { signal } = (await resp.json()) as { signal: SignalRecord };
      setSignals((prev) => prev.map((s) => (s.id === id ? signal : s)));
    }
  };

  const handleSendHistoricalTelegram = async (signal: SignalRecord) => {
    const resp = await fetch(apiUrl('/api/telegram/send-signal'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ signalId: signal.id, signal }),
    });
    const data = (await resp.json()) as { ok?: boolean; error?: string };
    if (!resp.ok || !data.ok) {
      throw new Error(data.error || 'Falha ao enviar para o Telegram.');
    }
    setSignals((prev) =>
      prev.map((s) => (s.id === signal.id ? { ...s, telegramSent: true } : s))
    );
  };

  const handleClearHistory = async () => {
    const resp = await fetch(apiUrl('/api/signals'), { method: 'DELETE' });
    if (resp.ok) {
      setSignals([]);
    }
  };

  const handleClearImportedOtc = async () => {
    await fetch(
      apiUrl(
        `/api/market/import-otc?pairId=${encodeURIComponent(
          selectedPairId
        )}&timeframe=${timeframe}`
      ),
      { method: 'DELETE' }
    );
    fetchAnalysis();
  };

  const handleSaveImageAnalysis = async (imgRes: ChartImageAnalysisResult) => {
    const parsedPrice = imgRes.visiblePriceText
      ? Number(imgRes.visiblePriceText.replace(/[^\d.,]/g, '').replace(',', '.'))
      : NaN;

    const payload: Omit<SignalRecord, 'id' | 'createdAtMs'> = {
      pairId: imgRes.pairId,
      pairSymbol: imgRes.pairSymbol,
      timeframe: imgRes.timeframe,
      direction: imgRes.direction,
      strength: imgRes.strength,
      confidence: imgRes.confidence,
      priceAtSignal: Number.isFinite(parsedPrice) && parsedPrice > 0 ? parsedPrice : 0,
      entryTimeMs: imgRes.analyzedAtMs,
      expirationMinutes: imgRes.timeframe === '1m' ? 1 : 5,
      mode: settings.mode,
      sourceProvider: 'Análise Visual de Captura OTC',
      isPocketOtc: true,
      indicatorsSnapshot: {
        rsi: null,
        macdHistogram: null,
        emaFast: null,
        emaSlow: null,
        pattern: imgRes.patterns[0]?.name || imgRes.trend,
      },
      telegramSent: false,
      outcome: 'PENDENTE',
    };

    const resp = await fetch(apiUrl('/api/signals'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!resp.ok) {
      throw new Error('Erro ao guardar análise da imagem no histórico.');
    }
    const { signal } = (await resp.json()) as { signal: SignalRecord };
    setSignals((prev) => [signal, ...prev]);
  };

  const telegramConfigured = Boolean(
    settings.telegramBotToken.trim() && settings.telegramChatId.trim()
  );

  return (
    <div className="min-h-screen bg-[#05070B] text-slate-100 pb-24 md:pb-10">
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        mode={settings.mode}
        onToggleMode={handleToggleMode}
      />

      <main className="mx-auto max-w-7xl px-4 pt-4 sm:px-6 sm:pt-6">
        {activeTab === 'analyze' && (
          <div className="space-y-4">
            {/* Manual OTC Pair Selector & Timeframe Toolbar */}
            <section
              aria-label="Seleção individual de par OTC e timeframe"
              className="rounded-xl border border-slate-800/90 bg-[#090F1D] p-3.5 sm:p-4"
            >
              {/* Individual OTC Pair Selection Grid */}
              <div>
                <div className="mb-2 flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-slate-300">
                    Selecionar Par OTC (análise exclusiva do par escolhido)
                  </span>
                  <span className="font-mono text-[11px] text-slate-400">
                    {selectedPair.symbol}
                  </span>
                </div>

                <div
                  role="radiogroup"
                  aria-label="Pares OTC disponíveis"
                  className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap"
                >
                  {MARKET_PAIRS.map((pair) => {
                    const isSelected = pair.id === selectedPairId;
                    return (
                      <button
                        key={pair.id}
                        type="button"
                        role="radio"
                        aria-checked={isSelected}
                        onClick={() => setSelectedPairId(pair.id)}
                        className={`min-h-[44px] rounded-lg border px-3 py-2 text-xs font-semibold whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                          isSelected
                            ? 'border-blue-500 bg-blue-600 text-white'
                            : 'border-slate-800 bg-[#050811] text-slate-300 hover:border-slate-700 hover:text-white'
                        }`}
                      >
                        {pair.symbol}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Timeframe & Actions Row */}
              <div className="mt-3.5 flex flex-col gap-3 border-t border-slate-800/80 pt-3.5 sm:flex-row sm:items-center sm:justify-between">
                <div
                  role="group"
                  aria-label="Período"
                  className="flex items-center rounded-lg border border-slate-800 bg-[#050811] p-1"
                >
                  {(['1m', '5m'] as Timeframe[]).map((tf) => (
                    <button
                      key={tf}
                      type="button"
                      onClick={() => setTimeframe(tf)}
                      className={`flex-1 min-h-[38px] rounded-md px-4 text-xs font-bold whitespace-nowrap transition-colors sm:flex-initial ${
                        timeframe === tf
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {tf === '1m' ? '1 Minuto' : '5 Minutos'}
                    </button>
                  ))}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setImageModalOpen(true)}
                    className="flex min-h-[44px] items-center gap-1.5 rounded-lg border border-blue-500/50 bg-blue-600/20 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-600/30"
                  >
                    <Camera className="h-4 w-4 text-blue-300" />
                    <span>Analisar Imagem</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setImportOpen(true)}
                    className="flex min-h-[44px] items-center gap-1.5 rounded-lg border border-blue-500/35 bg-[#0D1A33] px-3.5 py-2 text-xs font-semibold text-blue-200 hover:bg-[#132548]"
                  >
                    <FileSpreadsheet className="h-4 w-4" />
                    <span>Importar Velas OTC</span>
                  </button>

                  {analysis?.source.providerType === 'IMPORTED_OTC' && (
                    <button
                      type="button"
                      onClick={handleClearImportedOtc}
                      className="flex min-h-[44px] items-center gap-1.5 rounded-lg border border-red-500/30 bg-red-950/25 px-3 py-2 text-xs font-medium text-red-300 hover:bg-red-950/45"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>Remover CSV</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={fetchAnalysis}
                    disabled={loadingAnalysis}
                    className="flex min-h-[44px] items-center gap-1.5 rounded-lg border border-slate-700 bg-[#0D1526] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800 disabled:opacity-50"
                  >
                    <RefreshCw
                      className={`h-3.5 w-3.5 ${loadingAnalysis ? 'animate-spin' : ''}`}
                    />
                    <span>Analisar</span>
                  </button>
                </div>
              </div>

              {/* Unboxed Metadata Bar */}
              <div className="mt-3 flex flex-wrap items-center gap-x-2.5 gap-y-1 border-t border-slate-800/80 pt-2.5 text-xs text-slate-400">
                <span className="font-medium text-slate-200">
                  {selectedPair.description}
                </span>
                {analysis?.source && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>Fonte: {analysis.source.providerName}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">
                      Última atualização:{' '}
                      {formatDateTimePT(
                        analysis.source.importedAtMs ?? analysis.source.fetchedAtMs
                      )}
                    </span>
                    {analysis.source.lastCandleTimeMs && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">
                          Última vela: {formatDateTimePT(analysis.source.lastCandleTimeMs)}
                        </span>
                      </>
                    )}
                  </>
                )}
              </div>
            </section>

            {/* Main Content Area */}
            {loadingAnalysis && !analysis ? (
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
                <div className="h-[420px] rounded-xl border border-slate-800/80 bg-[#090F1D] animate-pulse lg:col-span-7" />
                <div className="h-[420px] rounded-xl border border-slate-800/80 bg-[#090F1D] animate-pulse lg:col-span-5" />
              </div>
            ) : analysis && !analysis.source.available ? (
              <DataUnavailablePanel
                pair={selectedPair}
                timeframe={timeframe}
                message={
                  analysis.source.unavailableMessage ||
                  'Análise OTC não disponível sem fonte de dados OTC compatível e verificável.'
                }
                onOpenImport={() => setImportOpen(true)}
                onOpenImageAnalyzer={() => setImageModalOpen(true)}
                onOpenSettings={() => setActiveTab('settings')}
              />
            ) : analysis ? (
              <div className="space-y-4">
                {analysis.source.isStale && analysis.source.staleReason && (
                  <div className="rounded-xl border border-amber-500/40 bg-amber-950/30 px-4 py-3 text-xs text-amber-200">
                    <strong>Aviso de atualização OTC:</strong> {analysis.source.staleReason}
                  </div>
                )}

                <div className="grid grid-cols-1 gap-4 lg:grid-cols-12 lg:items-start">
                  <div className="space-y-4 lg:col-span-7">
                    <CandlestickChart analysis={analysis} />

                    {/* Compact Indicator Readout Strip */}
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                      <div className="rounded-xl border border-slate-800/80 bg-[#090F1D] p-3">
                        <span className="text-[11px] text-slate-400">Cotação OTC</span>
                        <p className="mt-1 font-mono text-base font-bold tabular-nums text-white">
                          {analysis.currentPrice !== null
                            ? analysis.currentPrice.toFixed(analysis.pair.decimals)
                            : '—'}
                        </p>
                      </div>
                      <div className="rounded-xl border border-slate-800/80 bg-[#090F1D] p-3">
                        <span className="text-[11px] text-slate-400">
                          RSI ({settings.indicatorConfig.rsiPeriod})
                        </span>
                        <p className="mt-1 font-mono text-base font-bold tabular-nums text-sky-300">
                          {analysis.latestIndicators.rsi !== null
                            ? analysis.latestIndicators.rsi.toFixed(1)
                            : '—'}
                        </p>
                      </div>
                      <div className="rounded-xl border border-slate-800/80 bg-[#090F1D] p-3">
                        <span className="text-[11px] text-slate-400">
                          EMA {settings.indicatorConfig.emaFast} / {settings.indicatorConfig.emaSlow}
                        </span>
                        <p className="mt-1 font-mono text-xs font-semibold tabular-nums text-slate-200">
                          {analysis.latestIndicators.emaFast !== null &&
                          analysis.latestIndicators.emaSlow !== null
                            ? analysis.latestIndicators.emaFast >
                              analysis.latestIndicators.emaSlow
                              ? 'EMA9 > EMA21'
                              : 'EMA9 < EMA21'
                            : '—'}
                        </p>
                      </div>
                      <div className="rounded-xl border border-slate-800/80 bg-[#090F1D] p-3">
                        <span className="text-[11px] text-slate-400">Padrão de Vela</span>
                        <p className="mt-1 truncate text-xs font-semibold text-white">
                          {analysis.patterns[0]?.name || '—'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="lg:col-span-5">
                    <SignalCard
                      analysis={analysis}
                      mode={settings.mode}
                      minConfidence={settings.indicatorConfig.minConfidence}
                      telegramConfigured={telegramConfigured}
                      onSaveToHistory={handleSaveCurrentSignal}
                      onSendTelegram={handleSendCurrentTelegram}
                      savingHistory={savingHistory}
                      sendingTelegram={sendingTelegram}
                      actionFeedback={actionFeedback}
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="rounded-xl border border-red-500/40 bg-red-950/30 p-5 text-sm text-red-200">
                Não foi possível carregar a análise OTC. Tente atualizar novamente.
              </div>
            )}
          </div>
        )}

        {activeTab === 'scanner' && (
          <OpportunitiesScanner
            timeframe={timeframe}
            onChangeTimeframe={setTimeframe}
            onInspectPair={(pairId) => {
              setSelectedPairId(pairId);
              setActiveTab('analyze');
            }}
          />
        )}

        {activeTab === 'history' && (
          <SignalHistoryView
            signals={signals}
            initialPairId={selectedPairId}
            initialTimeframe={timeframe}
            telegramConfigured={telegramConfigured}
            onUpdateOutcome={handleUpdateOutcome}
            onSendTelegram={handleSendHistoricalTelegram}
            onClearHistory={handleClearHistory}
            onGoToAnalyze={() => setActiveTab('analyze')}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView settings={settings} onSaveSettings={handleSaveSettings} />
        )}
      </main>

      <MobileBottomNav activeTab={activeTab} onSelectTab={setActiveTab} />

      <ImportOtcModal
        isOpen={importOpen}
        onClose={() => setImportOpen(false)}
        pair={selectedPair}
        timeframe={timeframe}
        onImported={fetchAnalysis}
      />

      <ChartImageAnalyzerModal
        isOpen={imageModalOpen}
        onClose={() => setImageModalOpen(false)}
        pair={selectedPair}
        timeframe={timeframe}
        mode={settings.mode}
        telegramConfigured={telegramConfigured}
        telegramAutoSendCaptures={settings.telegramAutoSendCaptures}
        onToggleAutoSendCaptures={handleToggleAutoSendCaptures}
        onSaveToHistory={handleSaveImageAnalysis}
      />
    </div>
  );
}
