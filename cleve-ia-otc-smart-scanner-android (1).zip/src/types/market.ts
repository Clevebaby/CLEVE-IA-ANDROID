export type Timeframe = '1m' | '5m';

export type TradingMode = 'DEMO' | 'REAL_ANALYTICS';

export type PairCategory = 'OTC';

export type SignalDirection = 'UP' | 'DOWN' | 'NEUTRO';

export type SignalStrength =
  | 'MUITO_FORTE'
  | 'FORTE'
  | 'MODERADA'
  | 'FRACA'
  | 'SEM_CONFLUENCIA';

export type SignalOutcome = 'PENDENTE' | 'WIN' | 'LOSS' | 'EMPATE';

export interface PairDefinition {
  id: string;
  symbol: string;
  displayName: string;
  category: PairCategory;
  decimals: number;
  baseCurrency: string;
  quoteCurrency: string;
  description: string;
}

export interface Candle {
  time: number; // Unix timestamp in milliseconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface IndicatorConfig {
  rsiPeriod: number;
  rsiOverbought: number;
  rsiOversold: number;
  emaFast: number;
  emaSlow: number;
  macdFast: number;
  macdSlow: number;
  macdSignal: number;
  minConfidence: number;
}

export interface CandlePattern {
  name: string;
  bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  description: string;
  impactPoints: number;
}

export interface TechnicalFactor {
  id: string;
  label: string;
  valueText: string;
  bias: 'UP' | 'DOWN' | 'NEUTRO';
  summary: string;
  points: number;
}

export interface EntryTimingEstimate {
  nextEntryTimeMs: number;
  secondsUntilEntry: number;
  expirationMinutes: number;
  timingStatus:
    | 'PREPARAR_PROXIMA_VELA'
    | 'JANELA_ABERTURA_ATIVA'
    | 'AGUARDAR_CONFIRMACAO'
    | 'DADOS_HISTORICOS';
  label: string;
  detail: string;
}

export interface MarketSourceMetadata {
  available: boolean;
  isPocketOtc: boolean;
  verified: boolean;
  providerName: string;
  providerType: 'POCKET_OTC_BRIDGE' | 'IMPORTED_OTC' | 'UNAVAILABLE';
  fetchedAtMs: number;
  importedAtMs?: number;
  lastCandleTimeMs: number | null;
  isStale: boolean;
  staleReason?: string;
  unavailableReason?: string;
  unavailableMessage?: string;
}

export interface IndicatorSeries {
  emaFast: (number | null)[];
  emaSlow: (number | null)[];
  rsi: (number | null)[];
  macdLine: (number | null)[];
  macdSignal: (number | null)[];
  macdHistogram: (number | null)[];
}

export interface AnalysisResult {
  pair: PairDefinition;
  timeframe: Timeframe;
  source: MarketSourceMetadata;
  candles: Candle[];
  series: IndicatorSeries;
  currentPrice: number | null;
  previousPrice: number | null;
  priceChangePct: number | null;
  latestIndicators: {
    emaFast: number | null;
    emaSlow: number | null;
    rsi: number | null;
    macd: number | null;
    macdSignal: number | null;
    macdHistogram: number | null;
  };
  patterns: CandlePattern[];
  factors: TechnicalFactor[];
  direction: SignalDirection;
  strength: SignalStrength;
  confidence: number;
  entryEstimate: EntryTimingEstimate | null;
  rationale: string;
}

export interface SignalRecord {
  id: string;
  createdAtMs: number;
  candleTimeMs?: number;
  pairId: string;
  pairSymbol: string;
  timeframe: Timeframe;
  direction: SignalDirection;
  strength: SignalStrength;
  confidence: number;
  priceAtSignal: number;
  entryTimeMs: number;
  expirationMinutes: number;
  mode: TradingMode;
  sourceProvider: string;
  isPocketOtc: boolean;
  indicatorsSnapshot: {
    rsi: number | null;
    macdHistogram: number | null;
    emaFast: number | null;
    emaSlow: number | null;
    pattern: string;
  };
  telegramSent: boolean;
  outcome: SignalOutcome;
  notes?: string;
}

export interface AppSettings {
  mode: TradingMode;
  otcBridgeUrl: string;
  otcBridgeApiKey: string;
  telegramBotToken: string;
  telegramChatId: string;
  telegramAutoAlert: boolean;
  telegramAutoSendCaptures: boolean;
  indicatorConfig: IndicatorConfig;
}

export interface ScannerOpportunity {
  pair: PairDefinition;
  timeframe: Timeframe;
  available: boolean;
  direction: SignalDirection;
  strength: SignalStrength;
  confidence: number;
  currentPrice: number | null;
  rsi: number | null;
  emaFast: number | null;
  emaSlow: number | null;
  macdHistogram: number | null;
  entryLabel: string;
  sourceProvider: string;
  isStale: boolean;
  unavailableMessage?: string;
}

export interface ChartImageIndicatorReading {
  visible: boolean;
  summary: string;
  bias: 'UP' | 'DOWN' | 'NEUTRO' | 'INDISPONIVEL';
}

export interface SupportResistanceZone {
  label: string;
  visiblePrice: string | null;
}

export type PriceProximityStatus =
  | 'PROXIMO_SUPORTE'
  | 'PROXIMO_RESISTENCIA'
  | 'ENTRE_ZONAS'
  | 'INDETERMINADO';

export type BreakoutStatus =
  | 'SEM_ROMPIMENTO'
  | 'ROMPIMENTO_ALTA'
  | 'ROMPIMENTO_BAIXA'
  | 'FALSO_ROMPIMENTO_ALTA'
  | 'FALSO_ROMPIMENTO_BAIXA'
  | 'INDETERMINADO';

export type CaptureTrend = 'ALTA' | 'BAIXA' | 'LATERAL' | 'INDETERMINADA';

export interface ChartImageAnalysisResult {
  id: string;
  analyzedAtMs: number;
  pairId: string;
  pairSymbol: string;
  timeframe: Timeframe;
  reliable: boolean;
  unreliableReason?: string;
  detectedPairText?: string | null;
  visiblePriceText?: string | null;
  greenCandlesCount: number;
  redCandlesCount: number;
  recentCandlesSummary: string;
  lastCandlesSequence: string;
  candleTypes: {
    forceCandles: boolean;
    rejectionCandles: boolean;
    dojiDetected: boolean;
    reversalSignal: boolean;
    details: string;
  };
  patterns: Array<{
    name: string;
    bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    description: string;
  }>;
  trend: CaptureTrend;
  trendSummary: string;
  supportResistance: {
    supportZones: SupportResistanceZone[];
    resistanceZones: SupportResistanceZone[];
    priceProximity: PriceProximityStatus;
    breakoutStatus: BreakoutStatus;
    summary: string;
  };
  indicators: {
    rsi: ChartImageIndicatorReading;
    ema: ChartImageIndicatorReading;
    macd: ChartImageIndicatorReading;
  };
  evidenceSummary: {
    sufficientForSignal: boolean;
    criteriaAligned: number;
    notes: string;
  };
  direction: SignalDirection;
  strength: SignalStrength;
  confidence: number;
  rationale: string;
  telegramAutoSent?: boolean;
  telegramAutoError?: string;
}

export interface CaptureComparisonSummary {
  pairId: string;
  pairSymbol: string;
  timeframe: Timeframe;
  totalCaptures: number;
  trendEvolution:
    | 'FORTALECENDO'
    | 'ENFRAQUECENDO'
    | 'ESTAVEL'
    | 'REVERSAO'
    | 'DADOS_INSUFICIENTES';
  summary: string;
  latestCapture: ChartImageAnalysisResult | null;
  previousCapture: ChartImageAnalysisResult | null;
}
