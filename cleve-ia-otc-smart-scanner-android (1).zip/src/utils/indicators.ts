import type {
  AnalysisResult,
  Candle,
  CandlePattern,
  EntryTimingEstimate,
  IndicatorConfig,
  IndicatorSeries,
  MarketSourceMetadata,
  PairDefinition,
  SignalDirection,
  SignalStrength,
  TechnicalFactor,
  Timeframe,
} from '../types/market.ts';

export const DEFAULT_INDICATOR_CONFIG: IndicatorConfig = {
  rsiPeriod: 14,
  rsiOverbought: 70,
  rsiOversold: 30,
  emaFast: 9,
  emaSlow: 21,
  macdFast: 12,
  macdSlow: 26,
  macdSignal: 9,
  minConfidence: 62,
};

export function calculateEMA(values: number[], period: number): (number | null)[] {
  const result: (number | null)[] = new Array(values.length).fill(null);
  if (period <= 0 || values.length < period) {
    return result;
  }

  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += values[i];
  }
  let ema = sum / period;
  result[period - 1] = ema;

  const multiplier = 2 / (period + 1);
  for (let i = period; i < values.length; i++) {
    ema = (values[i] - ema) * multiplier + ema;
    result[i] = ema;
  }

  return result;
}

export function calculateRSI(closes: number[], period: number): (number | null)[] {
  const result: (number | null)[] = new Array(closes.length).fill(null);
  if (period <= 0 || closes.length <= period) {
    return result;
  }

  let gainSum = 0;
  let lossSum = 0;

  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change >= 0) {
      gainSum += change;
    } else {
      lossSum += Math.abs(change);
    }
  }

  let avgGain = gainSum / period;
  let avgLoss = lossSum / period;

  result[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);

  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;

    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;

    if (avgLoss === 0) {
      result[i] = 100;
    } else {
      const rs = avgGain / avgLoss;
      result[i] = 100 - 100 / (1 + rs);
    }
  }

  return result;
}

export function calculateMACD(
  closes: number[],
  fastPeriod: number,
  slowPeriod: number,
  signalPeriod: number
): {
  macdLine: (number | null)[];
  macdSignal: (number | null)[];
  macdHistogram: (number | null)[];
} {
  const emaFast = calculateEMA(closes, fastPeriod);
  const emaSlow = calculateEMA(closes, slowPeriod);

  const macdLine: (number | null)[] = new Array(closes.length).fill(null);
  const validMacdValues: number[] = [];
  const validIndices: number[] = [];

  for (let i = 0; i < closes.length; i++) {
    if (emaFast[i] !== null && emaSlow[i] !== null) {
      const val = emaFast[i]! - emaSlow[i]!;
      macdLine[i] = val;
      validMacdValues.push(val);
      validIndices.push(i);
    }
  }

  const macdSignal: (number | null)[] = new Array(closes.length).fill(null);
  const macdHistogram: (number | null)[] = new Array(closes.length).fill(null);

  const signalFromValid = calculateEMA(validMacdValues, signalPeriod);
  for (let j = 0; j < validIndices.length; j++) {
    const idx = validIndices[j];
    const sig = signalFromValid[j];
    if (sig !== null) {
      macdSignal[idx] = sig;
      macdHistogram[idx] = macdLine[idx]! - sig;
    }
  }

  return { macdLine, macdSignal, macdHistogram };
}

export function detectCandlePatterns(candles: Candle[]): CandlePattern[] {
  const patterns: CandlePattern[] = [];
  if (candles.length < 3) {
    return patterns;
  }

  // Analyze the most recent completed candle (or latest candle if dataset is closed)
  const curr = candles[candles.length - 1];
  const prev = candles[candles.length - 2];

  const currBody = Math.abs(curr.close - curr.open);
  const currRange = Math.max(curr.high - curr.low, 1e-10);
  const currUpperWick = curr.high - Math.max(curr.open, curr.close);
  const currLowerWick = Math.min(curr.open, curr.close) - curr.low;
  const currBull = curr.close > curr.open;
  const currBear = curr.close < curr.open;

  const prevBody = Math.abs(prev.close - prev.open);
  const prevBull = prev.close > prev.open;
  const prevBear = prev.close < prev.open;

  // 1. Doji (indecision)
  if (currBody / currRange <= 0.12) {
    patterns.push({
      name: 'Doji (Indecisão)',
      bias: 'NEUTRAL',
      description: 'Corpo muito estreito indica equilíbrio temporário entre compradores e vendedores.',
      impactPoints: -8,
    });
  }

  // 2. Bullish Engulfing
  if (
    prevBear &&
    currBull &&
    curr.open <= prev.close &&
    curr.close >= prev.open &&
    currBody > prevBody * 1.05
  ) {
    patterns.push({
      name: 'Engolfo de Alta',
      bias: 'BULLISH',
      description: 'Vela compradora envolveu completamente o corpo da vela vendedora anterior.',
      impactPoints: 16,
    });
  }

  // 3. Bearish Engulfing
  if (
    prevBull &&
    currBear &&
    curr.open >= prev.close &&
    curr.close <= prev.open &&
    currBody > prevBody * 1.05
  ) {
    patterns.push({
      name: 'Engolfo de Baixa',
      bias: 'BEARISH',
      description: 'Vela vendedora envolveu completamente o corpo da vela compradora anterior.',
      impactPoints: 16,
    });
  }

  // 4. Hammer / Bullish Pin Bar
  if (
    currLowerWick >= Math.max(currBody * 2, currRange * 0.45) &&
    currUpperWick <= currRange * 0.2
  ) {
    patterns.push({
      name: 'Martelo / Rejeição Inferior',
      bias: 'BULLISH',
      description: 'Pavio inferior longo sinaliza rejeição compradora no suporte recente.',
      impactPoints: 13,
    });
  }

  // 5. Shooting Star / Bearish Pin Bar
  if (
    currUpperWick >= Math.max(currBody * 2, currRange * 0.45) &&
    currLowerWick <= currRange * 0.2
  ) {
    patterns.push({
      name: 'Estrela Cadente / Rejeição Superior',
      bias: 'BEARISH',
      description: 'Pavio superior longo sinaliza rejeição vendedora na resistência recente.',
      impactPoints: 13,
    });
  }

  // 6. Strong Marubozu Momentum
  if (currBody / currRange >= 0.78) {
    if (currBull) {
      patterns.push({
        name: 'Vela de Força Compradora',
        bias: 'BULLISH',
        description: 'Corpo dominante de alta com pavios reduzidos indica pressão compradora ativa.',
        impactPoints: 10,
      });
    } else if (currBear) {
      patterns.push({
        name: 'Vela de Força Vendedora',
        bias: 'BEARISH',
        description: 'Corpo dominante de baixa com pavios reduzidos indica pressão vendedora ativa.',
        impactPoints: 10,
      });
    }
  }

  if (patterns.length === 0) {
    patterns.push({
      name: 'Estrutura Padrão',
      bias: currBull ? 'BULLISH' : currBear ? 'BEARISH' : 'NEUTRAL',
      description: 'Sem padrão extremo de reversão; vela acompanha o fluxo imediato.',
      impactPoints: 4,
    });
  }

  return patterns;
}

export function computeEntryTiming(
  timeframe: Timeframe,
  source: MarketSourceMetadata,
  direction: SignalDirection,
  nowMs: number = Date.now()
): EntryTimingEstimate {
  const intervalMs = timeframe === '1m' ? 60_000 : 300_000;
  const expirationMinutes = timeframe === '1m' ? 1 : 5;

  if (source.providerType === 'IMPORTED_OTC' || source.isStale) {
    const lastTime = source.lastCandleTimeMs ?? nowMs;
    const nextEntryTimeMs = lastTime + intervalMs;
    return {
      nextEntryTimeMs,
      secondsUntilEntry: 0,
      expirationMinutes,
      timingStatus: 'DADOS_HISTORICOS',
      label: 'Baseado na última vela do ficheiro',
      detail:
        source.providerType === 'IMPORTED_OTC'
          ? 'Conjunto OTC importado manualmente: valide com a hora atual antes de operar.'
          : 'Mercado ou feed sem atualização recente — aguarde nova vela em tempo real.',
    };
  }

  const currentBucketStart = Math.floor(nowMs / intervalMs) * intervalMs;
  const elapsedInCandleSec = Math.floor((nowMs - currentBucketStart) / 1000);
  const nextCandleTime = currentBucketStart + intervalMs;
  const secondsUntilNext = Math.max(0, Math.ceil((nextCandleTime - nowMs) / 1000));

  if (direction === 'NEUTRO') {
    return {
      nextEntryTimeMs: nextCandleTime,
      secondsUntilEntry: secondsUntilNext,
      expirationMinutes,
      timingStatus: 'AGUARDAR_CONFIRMACAO',
      label: 'Aguardar confirmação de tendência',
      detail: `Sem confluência suficiente nesta vela. Reavaliar no fecho em ${secondsUntilNext}s.`,
    };
  }

  // If we are in the first 10 seconds of a newly opened candle, entry window is active now
  if (elapsedInCandleSec <= 10) {
    return {
      nextEntryTimeMs: currentBucketStart,
      secondsUntilEntry: 0,
      expirationMinutes,
      timingStatus: 'JANELA_ABERTURA_ATIVA',
      label: 'Janela de abertura ativa agora',
      detail: `Vela ${timeframe.toUpperCase()} recém-aberta (${elapsedInCandleSec}s). Expiração sugerida: ${expirationMinutes} min.`,
    };
  }

  return {
    nextEntryTimeMs: nextCandleTime,
    secondsUntilEntry: secondsUntilNext,
    expirationMinutes,
    timingStatus: 'PREPARAR_PROXIMA_VELA',
    label: 'Entrada estimada na próxima vela',
    detail: `Aguardar fecho da vela atual (${secondsUntilNext}s) para confirmar entrada de ${expirationMinutes} min.`,
  };
}

export function formatTimeHHMMSS(ms: number): string {
  const d = new Date(ms);
  return d.toLocaleTimeString('pt-PT', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}

export function formatDateTimePT(ms: number): string {
  const d = new Date(ms);
  return d.toLocaleString('pt-PT', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}

export function strengthToLabel(strength: SignalStrength): string {
  switch (strength) {
    case 'MUITO_FORTE':
      return 'Muito Forte';
    case 'FORTE':
      return 'Forte';
    case 'MODERADA':
      return 'Moderada';
    case 'FRACA':
      return 'Fraca';
    default:
      return 'Sem Confluência';
  }
}

export function analyzeMarket(
  candles: Candle[],
  pair: PairDefinition,
  timeframe: Timeframe,
  config: IndicatorConfig,
  source: MarketSourceMetadata,
  nowMs: number = Date.now()
): AnalysisResult {
  if (!source.available || candles.length < 30) {
    return {
      pair,
      timeframe,
      source,
      candles,
      series: {
        emaFast: [],
        emaSlow: [],
        rsi: [],
        macdLine: [],
        macdSignal: [],
        macdHistogram: [],
      },
      currentPrice: candles.length > 0 ? candles[candles.length - 1].close : null,
      previousPrice: candles.length > 1 ? candles[candles.length - 2].close : null,
      priceChangePct: null,
      latestIndicators: {
        emaFast: null,
        emaSlow: null,
        rsi: null,
        macd: null,
        macdSignal: null,
        macdHistogram: null,
      },
      patterns: [],
      factors: [],
      direction: 'NEUTRO',
      strength: 'SEM_CONFLUENCIA',
      confidence: 0,
      entryEstimate: null,
      rationale:
        source.unavailableMessage ||
        'Sem velas verificáveis suficientes (mínimo 30 velas) para calcular EMA 21 e MACD (26).',
    };
  }

  const closes = candles.map((c) => c.close);
  const emaFastSeries = calculateEMA(closes, config.emaFast);
  const emaSlowSeries = calculateEMA(closes, config.emaSlow);
  const rsiSeries = calculateRSI(closes, config.rsiPeriod);
  const { macdLine, macdSignal, macdHistogram } = calculateMACD(
    closes,
    config.macdFast,
    config.macdSlow,
    config.macdSignal
  );

  const series: IndicatorSeries = {
    emaFast: emaFastSeries,
    emaSlow: emaSlowSeries,
    rsi: rsiSeries,
    macdLine,
    macdSignal,
    macdHistogram,
  };

  const last = candles.length - 1;
  const prev = candles.length - 2;

  const currentPrice = closes[last];
  const previousPrice = closes[prev];
  const priceChangePct =
    previousPrice !== 0 ? ((currentPrice - previousPrice) / previousPrice) * 100 : 0;

  const emaF = emaFastSeries[last];
  const emaFPrev = emaFastSeries[prev];
  const emaS = emaSlowSeries[last];
  const emaSPrev = emaSlowSeries[prev];
  const rsi = rsiSeries[last];
  const rsiPrev = rsiSeries[prev];
  const macd = macdLine[last];
  const sig = macdSignal[last];
  const hist = macdHistogram[last];
  const histPrev = macdHistogram[prev];

  let upPoints = 0;
  let downPoints = 0;
  const factors: TechnicalFactor[] = [];

  // Factor 1: EMA 9 & EMA 21 (max 28 pts)
  if (emaF !== null && emaS !== null && emaFPrev !== null && emaSPrev !== null) {
    const bullishCross = emaFPrev <= emaSPrev && emaF > emaS;
    const bearishCross = emaFPrev >= emaSPrev && emaF < emaS;

    if (bullishCross) {
      upPoints += 28;
      factors.push({
        id: 'ema',
        label: `EMA ${config.emaFast} / EMA ${config.emaSlow}`,
        valueText: `${emaF.toFixed(pair.decimals)} > ${emaS.toFixed(pair.decimals)}`,
        bias: 'UP',
        summary: `Cruzamento de alta recente: EMA ${config.emaFast} cruzou acima da EMA ${config.emaSlow}.`,
        points: 28,
      });
    } else if (bearishCross) {
      downPoints += 28;
      factors.push({
        id: 'ema',
        label: `EMA ${config.emaFast} / EMA ${config.emaSlow}`,
        valueText: `${emaF.toFixed(pair.decimals)} < ${emaS.toFixed(pair.decimals)}`,
        bias: 'DOWN',
        summary: `Cruzamento de baixa recente: EMA ${config.emaFast} cruzou abaixo da EMA ${config.emaSlow}.`,
        points: 28,
      });
    } else if (emaF > emaS && currentPrice >= emaF) {
      upPoints += 22;
      factors.push({
        id: 'ema',
        label: `EMA ${config.emaFast} / EMA ${config.emaSlow}`,
        valueText: `Tendência Alta`,
        bias: 'UP',
        summary: `Preço acima da EMA ${config.emaFast} e EMA ${config.emaFast} > EMA ${config.emaSlow}.`,
        points: 22,
      });
    } else if (emaF < emaS && currentPrice <= emaF) {
      downPoints += 22;
      factors.push({
        id: 'ema',
        label: `EMA ${config.emaFast} / EMA ${config.emaSlow}`,
        valueText: `Tendência Baixa`,
        bias: 'DOWN',
        summary: `Preço abaixo da EMA ${config.emaFast} e EMA ${config.emaFast} < EMA ${config.emaSlow}.`,
        points: 22,
      });
    } else if (emaF > emaS) {
      upPoints += 12;
      factors.push({
        id: 'ema',
        label: `EMA ${config.emaFast} / EMA ${config.emaSlow}`,
        valueText: `Viés Alta (Pullback)`,
        bias: 'UP',
        summary: `EMA ${config.emaFast} acima da EMA ${config.emaSlow}, preço em retração.`,
        points: 12,
      });
    } else {
      downPoints += 12;
      factors.push({
        id: 'ema',
        label: `EMA ${config.emaFast} / EMA ${config.emaSlow}`,
        valueText: `Viés Baixa (Pullback)`,
        bias: 'DOWN',
        summary: `EMA ${config.emaFast} abaixo da EMA ${config.emaSlow}, preço em retração.`,
        points: 12,
      });
    }
  }

  // Factor 2: RSI (max 22 pts)
  if (rsi !== null && rsiPrev !== null) {
    if (rsi <= config.rsiOversold && rsi > rsiPrev) {
      upPoints += 22;
      factors.push({
        id: 'rsi',
        label: `RSI (${config.rsiPeriod})`,
        valueText: rsi.toFixed(1),
        bias: 'UP',
        summary: `Sobrevenda (${rsi.toFixed(1)} <= ${config.rsiOversold}) com viragem compradora.`,
        points: 22,
      });
    } else if (rsi >= config.rsiOverbought && rsi < rsiPrev) {
      downPoints += 22;
      factors.push({
        id: 'rsi',
        label: `RSI (${config.rsiPeriod})`,
        valueText: rsi.toFixed(1),
        bias: 'DOWN',
        summary: `Sobrecompra (${rsi.toFixed(1)} >= ${config.rsiOverbought}) com viragem vendedora.`,
        points: 22,
      });
    } else if (rsi >= 52 && rsi < config.rsiOverbought && rsi >= rsiPrev) {
      upPoints += 16;
      factors.push({
        id: 'rsi',
        label: `RSI (${config.rsiPeriod})`,
        valueText: rsi.toFixed(1),
        bias: 'UP',
        summary: `Momento comprador saudável acima da linha média 50.`,
        points: 16,
      });
    } else if (rsi <= 48 && rsi > config.rsiOversold && rsi <= rsiPrev) {
      downPoints += 16;
      factors.push({
        id: 'rsi',
        label: `RSI (${config.rsiPeriod})`,
        valueText: rsi.toFixed(1),
        bias: 'DOWN',
        summary: `Momento vendedor saudável abaixo da linha média 50.`,
        points: 16,
      });
    } else if (rsi >= config.rsiOverbought) {
      downPoints += 10;
      factors.push({
        id: 'rsi',
        label: `RSI (${config.rsiPeriod})`,
        valueText: rsi.toFixed(1),
        bias: 'DOWN',
        summary: `Zona de sobrecompra (${rsi.toFixed(1)}): risco elevado para novas compras.`,
        points: 10,
      });
    } else if (rsi <= config.rsiOversold) {
      upPoints += 10;
      factors.push({
        id: 'rsi',
        label: `RSI (${config.rsiPeriod})`,
        valueText: rsi.toFixed(1),
        bias: 'UP',
        summary: `Zona de sobrevenda (${rsi.toFixed(1)}): possível reação compradora.`,
        points: 10,
      });
    } else {
      factors.push({
        id: 'rsi',
        label: `RSI (${config.rsiPeriod})`,
        valueText: rsi.toFixed(1),
        bias: 'NEUTRO',
        summary: `RSI neutro próximo de 50 sem direção predominante.`,
        points: 0,
      });
    }
  }

  // Factor 3: MACD (max 24 pts)
  if (macd !== null && sig !== null && hist !== null && histPrev !== null) {
    const bullishCross = histPrev <= 0 && hist > 0;
    const bearishCross = histPrev >= 0 && hist < 0;

    if (bullishCross) {
      upPoints += 24;
      factors.push({
        id: 'macd',
        label: `MACD (${config.macdFast},${config.macdSlow},${config.macdSignal})`,
        valueText: `+${hist.toFixed(pair.decimals + 1)}`,
        bias: 'UP',
        summary: 'Cruzamento positivo da linha MACD acima da linha de sinal.',
        points: 24,
      });
    } else if (bearishCross) {
      downPoints += 24;
      factors.push({
        id: 'macd',
        label: `MACD (${config.macdFast},${config.macdSlow},${config.macdSignal})`,
        valueText: hist.toFixed(pair.decimals + 1),
        bias: 'DOWN',
        summary: 'Cruzamento negativo da linha MACD abaixo da linha de sinal.',
        points: 24,
      });
    } else if (hist > 0 && hist >= histPrev) {
      upPoints += 18;
      factors.push({
        id: 'macd',
        label: `MACD (${config.macdFast},${config.macdSlow},${config.macdSignal})`,
        valueText: `+${hist.toFixed(pair.decimals + 1)}`,
        bias: 'UP',
        summary: 'Histograma positivo em expansão confirma impulso de alta.',
        points: 18,
      });
    } else if (hist < 0 && hist <= histPrev) {
      downPoints += 18;
      factors.push({
        id: 'macd',
        label: `MACD (${config.macdFast},${config.macdSlow},${config.macdSignal})`,
        valueText: hist.toFixed(pair.decimals + 1),
        bias: 'DOWN',
        summary: 'Histograma negativo em expansão confirma impulso de baixa.',
        points: 18,
      });
    } else if (hist > 0) {
      upPoints += 9;
      factors.push({
        id: 'macd',
        label: `MACD (${config.macdFast},${config.macdSlow},${config.macdSignal})`,
        valueText: `+${hist.toFixed(pair.decimals + 1)}`,
        bias: 'UP',
        summary: 'Histograma positivo, porém com perda gradual de aceleração.',
        points: 9,
      });
    } else {
      downPoints += 9;
      factors.push({
        id: 'macd',
        label: `MACD (${config.macdFast},${config.macdSlow},${config.macdSignal})`,
        valueText: hist.toFixed(pair.decimals + 1),
        bias: 'DOWN',
        summary: 'Histograma negativo, porém com perda gradual de aceleração.',
        points: 9,
      });
    }
  }

  // Factor 4: Candlestick Patterns (max 16 pts)
  const patterns = detectCandlePatterns(candles);
  let patternNet = 0;
  for (const p of patterns) {
    if (p.bias === 'BULLISH') patternNet += p.impactPoints;
    else if (p.bias === 'BEARISH') patternNet -= p.impactPoints;
  }

  const primaryPattern = patterns[0];
  if (patternNet > 0) {
    const pts = Math.min(16, patternNet);
    upPoints += pts;
    factors.push({
      id: 'candles',
      label: 'Análise de Velas',
      valueText: primaryPattern.name,
      bias: 'UP',
      summary: primaryPattern.description,
      points: pts,
    });
  } else if (patternNet < 0) {
    const pts = Math.min(16, Math.abs(patternNet));
    downPoints += pts;
    factors.push({
      id: 'candles',
      label: 'Análise de Velas',
      valueText: primaryPattern.name,
      bias: 'DOWN',
      summary: primaryPattern.description,
      points: pts,
    });
  } else {
    factors.push({
      id: 'candles',
      label: 'Análise de Velas',
      valueText: primaryPattern.name,
      bias: 'NEUTRO',
      summary: primaryPattern.description,
      points: 0,
    });
  }

  // Factor 5: Last 3 candles momentum (max 10 pts)
  const lastThree = candles.slice(-3);
  const bullCount = lastThree.filter((c) => c.close > c.open).length;
  const bearCount = lastThree.filter((c) => c.close < c.open).length;
  if (bullCount === 3) {
    upPoints += 10;
    factors.push({
      id: 'flow',
      label: 'Sequência Recente',
      valueText: '3 velas de alta',
      bias: 'UP',
      summary: 'Três fechos consecutivos positivos reforçam a pressão compradora.',
      points: 10,
    });
  } else if (bearCount === 3) {
    downPoints += 10;
    factors.push({
      id: 'flow',
      label: 'Sequência Recente',
      valueText: '3 velas de baixa',
      bias: 'DOWN',
      summary: 'Três fechos consecutivos negativos reforçam a pressão vendedora.',
      points: 10,
    });
  } else if (bullCount >= 2 && lastThree[2].close > lastThree[2].open) {
    upPoints += 6;
    factors.push({
      id: 'flow',
      label: 'Sequência Recente',
      valueText: '2/3 velas de alta',
      bias: 'UP',
      summary: 'Maioria das últimas 3 velas com fecho positivo.',
      points: 6,
    });
  } else if (bearCount >= 2 && lastThree[2].close < lastThree[2].open) {
    downPoints += 6;
    factors.push({
      id: 'flow',
      label: 'Sequência Recente',
      valueText: '2/3 velas de baixa',
      bias: 'DOWN',
      summary: 'Maioria das últimas 3 velas com fecho negativo.',
      points: 6,
    });
  } else {
    factors.push({
      id: 'flow',
      label: 'Sequência Recente',
      valueText: 'Mista',
      bias: 'NEUTRO',
      summary: 'Alternância entre velas compradoras e vendedoras.',
      points: 0,
    });
  }

  const hasDojiPenalty = patterns.some((p) => p.bias === 'NEUTRAL' && p.impactPoints < 0);
  const net = upPoints - downPoints;
  const dominantPoints = Math.max(upPoints, downPoints);
  const opposingPoints = Math.min(upPoints, downPoints);

  // Confidence calculation: dominant score minus opposing conflict & doji penalty
  // Bounded strictly between 0% and 92% (never claiming 100% certainty)
  let rawConfidence = dominantPoints - Math.round(opposingPoints * 0.45);
  if (hasDojiPenalty) {
    rawConfidence -= 8;
  }
  if (source.isStale) {
    rawConfidence = Math.min(rawConfidence, 45);
  }
  const confidence = Math.max(0, Math.min(92, rawConfidence));

  let direction: SignalDirection = 'NEUTRO';
  if (!source.isStale && Math.abs(net) >= 18 && confidence >= 52) {
    direction = net > 0 ? 'UP' : 'DOWN';
  }

  let strength: SignalStrength = 'SEM_CONFLUENCIA';
  if (direction === 'NEUTRO') {
    strength = 'SEM_CONFLUENCIA';
  } else if (confidence >= 80) {
    strength = 'MUITO_FORTE';
  } else if (confidence >= 70) {
    strength = 'FORTE';
  } else if (confidence >= 58) {
    strength = 'MODERADA';
  } else {
    strength = 'FRACA';
  }

  const entryEstimate = computeEntryTiming(timeframe, source, direction, nowMs);

  let rationale = '';
  if (source.isStale) {
    rationale =
      'Os dados recebidos estão desatualizados (mercado spot fechado ou histórico). Não são gerados sinais ativos.';
  } else if (direction === 'NEUTRO') {
    rationale = `Sem confluência clara (${upPoints} pts alta vs ${downPoints} pts baixa). Recomenda-se aguardar definição dos indicadores.`;
  } else {
    const dirLabel = direction === 'UP' ? 'UP (Compra)' : 'DOWN (Venda)';
    rationale = `Confluência técnica para ${dirLabel}: ${upPoints} pts de alta contra ${downPoints} pts de baixa, com confiança estimada de ${confidence}%.`;
  }

  return {
    pair,
    timeframe,
    source,
    candles,
    series,
    currentPrice,
    previousPrice,
    priceChangePct,
    latestIndicators: {
      emaFast: emaF,
      emaSlow: emaS,
      rsi,
      macd,
      macdSignal: sig,
      macdHistogram: hist,
    },
    patterns,
    factors,
    direction,
    strength,
    confidence,
    entryEstimate,
    rationale,
  };
}
