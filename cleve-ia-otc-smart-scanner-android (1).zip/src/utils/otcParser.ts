import type { Candle } from '../types/market.ts';

export interface OtcValidationResult {
  valid: boolean;
  candles: Candle[];
  totalRows: number;
  validCount: number;
  rejectedCount: number;
  firstCandleTimeMs: number | null;
  lastCandleTimeMs: number | null;
  errors: string[];
}

function stripAccents(value: string): string {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

function parseNumeric(raw: string | undefined, allowCommaDecimal: boolean): number {
  if (!raw) return NaN;
  let cleaned = raw.trim().replace(/\s+/g, '');
  if (allowCommaDecimal && cleaned.includes(',') && !cleaned.includes('.')) {
    cleaned = cleaned.replace(',', '.');
  }
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : NaN;
}

function parseDateAndTime(dateRaw: string | undefined, timeRaw: string | undefined): number {
  const dStr = (dateRaw ?? '').trim();
  const tStr = (timeRaw ?? '').trim();

  // Case 1: Combined single numeric timestamp
  if (dStr && !tStr) {
    const asNum = Number(dStr);
    if (Number.isFinite(asNum) && dStr !== '') {
      return asNum < 1e12 ? asNum * 1000 : asNum;
    }
  }

  // Extract date parts if DD/MM/YYYY or DD-MM-YYYY
  let isoDatePart = dStr;
  const ddmmyyyy = dStr.match(/^(\d{2})[\/\-](\d{2})[\/\-](\d{4})(?:\s+(.*))?$/);
  if (ddmmyyyy) {
    const [, day, month, year, rest] = ddmmyyyy;
    isoDatePart = `${year}-${month}-${day}${rest ? ` ${rest}` : ''}`;
  } else {
    const yyyymmddSlash = dStr.match(/^(\d{4})\/(\d{2})\/(\d{2})(?:\s+(.*))?$/);
    if (yyyymmddSlash) {
      const [, year, month, day, rest] = yyyymmddSlash;
      isoDatePart = `${year}-${month}-${day}${rest ? ` ${rest}` : ''}`;
    }
  }

  if (isoDatePart && tStr) {
    // Normalize HH:MM to HH:MM:00
    const normTime = /^\d{1,2}:\d{2}$/.test(tStr) ? `${tStr}:00` : tStr;
    const normDateTime = `${isoDatePart}T${normTime}`;
    const parsed = Date.parse(normDateTime);
    if (Number.isFinite(parsed)) return parsed;
    const fallback = Date.parse(`${isoDatePart} ${normTime}`);
    if (Number.isFinite(fallback)) return fallback;
  }

  if (isoDatePart) {
    const parsed = Date.parse(isoDatePart);
    if (Number.isFinite(parsed)) return parsed;
  }

  return NaN;
}

function validateCandleGeometry(
  open: number,
  high: number,
  low: number,
  close: number,
  timeMs: number
): string | null {
  if (!Number.isFinite(timeMs) || timeMs <= 0) {
    return 'data/hora inválida';
  }
  if (
    !Number.isFinite(open) ||
    !Number.isFinite(high) ||
    !Number.isFinite(low) ||
    !Number.isFinite(close) ||
    open <= 0 ||
    high <= 0 ||
    low <= 0 ||
    close <= 0
  ) {
    return 'valores OHLC inválidos ou negativos';
  }
  if (high < low) {
    return 'máxima inferior à mínima';
  }
  if (high < Math.max(open, close) - 1e-9) {
    return 'máxima inferior à abertura/fecho';
  }
  if (low > Math.min(open, close) + 1e-9) {
    return 'mínima superior à abertura/fecho';
  }
  return null;
}

export function validateAndParseOtcInput(
  rawText: string,
  expectedPairSymbol?: string
): OtcValidationResult {
  const trimmed = rawText.trim();
  if (!trimmed) {
    return {
      valid: false,
      candles: [],
      totalRows: 0,
      validCount: 0,
      rejectedCount: 0,
      firstCandleTimeMs: null,
      lastCandleTimeMs: null,
      errors: ['Nenhum conteúdo fornecido para validação.'],
    };
  }

  const errors: string[] = [];
  const validCandles: Candle[] = [];
  let totalRows = 0;
  let rejectedCount = 0;

  // JSON format support
  if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed) as unknown;
      let items: unknown[] = [];
      if (Array.isArray(parsed)) {
        items = parsed;
      } else if (parsed && typeof parsed === 'object') {
        const obj = parsed as Record<string, unknown>;
        if (obj.isOtc === false) {
          return {
            valid: false,
            candles: [],
            totalRows: 0,
            validCount: 0,
            rejectedCount: 0,
            firstCandleTimeMs: null,
            lastCandleTimeMs: null,
            errors: ['Dados identificados como não-OTC. Importe apenas velas OTC reais.'],
          };
        }
        if (Array.isArray(obj.candles)) items = obj.candles;
        else if (Array.isArray(obj.data)) items = obj.data;
      }

      totalRows = items.length;
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (!item || typeof item !== 'object') {
          rejectedCount++;
          continue;
        }
        const row = item as Record<string, unknown>;
        const dateVal = row.data ?? row.date;
        const timeVal = row.hora ?? row.time ?? row.timestamp ?? row.t ?? row.datetime;
        let timeMs = NaN;
        if (typeof timeVal === 'number') {
          timeMs = timeVal < 1e12 ? timeVal * 1000 : timeVal;
        } else {
          timeMs = parseDateAndTime(
            dateVal !== undefined ? String(dateVal) : timeVal !== undefined ? String(timeVal) : '',
            dateVal !== undefined && timeVal !== undefined ? String(timeVal) : undefined
          );
        }

        const open = Number(row.abertura ?? row.open ?? row.o);
        const high = Number(row.maxima ?? row.high ?? row.h);
        const low = Number(row.minima ?? row.low ?? row.l);
        const close = Number(row.fecho ?? row.fechamento ?? row.close ?? row.c);
        const volumeRaw = row.volume ?? row.vol ?? row.v;
        const volume = volumeRaw !== undefined ? Number(volumeRaw) : undefined;

        const geomErr = validateCandleGeometry(open, high, low, close, timeMs);
        if (geomErr) {
          rejectedCount++;
          if (errors.length < 3) {
            errors.push(`Registo #${i + 1}: ${geomErr}.`);
          }
          continue;
        }

        validCandles.push({
          time: timeMs,
          open,
          high,
          low,
          close,
          ...(volume !== undefined && Number.isFinite(volume) ? { volume } : {}),
        });
      }
    } catch {
      return {
        valid: false,
        candles: [],
        totalRows: 0,
        validCount: 0,
        rejectedCount: 0,
        firstCandleTimeMs: null,
        lastCandleTimeMs: null,
        errors: ['JSON inválido. Verifique a sintaxe do ficheiro.'],
      };
    }
  } else {
    // CSV format (comma, semicolon, or tab)
    const lines = trimmed
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length < 2) {
      return {
        valid: false,
        candles: [],
        totalRows: lines.length,
        validCount: 0,
        rejectedCount: lines.length,
        firstCandleTimeMs: null,
        lastCandleTimeMs: null,
        errors: ['O ficheiro CSV deve conter cabeçalho e pelo menos 30 velas OTC válidas.'],
      };
    }

    const firstLine = lines[0];
    const delimiter = firstLine.includes(';')
      ? ';'
      : firstLine.includes('\t')
        ? '\t'
        : ',';
    const allowCommaDecimal = delimiter === ';' || delimiter === '\t';

    const rawCols = firstLine.split(delimiter).map(stripAccents);
    const hasHeader = rawCols.some((c) =>
      [
        'data',
        'date',
        'hora',
        'time',
        'timestamp',
        'datetime',
        'abertura',
        'open',
        'maxima',
        'high',
        'minima',
        'low',
        'fecho',
        'fechamento',
        'close',
      ].includes(c)
    );

    const startIdx = hasHeader ? 1 : 0;
    const findIdx = (aliases: string[]) =>
      rawCols.findIndex((c) => aliases.includes(c));

    const idxDate = hasHeader ? findIdx(['data', 'date', 'dia']) : -1;
    const idxTime = hasHeader ? findIdx(['hora', 'time', 'horario', 'hour']) : -1;
    const idxTimestamp = hasHeader
      ? findIdx(['timestamp', 'datetime', 'datahora'])
      : -1;
    const idxOpen = hasHeader ? findIdx(['abertura', 'open', 'o']) : -1;
    const idxHigh = hasHeader ? findIdx(['maxima', 'max', 'high', 'h']) : -1;
    const idxLow = hasHeader ? findIdx(['minima', 'min', 'low', 'l']) : -1;
    const idxClose = hasHeader ? findIdx(['fecho', 'fechamento', 'close', 'c']) : -1;
    const idxVol = hasHeader ? findIdx(['volume', 'vol', 'v']) : -1;
    const idxPair = hasHeader ? findIdx(['par', 'pair', 'symbol', 'ativo']) : -1;
    const idxSource = hasHeader ? findIdx(['fonte', 'source', 'mercado', 'tipo']) : -1;

    if (hasHeader && (idxOpen === -1 || idxHigh === -1 || idxLow === -1 || idxClose === -1)) {
      return {
        valid: false,
        candles: [],
        totalRows: lines.length - 1,
        validCount: 0,
        rejectedCount: lines.length - 1,
        firstCandleTimeMs: null,
        lastCandleTimeMs: null,
        errors: [
          'Cabeçalho CSV incompleto. Inclua colunas para abertura, máxima, mínima e fecho (ex: data,hora,abertura,maxima,minima,fecho).',
        ],
      };
    }

    if (hasHeader && idxDate === -1 && idxTime === -1 && idxTimestamp === -1) {
      return {
        valid: false,
        candles: [],
        totalRows: lines.length - 1,
        validCount: 0,
        rejectedCount: lines.length - 1,
        firstCandleTimeMs: null,
        lastCandleTimeMs: null,
        errors: [
          'Cabeçalho CSV sem coluna de data/hora. Inclua data e hora (ou timestamp).',
        ],
      };
    }

    totalRows = lines.length - startIdx;
    const normExpectedPair = expectedPairSymbol
      ? expectedPairSymbol.replace(/[^A-Z0-9]/gi, '').toUpperCase()
      : '';

    for (let i = startIdx; i < lines.length; i++) {
      const cols = lines[i].split(delimiter).map((c) => c.trim());

      if (hasHeader && idxPair !== -1 && cols[idxPair] && normExpectedPair) {
        const rowPairNorm = cols[idxPair].replace(/[^A-Z0-9]/gi, '').toUpperCase();
        if (rowPairNorm && rowPairNorm !== normExpectedPair) {
          return {
            valid: false,
            candles: [],
            totalRows,
            validCount: 0,
            rejectedCount: totalRows,
            firstCandleTimeMs: null,
            lastCandleTimeMs: null,
            errors: [
              `O ficheiro contém dados do par "${cols[idxPair]}", mas o par selecionado é "${expectedPairSymbol}".`,
            ],
          };
        }
      }

      if (hasHeader && idxSource !== -1 && cols[idxSource]) {
        const srcUpper = cols[idxSource].toUpperCase();
        if (
          (srcUpper.includes('FOREX') ||
            srcUpper.includes('SPOT') ||
            srcUpper.includes('KRAKEN') ||
            srcUpper.includes('YAHOO')) &&
          !srcUpper.includes('OTC')
        ) {
          return {
            valid: false,
            candles: [],
            totalRows,
            validCount: 0,
            rejectedCount: totalRows,
            firstCandleTimeMs: null,
            lastCandleTimeMs: null,
            errors: [
              `Fonte rejeitada ("${cols[idxSource]}"): não utilize dados de Forex tradicional ou outras fontes como se fossem OTC.`,
            ],
          };
        }
      }

      let timeMs = NaN;
      let open = NaN;
      let high = NaN;
      let low = NaN;
      let close = NaN;
      let volume: number | undefined;

      if (hasHeader) {
        if (idxTimestamp !== -1 && cols[idxTimestamp]) {
          timeMs = parseDateAndTime(cols[idxTimestamp], undefined);
        } else if (idxDate !== -1 && idxTime !== -1) {
          timeMs = parseDateAndTime(cols[idxDate], cols[idxTime]);
        } else if (idxDate !== -1) {
          timeMs = parseDateAndTime(cols[idxDate], undefined);
        } else if (idxTime !== -1) {
          timeMs = parseDateAndTime(cols[idxTime], undefined);
        }

        open = parseNumeric(cols[idxOpen], allowCommaDecimal);
        high = parseNumeric(cols[idxHigh], allowCommaDecimal);
        low = parseNumeric(cols[idxLow], allowCommaDecimal);
        close = parseNumeric(cols[idxClose], allowCommaDecimal);
        if (idxVol !== -1 && cols[idxVol]) {
          const v = parseNumeric(cols[idxVol], allowCommaDecimal);
          if (Number.isFinite(v)) volume = v;
        }
      } else {
        // Headerless: either 6+ cols (data,hora,open,high,low,close[,vol]) or 5 cols (timestamp,open,high,low,close)
        if (cols.length >= 6 && Number.isNaN(Number(cols[1]))) {
          // Wait: check if cols[1] is HH:MM (non-numeric) -> data, hora, O, H, L, C
          timeMs = parseDateAndTime(cols[0], cols[1]);
          open = parseNumeric(cols[2], allowCommaDecimal);
          high = parseNumeric(cols[3], allowCommaDecimal);
          low = parseNumeric(cols[4], allowCommaDecimal);
          close = parseNumeric(cols[5], allowCommaDecimal);
          if (cols[6]) {
            const v = parseNumeric(cols[6], allowCommaDecimal);
            if (Number.isFinite(v)) volume = v;
          }
        } else if (cols.length >= 5) {
          timeMs = parseDateAndTime(cols[0], undefined);
          open = parseNumeric(cols[1], allowCommaDecimal);
          high = parseNumeric(cols[2], allowCommaDecimal);
          low = parseNumeric(cols[3], allowCommaDecimal);
          close = parseNumeric(cols[4], allowCommaDecimal);
          if (cols[5]) {
            const v = parseNumeric(cols[5], allowCommaDecimal);
            if (Number.isFinite(v)) volume = v;
          }
        }
      }

      const geomErr = validateCandleGeometry(open, high, low, close, timeMs);
      if (geomErr) {
        rejectedCount++;
        if (errors.length < 3) {
          errors.push(`Linha ${i + 1}: ${geomErr}.`);
        }
        continue;
      }

      validCandles.push({
        time: timeMs,
        open,
        high,
        low,
        close,
        ...(volume !== undefined ? { volume } : {}),
      });
    }
  }

  // Deduplicate by timestamp and sort ascending
  const byTime = new Map<number, Candle>();
  for (const c of validCandles) {
    byTime.set(c.time, c);
  }
  const sorted = Array.from(byTime.values())
    .sort((a, b) => a.time - b.time)
    .slice(-150);

  if (sorted.length < 30) {
    errors.unshift(
      `Encontradas apenas ${sorted.length} velas OTC válidas. São necessárias pelo menos 30 velas para calcular EMA 21 e MACD (12, 26, 9).`
    );
  }

  return {
    valid: sorted.length >= 30,
    candles: sorted,
    totalRows,
    validCount: sorted.length,
    rejectedCount,
    firstCandleTimeMs: sorted.length > 0 ? sorted[0].time : null,
    lastCandleTimeMs: sorted.length > 0 ? sorted[sorted.length - 1].time : null,
    errors,
  };
}
