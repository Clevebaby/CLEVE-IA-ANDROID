import type {
  BreakoutStatus,
  CaptureComparisonSummary,
  CaptureTrend,
  PriceProximityStatus,
} from '../types/market.ts';

export function formatTrendLabel(trend: CaptureTrend): string {
  switch (trend) {
    case 'ALTA':
      return 'Alta';
    case 'BAIXA':
      return 'Baixa';
    case 'LATERAL':
      return 'Lateralização';
    default:
      return 'Indeterminada';
  }
}

export function formatProximityLabel(status: PriceProximityStatus): string {
  switch (status) {
    case 'PROXIMO_SUPORTE':
      return 'Próximo de Suporte';
    case 'PROXIMO_RESISTENCIA':
      return 'Próximo de Resistência';
    case 'ENTRE_ZONAS':
      return 'Entre Suporte e Resistência';
    default:
      return 'Proximidade não determinada';
  }
}

export function formatBreakoutLabel(status: BreakoutStatus): string {
  switch (status) {
    case 'ROMPIMENTO_ALTA':
      return 'Possível rompimento de alta';
    case 'ROMPIMENTO_BAIXA':
      return 'Possível rompimento de baixa';
    case 'FALSO_ROMPIMENTO_ALTA':
      return 'Possível falso rompimento de alta';
    case 'FALSO_ROMPIMENTO_BAIXA':
      return 'Possível falso rompimento de baixa';
    case 'SEM_ROMPIMENTO':
      return 'Sem rompimento ativo';
    default:
      return 'Não determinado';
  }
}

export function formatTrendEvolutionLabel(
  evolution: CaptureComparisonSummary['trendEvolution']
): { label: string; toneClass: string } {
  switch (evolution) {
    case 'FORTALECENDO':
      return { label: 'Tendência a fortalecer', toneClass: 'text-emerald-400' };
    case 'ENFRAQUECENDO':
      return { label: 'Tendência a enfraquecer', toneClass: 'text-amber-300' };
    case 'REVERSAO':
      return { label: 'Mudança / possível reversão', toneClass: 'text-red-400' };
    case 'ESTAVEL':
      return { label: 'Tendência estável', toneClass: 'text-sky-300' };
    default:
      return { label: 'Aguardar mais capturas', toneClass: 'text-slate-400' };
  }
}
