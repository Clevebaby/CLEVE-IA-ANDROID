const API_BASE_STORAGE_KEY = 'pocket_ai_otc_api_base_url';

export function getEnvApiBaseUrl(): string {
  const envVal = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? '';
  return envVal.trim().replace(/\/+$/, '');
}

export function getApiBaseUrl(): string {
  try {
    const stored = window.localStorage.getItem(API_BASE_STORAGE_KEY)?.trim() ?? '';
    if (stored) {
      return stored.replace(/\/+$/, '');
    }
  } catch {
    // Ignore storage access errors
  }
  return getEnvApiBaseUrl();
}

export function setApiBaseUrl(url: string): void {
  const cleaned = url.trim().replace(/\/+$/, '');
  try {
    if (!cleaned) {
      window.localStorage.removeItem(API_BASE_STORAGE_KEY);
    } else {
      window.localStorage.setItem(API_BASE_STORAGE_KEY, cleaned);
    }
  } catch {
    // Ignore storage errors
  }
}

export function apiUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const base = getApiBaseUrl();
  return base ? `${base}${normalizedPath}` : normalizedPath;
}

export function isCapacitorNative(): boolean {
  try {
    const cap = (
      window as unknown as {
        Capacitor?: { isNativePlatform?: () => boolean };
      }
    ).Capacitor;
    return Boolean(cap?.isNativePlatform?.());
  } catch {
    return false;
  }
}
