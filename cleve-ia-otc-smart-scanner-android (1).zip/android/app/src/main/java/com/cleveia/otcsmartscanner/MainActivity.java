package com.cleveia.otcsmartscanner;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
