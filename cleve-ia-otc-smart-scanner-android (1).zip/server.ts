import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import express from 'express';
import fs from 'fs';
import JSZip from 'jszip';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { MARKET_PAIRS, getPairById } from './src/data/pairs.ts';
import type {
  AppSettings,
  BreakoutStatus,
  Candle,
  CaptureComparisonSummary,
  CaptureTrend,
  ChartImageAnalysisResult,
  MarketSourceMetadata,
  PriceProximityStatus,
  ScannerOpportunity,
  SignalDirection,
  SignalOutcome,
  SignalRecord,
  SignalStrength,
  Timeframe,
  TradingMode,
} from './src/types/market.ts';
import {
  DEFAULT_INDICATOR_CONFIG,
  analyzeMarket,
  formatDateTimePT,
  formatTimeHHMMSS,
  strengthToLabel,
} from './src/utils/indicators.ts';
import { validateAndParseOtcInput } from './src/utils/otcParser.ts';

dotenv.config();

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const PORT = 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_FILE = path.join(DATA_DIR, 'store.json');

interface PersistedStore {
  settings: AppSettings;
  signals: SignalRecord[];
  captures: ChartImageAnalysisResult[];
  importedOtc: Record<string, { candles: Candle[]; importedAtMs: number; label: string }>;
}

const DEFAULT_SETTINGS: AppSettings = {
  mode: 'DEMO',
  otcBridgeUrl: '',
  otcBridgeApiKey: '',
  telegramBotToken: '',
  telegramChatId: '',
  telegramAutoAlert: false,
  telegramAutoSendCaptures: false,
  indicatorConfig: { ...DEFAULT_INDICATOR_CONFIG },
};

function ensureStore(): PersistedStore {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(STORE_FILE)) {
      const initial: PersistedStore = {
        settings: DEFAULT_SETTINGS,
        signals: [],
        captures: [],
        importedOtc: {},
      };
      fs.writeFileSync(STORE_FILE, JSON.stringify(initial, null, 2), 'utf8');
      return initial;
    }
    const raw = fs.readFileSync(STORE_FILE, 'utf8');
    const parsed = JSON.parse(raw) as Partial<PersistedStore>;
    return {
      settings: {
        ...DEFAULT_SETTINGS,
        ...(parsed.settings ?? {}),
        indicatorConfig: {
          ...DEFAULT_INDICATOR_CONFIG,
          ...(parsed.settings?.indicatorConfig ?? {}),
        },
      },
      signals: Array.isArray(parsed.signals) ? parsed.signals : [],
      captures: Array.isArray(parsed.captures) ? parsed.captures : [],
      importedOtc: parsed.importedOtc ?? {},
    };
  } catch {
    return {
      settings: DEFAULT_SETTINGS,
      signals: [],
      captures: [],
      importedOtc: {},
    };
  }
}

function saveStore(store: PersistedStore): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2), 'utf8');
}

function normalizeCandles(rawItems: unknown[]): Candle[] {
  const normalized: Candle[] = [];
  for (const item of rawItems) {
    if (!item || typeof item !== 'object') continue;
    const row = item as Record<string, unknown>;
    const rawTime = row.time ?? row.timestamp ?? row.t ?? row.date ?? row.datetime;
    let timeMs = 0;
    if (typeof rawTime === 'number') {
      timeMs = rawTime < 1e12 ? rawTime * 1000 : rawTime;
    } else if (typeof rawTime === 'string') {
      const asNum = Number(rawTime);
      if (Number.isFinite(asNum) && rawTime.trim() !== '') {
        timeMs = asNum < 1e12 ? asNum * 1000 : asNum;
      } else {
        const parsed = Date.parse(rawTime);
        if (Number.isFinite(parsed)) timeMs = parsed;
      }
    }

    const open = Number(row.open ?? row.o);
    const high = Number(row.high ?? row.h);
    const low = Number(row.low ?? row.l);
    const close = Number(row.close ?? row.c);
    const volume =
      row.volume !== undefined
        ? Number(row.volume)
        : row.v !== undefined
          ? Number(row.v)
          : undefined;

    if (
      Number.isFinite(timeMs) &&
      timeMs > 0 &&
      Number.isFinite(open) &&
      Number.isFinite(high) &&
      Number.isFinite(low) &&
      Number.isFinite(close) &&
      open > 0 &&
      high >= low &&
      close > 0
    ) {
      normalized.push({
        time: timeMs,
        open,
        high,
        low,
        close,
        ...(volume !== undefined && Number.isFinite(volume) ? { volume } : {}),
      });
    }
  }

  const byTime = new Map<number, Candle>();
  for (const c of normalized) {
    byTime.set(c.time, c);
  }
  return Array.from(byTime.values())
    .sort((a, b) => a.time - b.time)
    .slice(-150);
}

function parseImportedPayload(rawText: string): Candle[] {
  const trimmed = rawText.trim();
  if (!trimmed) return [];

  if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
    const parsed = JSON.parse(trimmed) as unknown;
    if (Array.isArray(parsed)) {
      return normalizeCandles(parsed);
    }
    if (parsed && typeof parsed === 'object') {
      const obj = parsed as Record<string, unknown>;
      if (Array.isArray(obj.candles)) return normalizeCandles(obj.candles);
      if (Array.isArray(obj.data)) return normalizeCandles(obj.data);
    }
    return [];
  }

  const lines = trimmed
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length < 2) return [];

  const delimiter = lines[0].includes(';') ? ';' : ',';
  const firstCols = lines[0].split(delimiter).map((c) => c.trim().toLowerCase());
  const hasHeader =
    firstCols.includes('open') ||
    firstCols.includes('close') ||
    firstCols.includes('time') ||
    firstCols.includes('timestamp');

  const rows: Record<string, string>[] = [];
  if (hasHeader) {
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(delimiter).map((c) => c.trim());
      if (cols.length < 5) continue;
      const obj: Record<string, string> = {};
      for (let j = 0; j < firstCols.length && j < cols.length; j++) {
        obj[firstCols[j]] = cols[j];
      }
      rows.push(obj);
    }
  } else {
    for (const line of lines) {
      const cols = line.split(delimiter).map((c) => c.trim());
      if (cols.length < 5) continue;
      rows.push({
        time: cols[0],
        open: cols[1],
        high: cols[2],
        low: cols[3],
        close: cols[4],
        ...(cols[5] ? { volume: cols[5] } : {}),
      });
    }
  }

  return normalizeCandles(rows);
}

async function fetchFromCustomOtcBridge(
  bridgeUrl: string,
  apiKey: string,
  pairSymbol: string,
  timeframe: Timeframe
): Promise<{ candles: Candle[]; source: MarketSourceMetadata }> {
  const separator = bridgeUrl.includes('?') ? '&' : '?';
  const targetUrl = `${bridgeUrl}${separator}pair=${encodeURIComponent(
    pairSymbol
  )}&timeframe=${encodeURIComponent(timeframe)}`;

  const headers: Record<string, string> = { Accept: 'application/json' };
  if (apiKey.trim()) {
    headers['Authorization'] = `Bearer ${apiKey.trim()}`;
  }

  const resp = await fetch(targetUrl, {
    headers,
    signal: AbortSignal.timeout(8000),
  });
  if (!resp.ok) {
    throw new Error(`Bridge OTC respondeu com HTTP ${resp.status}`);
  }

  const payload = (await resp.json()) as unknown;
  let rawArr: unknown[] = [];
  if (Array.isArray(payload)) {
    rawArr = payload;
  } else if (payload && typeof payload === 'object') {
    const obj = payload as Record<string, unknown>;
    if (obj.isOtc === false) {
      throw new Error('A fonte respondeu com dados não-OTC (rejeitado por integridade).');
    }
    if (obj.pair && typeof obj.pair === 'string') {
      const normReq = pairSymbol.replace(/[^A-Z0-9]/gi, '').toUpperCase();
      const normResp = obj.pair.replace(/[^A-Z0-9]/gi, '').toUpperCase();
      if (normResp && normResp !== normReq) {
        throw new Error(
          `A Bridge OTC retornou o par ${obj.pair} em vez de ${pairSymbol}.`
        );
      }
    }
    if (Array.isArray(obj.candles)) rawArr = obj.candles;
    else if (Array.isArray(obj.data)) rawArr = obj.data;
  }

  const candles = normalizeCandles(rawArr);
  if (candles.length < 30) {
    throw new Error(
      `Bridge OTC retornou apenas ${candles.length} velas válidas (mínimo necessário: 30).`
    );
  }

  const lastTime = candles[candles.length - 1].time;
  const now = Date.now();
  const maxAgeMs = timeframe === '1m' ? 5 * 60_000 : 15 * 60_000;
  const isStale = now - lastTime > maxAgeMs;

  return {
    candles,
    source: {
      available: true,
      isPocketOtc: true,
      verified: true,
      providerName: `Bridge OTC Compatível (${pairSymbol})`,
      providerType: 'POCKET_OTC_BRIDGE',
      fetchedAtMs: now,
      lastCandleTimeMs: lastTime,
      isStale,
      ...(isStale
        ? {
            staleReason:
              'Velas recebidas da Bridge OTC têm atraso superior ao esperado para este timeframe.',
          }
        : {}),
    },
  };
}

async function resolveOtcMarketData(
  pairId: string,
  timeframe: Timeframe,
  store: PersistedStore
): Promise<{ candles: Candle[]; source: MarketSourceMetadata }> {
  const pair = getPairById(pairId);
  const now = Date.now();

  const importKey = `${pair.id}:${timeframe}`;
  const imported = store.importedOtc[importKey];
  if (imported && imported.candles.length >= 30) {
    const lastTime = imported.candles[imported.candles.length - 1].time;
    return {
      candles: imported.candles,
      source: {
        available: true,
        isPocketOtc: true,
        verified: true,
        providerName: `Velas OTC Importadas (${imported.label})`,
        providerType: 'IMPORTED_OTC',
        fetchedAtMs: now,
        importedAtMs: imported.importedAtMs,
        lastCandleTimeMs: lastTime,
        isStale: false,
      },
    };
  }

  if (store.settings.otcBridgeUrl.trim()) {
    try {
      return await fetchFromCustomOtcBridge(
        store.settings.otcBridgeUrl.trim(),
        store.settings.otcBridgeApiKey,
        pair.symbol,
        timeframe
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao consultar Bridge OTC.';
      return {
        candles: [],
        source: {
          available: false,
          isPocketOtc: true,
          verified: false,
          providerName: 'Bridge OTC Compatível',
          providerType: 'UNAVAILABLE',
          fetchedAtMs: now,
          lastCandleTimeMs: null,
          isStale: true,
          unavailableReason: 'BRIDGE_ERROR',
          unavailableMessage: `Análise OTC não disponível para ${pair.symbol}: ${msg}`,
        },
      };
    }
  }

  return {
    candles: [],
    source: {
      available: false,
      isPocketOtc: true,
      verified: false,
      providerName: 'Sem fonte OTC conectada',
      providerType: 'UNAVAILABLE',
      fetchedAtMs: now,
      lastCandleTimeMs: null,
      isStale: true,
      unavailableReason: 'NO_OTC_FEED',
      unavailableMessage: `Análise OTC não disponível para ${pair.symbol}. Não existe uma fonte de dados OTC compatível e verificável conectada para este par.`,
    },
  };
}

async function sendTelegramMessage(
  botToken: string,
  chatId: string,
  text: string
): Promise<{ ok: boolean; description?: string }> {
  const cleanToken = botToken.trim();
  const cleanChatId = chatId.trim();
  if (!cleanToken || !cleanChatId) {
    return { ok: false, description: 'Bot Token e Chat ID são obrigatórios.' };
  }

  const resp = await fetch(`https://api.telegram.org/bot${cleanToken}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: cleanChatId,
      text,
      parse_mode: 'HTML',
      disable_web_page_preview: true,
    }),
    signal: AbortSignal.timeout(8000),
  });

  const data = (await resp.json()) as { ok?: boolean; description?: string };
  if (!resp.ok || !data.ok) {
    return {
      ok: false,
      description: data.description || `Erro HTTP ${resp.status} na API do Telegram.`,
    };
  }
  return { ok: true };
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function proximityToLabel(status: PriceProximityStatus): string {
  switch (status) {
    case 'PROXIMO_SUPORTE':
      return 'Próximo de zona de Suporte';
    case 'PROXIMO_RESISTENCIA':
      return 'Próximo de zona de Resistência';
    case 'ENTRE_ZONAS':
      return 'Entre zonas de Suporte e Resistência';
    default:
      return 'Proximidade não determinada';
  }
}

function breakoutToLabel(status: BreakoutStatus): string {
  switch (status) {
    case 'ROMPIMENTO_ALTA':
      return 'Possível rompimento de alta (resistência)';
    case 'ROMPIMENTO_BAIXA':
      return 'Possível rompimento de baixa (suporte)';
    case 'FALSO_ROMPIMENTO_ALTA':
      return 'Possível falso rompimento de alta';
    case 'FALSO_ROMPIMENTO_BAIXA':
      return 'Possível falso rompimento de baixa';
    case 'SEM_ROMPIMENTO':
      return 'Sem rompimento ativo';
    default:
      return 'Não determinado';
  }
}

function formatImageAnalysisTelegramMessage(
  analysis: ChartImageAnalysisResult,
  mode: TradingMode
): string {
  const dirLabel =
    analysis.direction === 'UP'
      ? '🟢 UP (COMPRA)'
      : analysis.direction === 'DOWN'
        ? '🔴 DOWN (VENDA)'
        : '⚪ NEUTRO — AGUARDAR';

  const candleFlags: string[] = [];
  if (analysis.candleTypes?.forceCandles) candleFlags.push('Força');
  if (analysis.candleTypes?.rejectionCandles) candleFlags.push('Rejeição');
  if (analysis.candleTypes?.dojiDetected) candleFlags.push('Doji');
  if (analysis.candleTypes?.reversalSignal) candleFlags.push('Possível reversão');

  const rsiLine = analysis.indicators.rsi.visible
    ? escapeHtml(analysis.indicators.rsi.summary)
    : 'Não visível / dados insuficientes';
  const emaLine = analysis.indicators.ema.visible
    ? escapeHtml(analysis.indicators.ema.summary)
    : 'Não visível / dados insuficientes';
  const macdLine = analysis.indicators.macd.visible
    ? escapeHtml(analysis.indicators.macd.summary)
    : 'Não visível / dados insuficientes';

  return [
    `<b>POCKET AI PRO OTC · ANÁLISE DE CAPTURA</b>`,
    ``,
    `Par: <b>${escapeHtml(analysis.detectedPairText || analysis.pairSymbol)}</b>`,
    `Período: <b>${analysis.timeframe.toUpperCase()}</b> (${
      analysis.timeframe === '1m' ? '1 Minuto' : '5 Minutos'
    })`,
    `Direção: <b>${dirLabel}</b>`,
    `Força: <b>${strengthToLabel(analysis.strength)}</b>`,
    `Confiança estimada: <b>${analysis.confidence}%</b> <i>(confluência visual, não é probabilidade real de vitória)</i>`,
    ``,
    `<b>Justificativa</b>`,
    `${escapeHtml(analysis.rationale)}`,
    ``,
    `<b>Velas &amp; Tendência (${escapeHtml(analysis.trend)})</b>`,
    `• Contagem: ${analysis.greenCandlesCount} verdes / ${analysis.redCandlesCount} vermelhas`,
    `• Últimas velas: ${escapeHtml(analysis.lastCandlesSequence)}`,
    `• Leitura: ${candleFlags.length > 0 ? candleFlags.join(', ') : 'Sem destaque específico'}`,
    ``,
    `<b>Suportes &amp; Resistências</b>`,
    `• Posição: ${proximityToLabel(analysis.supportResistance.priceProximity)}`,
    `• Rompimento: ${breakoutToLabel(analysis.supportResistance.breakoutStatus)}`,
    `• Resumo S/R: ${escapeHtml(analysis.supportResistance.summary)}`,
    ``,
    `<b>Indicadores na Captura</b>`,
    `• RSI: ${rsiLine}`,
    `• EMA: ${emaLine}`,
    `• MACD: ${macdLine}`,
    ``,
    `Data/Hora: ${formatDateTimePT(analysis.analyzedAtMs)}`,
    `Modo: <b>${mode === 'DEMO' ? 'DEMO' : 'ANÁLISE REAL'}</b> · Execução automática: <b>Desativada</b>`,
    `<i>Aviso: Conteúdo informativo exclusivo Pocket Option OTC. Não garante lucros nem taxa de acerto.</i>`,
  ].join('\n');
}

function computeCaptureComparison(
  captures: ChartImageAnalysisResult[],
  pairId: string,
  pairSymbol: string,
  timeframe: Timeframe
): CaptureComparisonSummary {
  // Captures passed here are already strictly filtered to pairId + timeframe, newest first
  const latest = captures[0] ?? null;
  const previous = captures[1] ?? null;

  if (!latest || !previous) {
    return {
      pairId,
      pairSymbol,
      timeframe,
      totalCaptures: captures.length,
      trendEvolution: 'DADOS_INSUFICIENTES',
      summary:
        captures.length === 0
          ? `Sem capturas fiáveis guardadas para ${pairSymbol} (${timeframe.toUpperCase()}).`
          : `Apenas 1 captura registada para ${pairSymbol} (${timeframe.toUpperCase()}). Carregue uma segunda captura do mesmo par e período para comparar a evolução da tendência.`,
      latestCapture: latest,
      previousCapture: previous,
    };
  }

  let trendEvolution: CaptureComparisonSummary['trendEvolution'] = 'ESTAVEL';
  let summary = '';

  const sameTrend = latest.trend === previous.trend;
  const isDirectionalLatest = latest.trend === 'ALTA' || latest.trend === 'BAIXA';
  const isDirectionalPrev = previous.trend === 'ALTA' || previous.trend === 'BAIXA';

  const latestBalance =
    latest.trend === 'ALTA'
      ? latest.greenCandlesCount - latest.redCandlesCount
      : latest.redCandlesCount - latest.greenCandlesCount;
  const prevBalance =
    previous.trend === 'ALTA'
      ? previous.greenCandlesCount - previous.redCandlesCount
      : previous.redCandlesCount - previous.greenCandlesCount;

  const confDelta = latest.confidence - previous.confidence;
  const criteriaDelta =
    latest.evidenceSummary.criteriaAligned - previous.evidenceSummary.criteriaAligned;

  if (
    isDirectionalLatest &&
    isDirectionalPrev &&
    latest.trend !== previous.trend
  ) {
    trendEvolution = 'REVERSAO';
    summary = `Mudança de tendência detetada em ${pairSymbol} (${timeframe.toUpperCase()}): passou de ${previous.trend} para ${latest.trend}.`;
  } else if (latest.trend === 'LATERAL' && isDirectionalPrev) {
    trendEvolution = 'ENFRAQUECENDO';
    summary = `A tendência anterior (${previous.trend}) perdeu força e entrou em lateralização (${latest.trend}).`;
  } else if (isDirectionalLatest && previous.trend === 'LATERAL') {
    trendEvolution = 'FORTALECENDO';
    summary = `Saída de lateralização em direção a ${latest.trend} com ${latest.evidenceSummary.criteriaAligned} critérios alinhados.`;
  } else if (sameTrend && isDirectionalLatest) {
    const score =
      (confDelta >= 5 ? 1 : confDelta <= -5 ? -1 : 0) +
      (criteriaDelta > 0 ? 1 : criteriaDelta < 0 ? -1 : 0) +
      (latestBalance > prevBalance + 1 ? 1 : latestBalance < prevBalance - 1 ? -1 : 0);

    if (latest.candleTypes.reversalSignal && !previous.candleTypes.reversalSignal) {
      trendEvolution = 'ENFRAQUECENDO';
      summary = `Tendência de ${latest.trend} mantém-se, mas surgiram sinais visuais de possível reversão/exaustão nas últimas velas.`;
    } else if (score > 0) {
      trendEvolution = 'FORTALECENDO';
      summary = `Tendência de ${latest.trend} está a fortalecer (${previous.confidence}% → ${latest.confidence}% de confluência estimada, ${latest.evidenceSummary.criteriaAligned} critérios alinhados).`;
    } else if (score < 0) {
      trendEvolution = 'ENFRAQUECENDO';
      summary = `Tendência de ${latest.trend} está a enfraquecer (${previous.confidence}% → ${latest.confidence}% de confluência estimada).`;
    } else {
      trendEvolution = 'ESTAVEL';
      summary = `Tendência de ${latest.trend} mantém ritmo semelhante entre as últimas duas capturas (${latest.confidence}% est.).`;
    }
  } else {
    trendEvolution = 'ESTAVEL';
    summary = `Mercado mantém estrutura ${latest.trend} em ${pairSymbol} (${timeframe.toUpperCase()}).`;
  }

  return {
    pairId,
    pairSymbol,
    timeframe,
    totalCaptures: captures.length,
    trendEvolution,
    summary,
    latestCapture: latest,
    previousCapture: previous,
  };
}

const EXPORT_EXCLUDED_DIRS = new Set([
  'node_modules',
  'dist',
  '.git',
  'data',
  'coverage',
  '.gradle',
  'build',
]);

const EXPORT_EXCLUDED_FILES = new Set(['.env', '.env.local', 'local.properties']);

function collectExportableProjectFiles(
  rootDir: string,
  currentRelDir = ''
): Array<{ relPath: string; absPath: string; bytes: number }> {
  const fullDir = currentRelDir ? path.join(rootDir, currentRelDir) : rootDir;
  if (!fs.existsSync(fullDir)) return [];

  const entries = fs.readdirSync(fullDir, { withFileTypes: true });
  const results: Array<{ relPath: string; absPath: string; bytes: number }> = [];

  for (const entry of entries) {
    const relPath = currentRelDir ? `${currentRelDir}/${entry.name}` : entry.name;
    const absPath = path.join(rootDir, relPath);

    if (entry.isDirectory()) {
      if (EXPORT_EXCLUDED_DIRS.has(entry.name)) continue;
      if (relPath === 'android/app/build' || relPath === 'android/build') continue;
      results.push(...collectExportableProjectFiles(rootDir, relPath));
    } else if (entry.isFile()) {
      if (EXPORT_EXCLUDED_FILES.has(entry.name)) continue;
      if (entry.name.endsWith('.log') || entry.name === '.DS_Store') continue;
      const stat = fs.statSync(absPath);
      results.push({ relPath, absPath, bytes: stat.size });
    }
  }

  return results.sort((a, b) => a.relPath.localeCompare(b.relPath));
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '12mb' }));

  // Allow requests from Capacitor Android WebView shells (https://localhost, capacitor://localhost)
  app.use('/api', (req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader('Access-Control-Allow-Origin', origin);
    } else {
      res.setHeader('Access-Control-Allow-Origin', '*');
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', app: 'POCKET AI PRO OTC' });
  });

  app.get('/api/pairs', (_req, res) => {
    const store = ensureStore();
    const pairsWithStatus = MARKET_PAIRS.map((p) => ({
      ...p,
      hasImported1m: Boolean(store.importedOtc[`${p.id}:1m`]),
      hasImported5m: Boolean(store.importedOtc[`${p.id}:5m`]),
    }));
    res.json({ pairs: pairsWithStatus });
  });

  app.get('/api/settings', (_req, res) => {
    const store = ensureStore();
    res.json(store.settings);
  });

  app.put('/api/settings', (req, res) => {
    const store = ensureStore();
    const body = req.body as Partial<AppSettings>;
    store.settings = {
      ...store.settings,
      mode: body.mode === 'REAL_ANALYTICS' ? 'REAL_ANALYTICS' : 'DEMO',
      otcBridgeUrl:
        typeof body.otcBridgeUrl === 'string'
          ? body.otcBridgeUrl.trim()
          : store.settings.otcBridgeUrl,
      otcBridgeApiKey:
        typeof body.otcBridgeApiKey === 'string'
          ? body.otcBridgeApiKey.trim()
          : store.settings.otcBridgeApiKey,
      telegramBotToken:
        typeof body.telegramBotToken === 'string'
          ? body.telegramBotToken.trim()
          : store.settings.telegramBotToken,
      telegramChatId:
        typeof body.telegramChatId === 'string'
          ? body.telegramChatId.trim()
          : store.settings.telegramChatId,
      telegramAutoAlert:
        typeof body.telegramAutoAlert === 'boolean'
          ? body.telegramAutoAlert
          : store.settings.telegramAutoAlert,
      telegramAutoSendCaptures:
        typeof body.telegramAutoSendCaptures === 'boolean'
          ? body.telegramAutoSendCaptures
          : store.settings.telegramAutoSendCaptures,
      indicatorConfig: {
        ...store.settings.indicatorConfig,
        ...(body.indicatorConfig ?? {}),
      },
    };
    saveStore(store);
    res.json(store.settings);
  });

  app.get('/api/market/analyze', async (req, res) => {
    const pairId = String(req.query.pairId || 'EURUSD_OTC');
    const timeframe: Timeframe = req.query.timeframe === '5m' ? '5m' : '1m';
    const pair = getPairById(pairId);
    const store = ensureStore();

    const { candles, source } = await resolveOtcMarketData(pair.id, timeframe, store);
    const analysis = analyzeMarket(
      candles,
      pair,
      timeframe,
      store.settings.indicatorConfig,
      source
    );

    res.json(analysis);
  });

  app.get('/api/market/scanner', async (req, res) => {
    const timeframe: Timeframe = req.query.timeframe === '5m' ? '5m' : '1m';
    const pairsQuery = typeof req.query.pairIds === 'string' ? req.query.pairIds.trim() : '';
    const selectedIds = pairsQuery
      ? pairsQuery
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean)
      : MARKET_PAIRS.map((p) => p.id);

    const store = ensureStore();
    const targetPairs = MARKET_PAIRS.filter((p) => selectedIds.includes(p.id));

    const results: ScannerOpportunity[] = await Promise.all(
      targetPairs.map(async (pair) => {
        const { candles, source } = await resolveOtcMarketData(pair.id, timeframe, store);
        const analysis = analyzeMarket(
          candles,
          pair,
          timeframe,
          store.settings.indicatorConfig,
          source
        );
        return {
          pair,
          timeframe,
          available: analysis.source.available,
          direction: analysis.direction,
          strength: analysis.strength,
          confidence: analysis.confidence,
          currentPrice: analysis.currentPrice,
          rsi: analysis.latestIndicators.rsi,
          emaFast: analysis.latestIndicators.emaFast,
          emaSlow: analysis.latestIndicators.emaSlow,
          macdHistogram: analysis.latestIndicators.macdHistogram,
          entryLabel: analysis.entryEstimate?.label || 'Indisponível',
          sourceProvider: analysis.source.providerName,
          isStale: analysis.source.isStale,
          unavailableMessage: analysis.source.unavailableMessage,
        };
      })
    );

    res.json({ timeframe, opportunities: results });
  });

  app.post('/api/market/import-otc', (req, res) => {
    const { pairId, timeframe, rawData, label } = req.body as {
      pairId?: string;
      timeframe?: Timeframe;
      rawData?: string;
      label?: string;
    };

    if (!pairId || !rawData) {
      res.status(400).json({ error: 'Selecione o par OTC e forneça os dados CSV ou JSON.' });
      return;
    }

    const validPair = MARKET_PAIRS.find((p) => p.id === pairId);
    if (!validPair) {
      res.status(400).json({ error: 'Par OTC não suportado.' });
      return;
    }

    const tf: Timeframe = timeframe === '5m' ? '5m' : '1m';
    try {
      const validation = validateAndParseOtcInput(rawData, validPair.symbol);
      if (!validation.valid) {
        res.status(400).json({
          error:
            validation.errors.join(' ') ||
            `Foram encontradas apenas ${validation.validCount} velas OTC válidas (mínimo necessário: 30).`,
          validation,
        });
        return;
      }

      const importedAtMs = Date.now();
      const store = ensureStore();
      store.importedOtc[`${validPair.id}:${tf}`] = {
        candles: validation.candles,
        importedAtMs,
        label: (label || 'Exportação Manual OTC').slice(0, 40),
      };
      saveStore(store);

      res.json({
        ok: true,
        count: validation.validCount,
        rejectedCount: validation.rejectedCount,
        firstCandleTimeMs: validation.firstCandleTimeMs,
        lastCandleTimeMs: validation.lastCandleTimeMs,
        importedAtMs,
        pairId: validPair.id,
        timeframe: tf,
      });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Formato CSV/JSON inválido.',
      });
    }
  });

  app.delete('/api/market/import-otc', (req, res) => {
    const pairId = String(req.query.pairId || '');
    const tf: Timeframe = req.query.timeframe === '5m' ? '5m' : '1m';
    const store = ensureStore();
    if (pairId) {
      delete store.importedOtc[`${pairId}:${tf}`];
    } else {
      store.importedOtc = {};
    }
    saveStore(store);
    res.json({ ok: true });
  });

  app.post('/api/market/test-bridge', async (req, res) => {
    const { otcBridgeUrl, otcBridgeApiKey, pairSymbol, timeframe } = req.body as {
      otcBridgeUrl?: string;
      otcBridgeApiKey?: string;
      pairSymbol?: string;
      timeframe?: Timeframe;
    };

    if (!otcBridgeUrl || !otcBridgeUrl.trim()) {
      res.status(400).json({ ok: false, error: 'Introduza o URL da Bridge OTC.' });
      return;
    }

    try {
      const result = await fetchFromCustomOtcBridge(
        otcBridgeUrl.trim(),
        otcBridgeApiKey || '',
        pairSymbol || 'EUR/USD OTC',
        timeframe === '5m' ? '5m' : '1m'
      );
      res.json({
        ok: true,
        candleCount: result.candles.length,
        lastCandleTimeMs: result.source.lastCandleTimeMs,
      });
    } catch (err) {
      res.status(400).json({
        ok: false,
        error: err instanceof Error ? err.message : 'Falha na ligação à Bridge OTC.',
      });
    }
  });

  app.post('/api/market/analyze-image', async (req, res) => {
    const { pairId, timeframe, imageBase64, mimeType } = req.body as {
      pairId?: string;
      timeframe?: Timeframe;
      imageBase64?: string;
      mimeType?: string;
    };

    const allowedMimes = ['image/png', 'image/jpeg', 'image/webp'];
    if (!imageBase64 || !mimeType || !allowedMimes.includes(mimeType)) {
      res.status(400).json({
        error: 'Envie uma captura de ecrã válida em formato PNG, JPEG ou WEBP.',
      });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error:
          'Motor de análise visual indisponível: configure a variável GEMINI_API_KEY nos segredos do servidor.',
      });
      return;
    }

    const pair = getPairById(pairId || 'EURUSD_OTC');
    const tf: Timeframe = timeframe === '5m' ? '5m' : '1m';

    const systemInstruction = [
      'És um analista técnico institucional rigoroso especializado exclusivamente em capturas de ecrã de gráficos OTC da Pocket Option.',
      'Regras absolutas de segurança e precisão:',
      '1. ANÁLISE DE VELAS: Identifica e contabiliza velas verdes (alta) e vermelhas (baixa). Analisa especificamente as últimas 3 a 5 velas visíveis à direita (lastCandlesSequence). Reconhece explicitamente se existem velas de força (corpos amplos), velas de rejeição (pavios longos), doji (indecisão) e sinais de possível reversão.',
      '2. SUPORTES E RESISTÊNCIAS: Identifica zonas visíveis de suporte e resistência. Indica se o preço atual está próximo de um suporte, próximo de uma resistência ou entre zonas (priceProximity). Identifica possíveis rompimentos (ROMPIMENTO_ALTA / ROMPIMENTO_BAIXA) ou falsos rompimentos (FALSO_ROMPIMENTO_ALTA / FALSO_ROMPIMENTO_BAIXA, quando um pavio fura a zona e fecha de volta dentro). NUNCA inventes níveis numéricos de preços se os números no eixo vertical não estiverem claramente legíveis (usa visiblePrice: null).',
      '3. TENDÊNCIA: Classifica a tendência visível em ALTA, BAIXA, LATERAL ou INDETERMINADA.',
      '4. INDICADORES: Utiliza RSI, EMA e MACD APENAS se estiverem efetivamente desenhados e legíveis na imagem. Se algum não estiver visível ou legível, define visible=false, bias="INDISPONIVEL" e summary="Não visível ou sem dados suficientes na imagem". Nunca inventes valores.',
      '5. ANÁLISE RIGOROSA: Combina tendência + últimas velas + suportes/resistências (+ indicadores visíveis, se existirem). Só apresenta UP ou DOWN quando existirem evidências visuais suficientes e alinhadas (sufficientForSignal=true). Se houver conflito, lateralização sem gatilho ou falta de confirmação, define sufficientForSignal=false e direction="NEUTRO" (NEUTRO — AGUARDAR).',
      '6. QUALIDADE DA IMAGEM: Se a imagem não for um gráfico de velas OTC, estiver desfocada, com baixa resolução, cortada na extremidade direita, ou com menos de 8 velas legíveis, define reliable=false, explica exatamente em unreliableReason para o utilizador enviar outra captura, define direction="NEUTRO", strength="SEM_CONFLUENCIA" e confidence=0.',
      '7. Nunca prometas lucros nem presentes a confiança estimada como probabilidade real de vitória (confiança máxima <= 85).',
      'Responde sempre em Português (PT) estritamente conforme o esquema JSON.',
    ].join('\n');

    const prompt = `Analisa esta captura de ecrã de gráfico Pocket Option OTC para o par ${pair.symbol} (período selecionado: ${tf.toUpperCase()}). Extrai apenas o que é visível e aplica rigor máximo na confluência de velas, suportes/resistências e tendência.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType,
                data: imageBase64,
              },
            },
            { text: prompt },
          ],
        },
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reliable: { type: Type.BOOLEAN },
              unreliableReason: { type: Type.STRING, nullable: true },
              detectedPairText: { type: Type.STRING, nullable: true },
              visiblePriceText: { type: Type.STRING, nullable: true },
              greenCandlesCount: { type: Type.INTEGER },
              redCandlesCount: { type: Type.INTEGER },
              recentCandlesSummary: { type: Type.STRING },
              lastCandlesSequence: { type: Type.STRING },
              candleTypes: {
                type: Type.OBJECT,
                properties: {
                  forceCandles: { type: Type.BOOLEAN },
                  rejectionCandles: { type: Type.BOOLEAN },
                  dojiDetected: { type: Type.BOOLEAN },
                  reversalSignal: { type: Type.BOOLEAN },
                  details: { type: Type.STRING },
                },
                required: [
                  'forceCandles',
                  'rejectionCandles',
                  'dojiDetected',
                  'reversalSignal',
                  'details',
                ],
              },
              patterns: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    bias: { type: Type.STRING },
                    description: { type: Type.STRING },
                  },
                  required: ['name', 'bias', 'description'],
                },
              },
              trend: { type: Type.STRING },
              trendSummary: { type: Type.STRING },
              supportResistance: {
                type: Type.OBJECT,
                properties: {
                  supportZones: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        label: { type: Type.STRING },
                        visiblePrice: { type: Type.STRING, nullable: true },
                      },
                      required: ['label'],
                    },
                  },
                  resistanceZones: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        label: { type: Type.STRING },
                        visiblePrice: { type: Type.STRING, nullable: true },
                      },
                      required: ['label'],
                    },
                  },
                  priceProximity: { type: Type.STRING },
                  breakoutStatus: { type: Type.STRING },
                  summary: { type: Type.STRING },
                },
                required: [
                  'supportZones',
                  'resistanceZones',
                  'priceProximity',
                  'breakoutStatus',
                  'summary',
                ],
              },
              indicators: {
                type: Type.OBJECT,
                properties: {
                  rsi: {
                    type: Type.OBJECT,
                    properties: {
                      visible: { type: Type.BOOLEAN },
                      summary: { type: Type.STRING },
                      bias: { type: Type.STRING },
                    },
                    required: ['visible', 'summary', 'bias'],
                  },
                  ema: {
                    type: Type.OBJECT,
                    properties: {
                      visible: { type: Type.BOOLEAN },
                      summary: { type: Type.STRING },
                      bias: { type: Type.STRING },
                    },
                    required: ['visible', 'summary', 'bias'],
                  },
                  macd: {
                    type: Type.OBJECT,
                    properties: {
                      visible: { type: Type.BOOLEAN },
                      summary: { type: Type.STRING },
                      bias: { type: Type.STRING },
                    },
                    required: ['visible', 'summary', 'bias'],
                  },
                },
                required: ['rsi', 'ema', 'macd'],
              },
              evidenceSummary: {
                type: Type.OBJECT,
                properties: {
                  sufficientForSignal: { type: Type.BOOLEAN },
                  criteriaAligned: { type: Type.INTEGER },
                  notes: { type: Type.STRING },
                },
                required: ['sufficientForSignal', 'criteriaAligned', 'notes'],
              },
              direction: { type: Type.STRING },
              strength: { type: Type.STRING },
              confidence: { type: Type.INTEGER },
              rationale: { type: Type.STRING },
            },
            required: [
              'reliable',
              'greenCandlesCount',
              'redCandlesCount',
              'recentCandlesSummary',
              'lastCandlesSequence',
              'candleTypes',
              'patterns',
              'trend',
              'trendSummary',
              'supportResistance',
              'indicators',
              'evidenceSummary',
              'direction',
              'strength',
              'confidence',
              'rationale',
            ],
          },
        },
      });

      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        res.status(502).json({
          error: 'O motor de análise visual retornou uma resposta vazia.',
        });
        return;
      }

      const parsed = JSON.parse(rawText) as Omit<
        ChartImageAnalysisResult,
        'id' | 'analyzedAtMs' | 'pairId' | 'pairSymbol' | 'timeframe'
      >;

      const sanitizeBias = (
        visible: boolean,
        bias: string
      ): 'UP' | 'DOWN' | 'NEUTRO' | 'INDISPONIVEL' => {
        if (!visible) return 'INDISPONIVEL';
        if (bias === 'UP' || bias === 'DOWN' || bias === 'NEUTRO') return bias;
        return 'NEUTRO';
      };

      const reliable = Boolean(parsed.reliable);
      const sufficientForSignal = reliable && Boolean(parsed.evidenceSummary?.sufficientForSignal);
      const validDirs: SignalDirection[] = ['UP', 'DOWN', 'NEUTRO'];
      const validStrengths: SignalStrength[] = [
        'MUITO_FORTE',
        'FORTE',
        'MODERADA',
        'FRACA',
        'SEM_CONFLUENCIA',
      ];
      const validTrends: CaptureTrend[] = ['ALTA', 'BAIXA', 'LATERAL', 'INDETERMINADA'];
      const validProximity: PriceProximityStatus[] = [
        'PROXIMO_SUPORTE',
        'PROXIMO_RESISTENCIA',
        'ENTRE_ZONAS',
        'INDETERMINADO',
      ];
      const validBreakouts: BreakoutStatus[] = [
        'SEM_ROMPIMENTO',
        'ROMPIMENTO_ALTA',
        'ROMPIMENTO_BAIXA',
        'FALSO_ROMPIMENTO_ALTA',
        'FALSO_ROMPIMENTO_BAIXA',
        'INDETERMINADO',
      ];

      // Rigorous signal gate: only emit UP or DOWN if reliable AND sufficientForSignal
      let safeDirection: SignalDirection = 'NEUTRO';
      if (reliable && sufficientForSignal && validDirs.includes(parsed.direction)) {
        safeDirection = parsed.direction;
      }

      const safeStrength: SignalStrength =
        !reliable || safeDirection === 'NEUTRO'
          ? 'SEM_CONFLUENCIA'
          : validStrengths.includes(parsed.strength)
            ? parsed.strength
            : 'MODERADA';

      const safeConfidence = reliable
        ? safeDirection === 'NEUTRO'
          ? Math.max(0, Math.min(55, Math.round(Number(parsed.confidence) || 0)))
          : Math.max(52, Math.min(85, Math.round(Number(parsed.confidence) || 0)))
        : 0;

      const store = ensureStore();

      const result: ChartImageAnalysisResult = {
        id: `cap_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        analyzedAtMs: Date.now(),
        pairId: pair.id,
        pairSymbol: pair.symbol,
        timeframe: tf,
        reliable,
        unreliableReason: reliable
          ? undefined
          : parsed.unreliableReason ||
            'A imagem não tem qualidade ou velas suficientes para uma análise fiável. Envie outra captura mais nítida.',
        detectedPairText: parsed.detectedPairText || null,
        visiblePriceText: parsed.visiblePriceText || null,
        greenCandlesCount: Math.max(0, Math.round(Number(parsed.greenCandlesCount) || 0)),
        redCandlesCount: Math.max(0, Math.round(Number(parsed.redCandlesCount) || 0)),
        recentCandlesSummary: parsed.recentCandlesSummary || 'Sem leitura detalhada.',
        lastCandlesSequence:
          parsed.lastCandlesSequence || 'Sequência recente não identificada.',
        candleTypes: {
          forceCandles: Boolean(parsed.candleTypes?.forceCandles),
          rejectionCandles: Boolean(parsed.candleTypes?.rejectionCandles),
          dojiDetected: Boolean(parsed.candleTypes?.dojiDetected),
          reversalSignal: Boolean(parsed.candleTypes?.reversalSignal),
          details:
            parsed.candleTypes?.details ||
            'Sem características especiais de velas identificadas.',
        },
        patterns: Array.isArray(parsed.patterns)
          ? parsed.patterns.slice(0, 5).map((p) => ({
              name: p.name,
              bias:
                p.bias === 'BULLISH' || p.bias === 'BEARISH' || p.bias === 'NEUTRAL'
                  ? p.bias
                  : 'NEUTRAL',
              description: p.description,
            }))
          : [],
        trend: validTrends.includes(parsed.trend) ? parsed.trend : 'INDETERMINADA',
        trendSummary: parsed.trendSummary || 'Sem tendência definida.',
        supportResistance: {
          supportZones: Array.isArray(parsed.supportResistance?.supportZones)
            ? parsed.supportResistance.supportZones.slice(0, 3).map((z) => ({
                label: z.label,
                visiblePrice: z.visiblePrice || null,
              }))
            : [],
          resistanceZones: Array.isArray(parsed.supportResistance?.resistanceZones)
            ? parsed.supportResistance.resistanceZones.slice(0, 3).map((z) => ({
                label: z.label,
                visiblePrice: z.visiblePrice || null,
              }))
            : [],
          priceProximity: validProximity.includes(
            parsed.supportResistance?.priceProximity
          )
            ? parsed.supportResistance.priceProximity
            : 'INDETERMINADO',
          breakoutStatus: validBreakouts.includes(
            parsed.supportResistance?.breakoutStatus
          )
            ? parsed.supportResistance.breakoutStatus
            : 'INDETERMINADO',
          summary:
            parsed.supportResistance?.summary ||
            'Zonas de suporte e resistência não claramente delimitadas.',
        },
        indicators: {
          rsi: {
            visible: Boolean(parsed.indicators?.rsi?.visible),
            summary: parsed.indicators?.rsi?.visible
              ? parsed.indicators.rsi.summary
              : 'Não visível ou sem dados suficientes na imagem.',
            bias: sanitizeBias(
              Boolean(parsed.indicators?.rsi?.visible),
              parsed.indicators?.rsi?.bias
            ),
          },
          ema: {
            visible: Boolean(parsed.indicators?.ema?.visible),
            summary: parsed.indicators?.ema?.visible
              ? parsed.indicators.ema.summary
              : 'Não visível ou sem dados suficientes na imagem.',
            bias: sanitizeBias(
              Boolean(parsed.indicators?.ema?.visible),
              parsed.indicators?.ema?.bias
            ),
          },
          macd: {
            visible: Boolean(parsed.indicators?.macd?.visible),
            summary: parsed.indicators?.macd?.visible
              ? parsed.indicators.macd.summary
              : 'Não visível ou sem dados suficientes na imagem.',
            bias: sanitizeBias(
              Boolean(parsed.indicators?.macd?.visible),
              parsed.indicators?.macd?.bias
            ),
          },
        },
        evidenceSummary: {
          sufficientForSignal,
          criteriaAligned: Math.max(
            0,
            Math.round(Number(parsed.evidenceSummary?.criteriaAligned) || 0)
          ),
          notes:
            parsed.evidenceSummary?.notes ||
            (sufficientForSignal
              ? 'Evidências visuais convergentes.'
              : 'Sem confirmação visual suficiente — recomenda-se aguardar.'),
        },
        direction: safeDirection,
        strength: safeStrength,
        confidence: safeConfidence,
        rationale:
          parsed.rationale ||
          (safeDirection === 'NEUTRO'
            ? 'Sem confirmação visual suficiente entre tendência, velas e zonas de suporte/resistência.'
            : ''),
      };

      // Persist reliable capture in pair+timeframe isolated capture history
      if (result.reliable) {
        // Optional automatic Telegram dispatch for image analysis
        if (
          store.settings.telegramAutoSendCaptures &&
          store.settings.telegramBotToken.trim() &&
          store.settings.telegramChatId.trim()
        ) {
          const text = formatImageAnalysisTelegramMessage(result, store.settings.mode);
          try {
            const tgResp = await sendTelegramMessage(
              store.settings.telegramBotToken,
              store.settings.telegramChatId,
              text
            );
            if (tgResp.ok) {
              result.telegramAutoSent = true;
            } else {
              result.telegramAutoSent = false;
              result.telegramAutoError = tgResp.description;
            }
          } catch (tgErr) {
            result.telegramAutoSent = false;
            result.telegramAutoError =
              tgErr instanceof Error ? tgErr.message : 'Erro ao enviar automaticamente para o Telegram.';
          }
        }

        store.captures = [result, ...store.captures].slice(0, 150);
        saveStore(store);
      }

      res.json(result);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Erro ao analisar captura de ecrã.';
      res.status(502).json({
        error: `Falha na análise visual da imagem: ${msg}`,
      });
    }
  });

  app.get('/api/market/capture-history', (req, res) => {
    const pairId = String(req.query.pairId || 'EURUSD_OTC');
    const timeframe: Timeframe = req.query.timeframe === '5m' ? '5m' : '1m';
    const pair = getPairById(pairId);
    const store = ensureStore();

    // Strict isolation: NEVER mix captures of different pairs or timeframes
    const filtered = store.captures.filter(
      (c) => c.pairId === pair.id && c.timeframe === timeframe && c.reliable
    );
    const comparison = computeCaptureComparison(filtered, pair.id, pair.symbol, timeframe);

    res.json({
      captures: filtered,
      comparison,
    });
  });

  app.delete('/api/market/capture-history', (req, res) => {
    const pairId = String(req.query.pairId || '');
    const timeframe = String(req.query.timeframe || '');
    const store = ensureStore();
    if (pairId && (timeframe === '1m' || timeframe === '5m')) {
      store.captures = store.captures.filter(
        (c) => !(c.pairId === pairId && c.timeframe === timeframe)
      );
    } else {
      store.captures = [];
    }
    saveStore(store);
    res.json({ ok: true });
  });

  app.get('/api/signals', (_req, res) => {
    const store = ensureStore();
    res.json({ signals: store.signals });
  });

  app.post('/api/signals', (req, res) => {
    const store = ensureStore();
    const body = req.body as Omit<SignalRecord, 'id' | 'createdAtMs'> & {
      dedupeByCandle?: boolean;
    };
    const validDirs: SignalDirection[] = ['UP', 'DOWN', 'NEUTRO'];
    if (!body || !body.pairSymbol || !validDirs.includes(body.direction) || !body.isPocketOtc) {
      res.status(400).json({ error: 'Dados da análise OTC inválidos.' });
      return;
    }

    if (body.dedupeByCandle && body.candleTimeMs) {
      const existing = store.signals.find(
        (s) =>
          s.pairId === body.pairId &&
          s.timeframe === body.timeframe &&
          s.candleTimeMs === body.candleTimeMs &&
          s.direction === body.direction
      );
      if (existing) {
        res.json({ signal: existing, deduplicated: true });
        return;
      }
    }

    const { dedupeByCandle: _ignore, ...record } = body;
    const created: SignalRecord = {
      ...record,
      id: `sig_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      createdAtMs: Date.now(),
      outcome: record.outcome || 'PENDENTE',
    };

    store.signals = [created, ...store.signals].slice(0, 200);
    saveStore(store);
    res.json({ signal: created });
  });

  app.patch('/api/signals/:id', (req, res) => {
    const store = ensureStore();
    const { id } = req.params;
    const { outcome } = req.body as { outcome?: SignalOutcome };
    const validOutcomes: SignalOutcome[] = ['PENDENTE', 'WIN', 'LOSS', 'EMPATE'];
    if (!outcome || !validOutcomes.includes(outcome)) {
      res.status(400).json({ error: 'Resultado inválido.' });
      return;
    }

    const idx = store.signals.findIndex((s) => s.id === id);
    if (idx === -1) {
      res.status(404).json({ error: 'Registo não encontrado.' });
      return;
    }

    store.signals[idx] = { ...store.signals[idx], outcome };
    saveStore(store);
    res.json({ signal: store.signals[idx] });
  });

  app.delete('/api/signals', (_req, res) => {
    const store = ensureStore();
    store.signals = [];
    saveStore(store);
    res.json({ ok: true });
  });

  app.post('/api/telegram/test', async (req, res) => {
    const store = ensureStore();
    const body = req.body as { botToken?: string; chatId?: string };
    const token = body.botToken ?? store.settings.telegramBotToken;
    const chatId = body.chatId ?? store.settings.telegramChatId;

    const msg = [
      '<b>POCKET AI PRO OTC</b>',
      'Ligação ao Telegram verificada com sucesso.',
      `Modo atual: <b>${store.settings.mode === 'DEMO' ? 'DEMO' : 'ANÁLISE REAL'}</b>`,
      'Execução automática: Desativada (sistema informativo).',
    ].join('\n');

    try {
      const result = await sendTelegramMessage(token, chatId, msg);
      if (!result.ok) {
        res.status(400).json({ ok: false, error: result.description });
        return;
      }
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({
        ok: false,
        error: err instanceof Error ? err.message : 'Erro ao comunicar com a API do Telegram.',
      });
    }
  });

  app.post('/api/telegram/send-signal', async (req, res) => {
    const store = ensureStore();
    const { signalId, signal } = req.body as { signalId?: string; signal?: SignalRecord };

    const token = store.settings.telegramBotToken;
    const chatId = store.settings.telegramChatId;
    if (!token || !chatId) {
      res.status(400).json({
        ok: false,
        error: 'Configure o Bot Token e o Chat ID do Telegram nas Configurações.',
      });
      return;
    }

    let target = signal;
    if (!target && signalId) {
      target = store.signals.find((s) => s.id === signalId);
    }
    if (!target) {
      res.status(400).json({ ok: false, error: 'Sinal não encontrado para envio.' });
      return;
    }
    if (!target.isPocketOtc || (target.direction !== 'UP' && target.direction !== 'DOWN')) {
      res.status(400).json({
        ok: false,
        error: 'Apenas sinais OTC válidos (UP ou DOWN) podem ser enviados para o Telegram.',
      });
      return;
    }

    const dirEmoji = target.direction === 'UP' ? '🟢 UP (COMPRA)' : '🔴 DOWN (VENDA)';
    const entryClock = formatTimeHHMMSS(target.entryTimeMs);
    const text = [
      `<b>POCKET AI PRO OTC · SINAL OTC VÁLIDO</b>`,
      ``,
      `Par: <b>${target.pairSymbol}</b>`,
      `Timeframe: <b>${target.timeframe.toUpperCase()}</b> (Expiração: ${target.expirationMinutes} min)`,
      `Direção: <b>${dirEmoji}</b>`,
      `Entrada estimada: <b>${entryClock}</b>`,
      `Força: <b>${strengthToLabel(target.strength)}</b> · Confiança est.: <b>${target.confidence}%</b>`,
      ``,
      `<b>Indicadores</b>`,
      `• RSI: ${target.indicatorsSnapshot.rsi !== null ? target.indicatorsSnapshot.rsi.toFixed(1) : 'N/A'}`,
      `• MACD Hist: ${
        target.indicatorsSnapshot.macdHistogram !== null
          ? target.indicatorsSnapshot.macdHistogram.toFixed(5)
          : 'N/A'
      }`,
      `• Padrão: ${target.indicatorsSnapshot.pattern}`,
      ``,
      `Fonte: ${target.sourceProvider}`,
      `Modo: ${target.mode === 'DEMO' ? 'DEMO' : 'Análise Real'} · Sem execução automática`,
      `<i>Aviso: Análise técnica informativa. Não garante lucros nem taxa de acerto.</i>`,
    ].join('\n');

    try {
      const result = await sendTelegramMessage(token, chatId, text);
      if (!result.ok) {
        res.status(400).json({ ok: false, error: result.description });
        return;
      }

      if (signalId) {
        const idx = store.signals.findIndex((s) => s.id === signalId);
        if (idx !== -1) {
          store.signals[idx] = { ...store.signals[idx], telegramSent: true };
          saveStore(store);
        }
      }

      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({
        ok: false,
        error: err instanceof Error ? err.message : 'Erro ao enviar alerta para o Telegram.',
      });
    }
  });

  app.post('/api/telegram/send-image-analysis', async (req, res) => {
    const store = ensureStore();
    const { analysis } = req.body as { analysis?: ChartImageAnalysisResult };

    const token = store.settings.telegramBotToken;
    const chatId = store.settings.telegramChatId;
    if (!token || !chatId) {
      res.status(400).json({
        ok: false,
        error: 'Configure o Bot Token e o Chat ID do Telegram nas Configurações.',
      });
      return;
    }

    if (!analysis || !analysis.reliable) {
      res.status(400).json({
        ok: false,
        error:
          'A imagem não possui análise fiável. Solicite outra captura antes de enviar.',
      });
      return;
    }

    const text = formatImageAnalysisTelegramMessage(analysis, store.settings.mode);

    try {
      const result = await sendTelegramMessage(token, chatId, text);
      if (!result.ok) {
        res.status(400).json({ ok: false, error: result.description });
        return;
      }
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({
        ok: false,
        error:
          err instanceof Error
            ? err.message
            : 'Erro ao enviar resultado da imagem para o Telegram.',
      });
    }
  });

  app.get('/api/export/manifest', (_req, res) => {
    try {
      const rootDir = process.cwd();
      const files = collectExportableProjectFiles(rootDir);
      const totalBytes = files.reduce((acc, f) => acc + f.bytes, 0);
      const hasAndroidProject = fs.existsSync(
        path.join(rootDir, 'android', 'app', 'build.gradle')
      );
      res.json({
        projectName: 'CLEVE IA - OTC SMART SCANNER',
        capacitorAppId: 'com.cleveia.otcsmartscanner',
        hasAndroidProject,
        totalFiles: files.length,
        totalBytes,
        files: files.map((f) => ({ path: f.relPath, bytes: f.bytes })),
      });
    } catch (err) {
      res.status(500).json({
        error:
          err instanceof Error
            ? err.message
            : 'Falha ao listar os ficheiros do projeto.',
      });
    }
  });

  app.get('/api/export/project-zip', async (_req, res) => {
    try {
      const rootDir = process.cwd();
      const files = collectExportableProjectFiles(rootDir);
      const zip = new JSZip();

      for (const file of files) {
        const content = fs.readFileSync(file.absPath);
        zip.file(file.relPath, content);
      }

      const zipBuffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="cleve-ia-otc-smart-scanner-android.zip"'
      );
      res.setHeader('Content-Length', String(zipBuffer.length));
      res.send(zipBuffer);
    } catch (err) {
      res.status(500).json({
        error:
          err instanceof Error
            ? err.message
            : 'Erro ao gerar ficheiro ZIP do projeto.',
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`POCKET AI PRO OTC server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
